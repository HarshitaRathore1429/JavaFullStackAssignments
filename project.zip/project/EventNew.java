import java.util.Scanner;
import java.sql.*;
import java.io.*;
import java.util.regex.*;
import java.util.*;
import java.util.InputMismatchException;
import java.util.LinkedHashMap;
class Login
{
	private String user_name,user_password;
	private int user_id;
	Login(int user_id,String user_name,String user_password)
	{
		this.user_id=user_id;
		this.user_name=user_name;
		this.user_password=user_password;
	}
	 public String tostring()
    {
	   return " User name: "+ user_name+" Password: "+user_password;
    }
}
class User
{
	String email,user_address;
	long phone_no;
	Login l;
	User(Login l, String email, long phone_no, String user_address)
	{
		this.l=l;
		this.email=email;
		this.phone_no=phone_no;
		this.user_address=user_address;
	}
	void display()
	{
		System.out.println(l.tostring()+" User email :"+email+" User phone no: "+phone_no+" User address: "+user_address);
	}
} 
class Success
{
	String sucvenue,stitle;
	Success(String stitle,String sucvenue)
	{
      	this.stitle=stitle;
	    this.sucvenue=sucvenue;
	}
	void sdisplay()
	{
		System.out.println("Title for success party is: "+stitle);
		System.out.println("Selected venue is: "+sucvenue);
	}
}
class Welcome
{
	String welvenue,weltagline;
	Welcome(String weltagline,String welvenue)
	{
      	this.weltagline=weltagline;
	    this.welvenue=welvenue;
	}
	void wdisplay()
	{
		System.out.println("Title for success party is: "+weltagline);
		System.out.println("Selected venue is: "+welvenue);
	}
}
class Farewell
{
	String fname,favenue;
	Farewell(String fname,String favenue)
	{
      	this.fname=fname;
	    this.favenue=favenue;
	}
	void fdisplay()
	{
		System.out.println("Title for success party is: "+fname);
		System.out.println("Selected venue is: "+favenue);
	}
}
class Birthday
{
	String name,venue;
	Birthday(String name,String venue)
	{
		this.name=name;
		this.venue=venue;
	}
	void name()
	{
		System.out.println("Birthday boy/girl: "+name);
	}
	void confirm()
	{
		System.out.println("Basic details are filled!!");
	}
	void displayvenue()
	{
		System.out.println("Selected venue for birthday is: "+venue);
	}
}
class Anniversary 
{
	String men,women,annvenue;
	Anniversary(String men,String women, String annvenue)
	{
		this.men=men;
		this.women=women;
		this.annvenue=annvenue;
	}
	void showname()
	{
		System.out.println("Anniversary is of "+men+" & "+women);
	}
	void confirm()
	{
		System.out.println("Basic details are filled!!");
	}
	void displayvenue()
	{
		System.out.println("Selected venue for birthday is: "+annvenue);
	}
}
class Festival
{
	String fvenue,fname,farrange;
	Festival(String fvenue,String fname,String farrange)
	{
		this.fvenue=fvenue;
		this.fname=fname;
		this.farrange=farrange;
	}
	void fdisplay()
	{
		System.out.println("Your festive is: "+fname);
		System.out.println("Your choosed venue is: "+fvenue);
		if(farrange.equals("Yes"))
			System.out.println("We will arrange festive items!");
		else
			System.out.println("Festive items are not arranged by us.");
	}
}
abstract class Food
{
	abstract void use();
}
class Indian extends Food
{
	void use()
	{
		System.out.println("Indian cuisine is confirmed");
	}
}
class Chinese extends Food
{
	void use()
	{
		System.out.println("Chinese cuisine is confirmed");
	}
}	
class Event
{
	public static void main(String[] args)
	{
		 String user_name,user_password, user_email,user_address,party,event_type,event_name;
		 int user_id,c,guestno;;
		 long user_mobile;
		 int price=0,total=0,food_cost=0,approve_id;
		 Scanner s=new Scanner(System.in);
		 try
		 {
			Class.forName("com.mysql.jdbc.Driver");
		    String url="jdbc:mysql://localhost:3306/EventMgmt";
		    String user="root";
		    String pass="root";
		    Connection con=DriverManager.getConnection(url,user,pass);
		    Statement stmt=con.createStatement();
		    BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			   System.out.println("Enter the user id:");
			   user_id=Integer.parseInt(br.readLine());
               System.out.println("Enter the user name:");
               user_name=br.readLine();
			   System.out.println("Enter the password: ");
			   user_password=br.readLine();
			   ResultSet rs=stmt.executeQuery("select user_name from login where user_name like '"+'%'+user_name+'%'+"'");
               if(rs.next())
			   {
                    System.out.println("Logged in");
					if(user_id==1)
					{
						do
						{
							System.out.println("Welcome Admin");
						    System.out.println("1. View bookings");
						    System.out.println("2. Add event manager");
						    System.out.println("3. View feedback");
							int option=s.nextInt();
							if(option==1)
							{
								String query6="Select * from venue_details";
								ResultSet rs1=stmt.executeQuery(query6);
			  					while(rs1.next())
			                    {
				                  System.out.println("User id: "+rs1.getInt(1)+", Cuisine:  "+rs1.getString(2)+", Food type:  "+rs1.getString(3)+", Food Category: "+rs1.getString(4)+", Food Cost: "+rs1.getLong(5)+", DJ: "+rs1.getString(6)+", Stage: "+rs1.getString(7)+", Speaker: "+rs1.getString(8)+", Total: "+rs1.getLong(9)+", Status: "+rs1.getString(10)+", Feedback: "+rs1.getString(11));
		                     	}
								//if(rs1.next())
									//System.out.println(rs1.getInt(1)+" "+rs1.getString(2)+" "+rs1.getString(3)+" "+rs1.getString(4)+" "+rs1.getLong(5)+" "+rs1.getString(6)+" "+rs1.getString(7)+" "+rs1.getString(8)+" "+rs1.getLong(9)+" "+rs1.getString(10)+" "+rs1.getString(11));
								System.out.println("Do you want to approve any booking: Yes or No");
								String approve_status=s.next();
								if(approve_status.equals("Yes"))
								{
									System.out.println("Enter user_id which status you need to approve:");
									approve_id=s.nextInt();
									String query7="Update venue_details set status='Approved' where user_id='"+approve_id+"'";
									stmt.executeUpdate(query7);
								}
                            }	
							if(option==2)
							{
								System.out.println("Enter eventmanager id:");
								int event_manager_id=s.nextInt();
								System.out.println("Enter event manager name");
								String event_manager_name=s.next();
								LinkedHashMap<Integer,String> lk=new LinkedHashMap<Integer,String>();
								lk.put(event_manager_id,event_manager_name);
								String query9="Insert into event_manager(event_manager_id,event_manager_name,status) values(?,?,?)";
								PreparedStatement ps1=con.prepareStatement(query9);
								ps1.setInt(1,event_manager_id);
								ps1.setString(2,event_manager_name);
								ps1.setString(3,"Free");
								ps1.executeUpdate();
							}
							if(option==3)
							{
								String query8="Select user_id,feedback from venue_details";
								ResultSet rs2=stmt.executeQuery(query8);
								while(rs2.next())
								{
								  System.out.println(rs2.getInt("user_id")+" "+rs2.getString("feedback"));	
								}
							}							
							System.out.println("Do you want to continue: y/n");  
                            String say=br.readLine();  
                            if(say.startsWith("n"))
							{  
                              break;
	    					}
						}while(true); 
					}
					else
					{
					System.out.println("Do you want to see user_details, event_details and venue details: Yes or No");
					String answer=s.next();
					if(answer.equals("Yes"));
					{
						String query2="Select * from user_details where user_id='"+user_id+"'";
					    String query3="Select * from event_details where user_id='"+user_id+"'";
						String query5="Select * from venue_details where user_id='"+user_id+"'";
					ResultSet rst=stmt.executeQuery(query2);
					if(rst.next())
					{
				        System.out.println("User id: "+rst.getInt(1) + " " + "User email: " +rst.getString(2)+ " "+"User mobile: "+rst.getLong(3)+" "+"User address: "+rst.getString(4));
			        }
					ResultSet rt=stmt.executeQuery(query3);
					if(rt.next())
					{
				        System.out.println("User id: "+rt.getInt(1)+" "+"Event type: "+rt.getString(2)+" "+"Event name "+rt.getString(3));
			        }
					ResultSet r=stmt.executeQuery(query5);
					if(r.next())
					{
					   System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getLong(5)+" "+rs.getString(6)+" "+rs.getString(7)+" "+rs.getString(8)+" "+rs.getLong(9)+" "+r.getString(10)+" "+rs.getString(11));
					}
					}
					}
			    }
			    else
     		    {
			     String query="Insert into login(user_id,user_name,user_password) values (?,?,?)";
			     String query1="Insert into user_details(user_id,user_email,user_mobile,user_address) values(?,?,?,?)";
			     PreparedStatement pstmt=con.prepareStatement(query);
			     pstmt.setInt(1,user_id);
			     pstmt.setString(2,user_name);
			     pstmt.setString(3,user_password);
			     pstmt.executeUpdate();
			     PreparedStatement pst=con.prepareStatement(query1);
			     System.out.println("User is registered");
			     Login l=new Login(user_id,user_name, user_password);
			     System.out.println("Setup user profile");
			     pst.setInt(1,user_id);
			     System.out.println("Enter email:");
			     user_email=br.readLine();
			     String regex = "^(.+)@(.+)$"; 
			     Pattern pattern = Pattern.compile(regex);
			     Matcher matcher = pattern.matcher(user_email);
			     if(matcher.matches()==true)
			     {
				   pst.setString(2,user_email);
			     }
			     else
			     {
				   System.out.println("Enter valid email");
			       System.exit(0);
			     }
			     System.out.println("Enter user phone no: ");
			     user_mobile=Long.parseLong(br.readLine());
			     pst.setLong(3,user_mobile);
			     System.out.println("Enter your address: ");
			     user_address=br.readLine();
			     pst.setString(4,user_address);
			     pst.executeUpdate();
			     User user1=new User(l, user_email,user_mobile,user_address);
			     // user1.display();
		         String tagline,venue,title,farename,bname,cmen,cwomen,festive,arrange;
		         System.out.println("Enter 1 for corporate events, Enter 2 for personal events.");
		         c=s.nextInt();
		         if(c==1)
	             {
	         		System.out.println("1. Welcome party");
	         		System.out.println("2. Success party");
		        	System.out.println("3. Farwell party");
			        System.out.println("Please select type of corporate event by choosing number.");
		            event_name=s.next();
			        switch(event_name)
			        {
			        	case"Welcomeparty":
				        System.out.println("Enter welcome party's tagline:");
				        tagline=s.next();
		         		System.out.println("Write venue between two choice: a) office b) hotel");
		                venue=s.next();
		         		Welcome w=new Welcome(tagline,venue);
			        	w.wdisplay();
				        if(venue.equals("hotel"))
					        total=total+20000;
				        break;
				        case"Successparty":
		            	System.out.println("Enter success party's title:");
               			title=s.next();
				        System.out.println("Write venue between two choice: a) office b) hotel");
		                venue=s.next();
				        Success sc=new Success(title,venue);
			            sc.sdisplay();
		          		if(venue.equals("hotel"))
		                 	total=total+20000;
			         	break;
				        case"Farewellparty":
				        System.out.println("Enter name for whom the farewell party is:");
				        farename=s.next();
				        System.out.println("Write venue between two choice: a) office b) hotel");
		                venue=s.next();
			        	Farewell f=new Farewell(farename,venue);
				        f.fdisplay();
				        if(venue.equals("hotel"))
					       total=total+20000;
			        	break;
			        }
			        event_type="Corporate event";
		            String q="Insert into event_details(user_id,event_type,event_name) values(?,?,?)";
	            	PreparedStatement ps=con.prepareStatement(q);
            		ps.setInt(1,user_id);
		            ps.setString(2,event_type);
		            ps.setString(3,event_name);
		            ps.executeUpdate();
		         }
		         if(c==2)
		         {
			      event_type="Personal event";
		          System.out.println("1. Birthday");
			      System.out.println("2. Anniversary");
			      System.out.println("3. Festive party");
		          System.out.println("Please choose number according to event.");
		          event_name=s.next();
	        	  switch(event_name)
		          {
	               	case"Birthday":
		            System.out.println("Enter the birthday person name:");
		            bname=s.next();
		            System.out.println("Write venue between two choice: a) house b) hotel");
		            venue=s.next();
		            Birthday bn=new Birthday (bname,venue);
                    bn.name();
		            bn.displayvenue();
		            bn.confirm();
		         	if(venue.equals("hotel"))
				    	total=total+20000;
		            break;
		            case"Anniversary":
		            System.out.println("Enter the men name:");
		            cmen=s.next();
		            System.out.println("Enter the name of women:");
		            cwomen=s.next();
		            System.out.println("Write venue between two choice: a)house b) hotel");
		            venue=s.next();
		            Anniversary an=new Anniversary(cmen,cwomen,venue);
		            an.showname();
		            an.displayvenue();
		            an.confirm();
			        if(venue.equals("hotel"))
					   total=total+20000;
		            break;
			        case"Festiveparty":
			        System.out.println("Enter festive name:");
			        festive=s.next();
			        System.out.println("Write venue between two choice: a)house b)hotel");
			        venue=s.next();
			        System.out.println("Do you want us to arrange festive items: Yes or No");
			        arrange=s.next();
		        	Festival f=new Festival(festive,venue,arrange);
        			f.fdisplay();
		        	if(venue.equals("hotel"))
					   total=total+20000;
			        if(arrange.equals("Yes"))
				       total=total+10000;
			        break;
		          }
			      String q="Insert into event_details(user_id,event_type,event_name) values(?,?,?)";
		          PreparedStatement ps=con.prepareStatement(q);
		          ps.setInt(1,user_id);
		          ps.setString(2,event_type);
		          ps.setString(3,event_name);
		          ps.executeUpdate();
	             }
		         System.out.println("Please choose cuisine, Indian or Chinese");
		         String cuisine=s.next();
		         switch(cuisine)
		         {
			      case"Indian":
		      	  {
				   Indian i=new Indian();
		           i.use();
			       break;
		          }
			      case"Chinese":
			      { 
			       Chinese ch=new Chinese();
			       ch.use();
			       break;
			      }
	             }
		         System.out.println("select type of food:");
                 System.out.println("1. Breakfast");	
			     System.out.println("2. Lunch");
			     System.out.println("3. Tea & Snacks");
			     System.out.println("4. Dinner");
			     String food_type=s.next();
			     System.out.println("Please select the food category: ");
			     System.out.println("1. Basic");
			     System.out.println("2. Delite");
			     System.out.println("3. Royal");
			     String food_category=s.next();
			     if(food_category.equals("Basic"))
			     {
				   price=500;
				   System.out.println("Price is:"+price);
			     }
			     else if(food_category.equals("Delite"))
			     {
				   price=1200;
			     }
			     else if(food_category.equals("Royal"))
			     {
				   price=2500;
			     }
			     total=total+price;
			     System.out.println("total upto now: "+total);
			     System.out.println("Enter the total number of guest:");
		         guestno=s.nextInt();
			     food_cost=price*guestno;
			     System.out.println("Total cost of food is:" +food_cost);
			     total=total+food_cost;
			     System.out.println("Do you want to include DJ: Yes or No");
			     String DJ=s.next();
			     if(DJ.equals("Yes"))
			     {
				   total=total+10000;
			     }
			     else 
			     {
				   total=total;
			     }
			     System.out.println("Do you want a stage for event: Yes or No");
			     String stage=s.next();
			     if(stage.equals("Yes"))
			     {
				   total=total+7000;
			     }
			     else
                 {
				   total=total;
			     }
			     System.out.println("Do you want mike and speakers: Yes or No");
			     String speakers=s.next();
			     if(speakers.equals("Yes"))
			     {
				   total=total+8000;
			     }
			     else
			     {
				   total=total;
			     }
				 System.out.println("Do you want to have event_manager: Yes or No");
				 String manager=s.next();
				 if(manager.equals("Yes"))
				 {
					 total=total+15000;
					 String query10="Select * from event_manager";
					 ResultSet rs3=stmt.executeQuery(query10);
					 while(rs3.next())
					 {
						 System.out.println(rs3.getInt(1)+" "+rs3.getString(2)+" "+rs3.getString(3));
					 }
					 System.out.println("Enter event_manager_id to book event_manager");
					 int alloted_event_manager_id=s.nextInt();
					 String query11="Update event_manager set status='Alloted' where event_manager_id='"+alloted_event_manager_id+"'";
					 stmt.executeUpdate(query11);
				 }
			     System.out.println("Total payment for choosed event including your requirments is:"+total);
			     String status="Pending";
			     System.out.println("Give feedback: how was your experience");
			     System.out.println("1. Satisfied");
			     System.out.println("2. Highlysatisfied");
			     System.out.println("3. Notsatisfied");
			     String feedback=s.next();
			     String query4="Insert into venue_details(user_id,cuisine,food_type,food_categor,food_cost,DJ,stage,speakers,total,status,feedback) values(?,?,?,?,?,?,?,?,?,?,?)";
			     PreparedStatement pt=con.prepareStatement(query4);
			     pt.setInt(1,user_id);
			     pt.setString(2,cuisine);
			     pt.setString(3,food_type);
			     pt.setString(4,food_category);
			     pt.setLong(5,food_cost);
			     pt.setString(6,DJ);
			     pt.setString(7,stage);
			     pt.setString(8,speakers);
			     pt.setLong(9,total);
			     pt.setString(10,status);
			     pt.setString(11,feedback);
			     pt.executeUpdate();
			   }
		 }
		catch(InputMismatchException im)
		{
			im.printStackTrace();
		}
		catch(NumberFormatException ne)
		{
			System.out.println(ne);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}	
	}
}
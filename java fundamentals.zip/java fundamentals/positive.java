class Positive
{
   public static void main(String[] args)
   { 
    int a=Integer.parseInt(args[0]);
    System.out.println("Enter the number:"+a);
	if(a>0)
	{
		System.out.println("Number is positive");
	}
	else
	{
		System.out.println("Number is negative");
	}
   }
}   
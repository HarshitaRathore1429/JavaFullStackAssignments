import javax.swing.JOptionPane;
public class JOption extends JOptionPane
{
public static void main( String[] args )
{
String name = JOptionPane.showInputDialog( "Enter your Name:" );
JOptionPane.showMessageDialog(null, name);
}
}
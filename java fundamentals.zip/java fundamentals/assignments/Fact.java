class Fact
{
	public static void main(String[] args)
	{
		int a=Integer.parseInt(args[0]);
		int fact(a);
	    {
		  if(a>0);
		  {
			r=a*fact(a-1);
		  }
		  System.out.println(r);   
        }	 
	}
}
		
		
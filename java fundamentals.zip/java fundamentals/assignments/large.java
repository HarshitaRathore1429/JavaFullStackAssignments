class Largest
{
	public static void main(String[] args)
	{
		int a=Integer.parseInt(args[0]);
		int b=Integer.parseInt(args[1]);
		System.out.println("Enter number 1:"+a+"Enter number 2:"+b);
		if(a>b)
		{
			System.out.println("a is largest");
		}
		else
		{
			System.out.println("b is largest");
		}		
	}
}	
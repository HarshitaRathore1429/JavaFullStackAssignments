class Nprime
{
	public static void main(String[] args)
	{
		int n=Integer.parseInt(args[0]);
		int sum = 0;

        for(int j = 2; j <= n; j++)
		{

            int i;

            for(i = 2; i <= (j / 2); i++)
			{

                if(j% i == 0)
				{
                    i = j;
                    break;
                }
            }

            // If the number is prime then add it.
            if(i != j)
			{
                sum += j;            
            }
        }
		System.out.println("Sum is:" +sum);
	}
}
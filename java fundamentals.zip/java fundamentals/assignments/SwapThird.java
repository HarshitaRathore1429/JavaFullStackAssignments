class SwapThird
{
	public static void main(String[] args)
	{
		int a=Integer.parseInt(args[0]);
		int b=Integer.parseInt(args[1]);
		System.out.println("Numbers are:"+a+b);
		int temp;
		temp=a;
		a=b;
		b=temp;
		System.out.println("Swaped Numbers are:" +a+b);
	}
}	
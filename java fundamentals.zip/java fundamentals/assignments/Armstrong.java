class Armstrong
{
	public static void main(String[] args)
	{
		int a=Integer.parseInt(args[0]);
		int check,rem,sum=0;
		check=a;
		while(check!=0)
		{
			rem=check%10;
			sum=sum+(rem*rem*rem);
			check=check/10;
		}
		if(sum==a)
		{
			System.out.println("Number is Armstrong");
		}
		else
	    {
			System.out.println("Number is not Armstrong");
		}
	}
}
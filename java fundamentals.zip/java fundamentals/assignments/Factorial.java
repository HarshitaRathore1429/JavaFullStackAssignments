class Factorial
{
	public static void main(String[] args)
	{
		int a=Integer.parseInt(args[0]);
		int i;
		if(a>0)
		{
			for(i=a-1;i>0;i--)
			{
				a=a*i;
			}
		    System.out.println("Factorial is : "+a);
		}
	}
}
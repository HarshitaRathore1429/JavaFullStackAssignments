import java.util.HashSet;
import java.util.Iterator;
class HashSet1
{
	public static void main(String[] args)
	{
		HashSet<String> h=new HashSet<String>();
		h.add("Harshita");
		h.add("Nishita");
		h.add("Nipun");
		h.add("Samayak");
		h.add("Ram");
		Iterator i=h.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
	}
}
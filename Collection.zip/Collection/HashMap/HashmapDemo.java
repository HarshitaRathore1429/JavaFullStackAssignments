import java.util.*;
import java.util.Set;
import java.util.Map.Entry;
class HashmapDemo
{   static Map m=new HashMap();
	public static void sortkey()
	{
		ArrayList<Integer> a=new ArrayList<Integer>(m.keySet());
		Collections .sort(a);
		for (int x : a)
            System.out.println("Key = " +x+ ", Value = " + m.get(x));
	}
	public static void sortvalue()
	{
		 Set<Entry<Integer,String>> entries = m.entrySet();
		Comparator<Entry<Integer, String>> valueComparator = new Comparator<Entry<Integer,String>>() 
		{
            public int compare(Entry<Integer, String> e1, Entry<Integer, String> e2) {
                String v1 = e1.getValue();
                String v2 = e2.getValue();
                return v1.compareTo(v2);
            }
        };
        List<Entry<Integer, String>> listOfEntries  = new ArrayList<Entry<Integer, String>>(entries);
        Collections.sort(listOfEntries, valueComparator);       
        LinkedHashMap<Integer, String> sortedByValue = new LinkedHashMap<Integer, String>(listOfEntries.size());
        for(Entry<Integer, String> entry : listOfEntries){
            sortedByValue.put(entry.getKey(), entry.getValue());
        }
        
        System.out.println("HashMap after sorting entries by values ");
        Set<Entry<Integer, String>> entrySetSortedByValue = sortedByValue.entrySet();
        
        for(Entry<Integer, String> mapping : entrySetSortedByValue){
            System.out.println(mapping.getKey() + " ==> " + mapping.getValue());
        }
    }
	public static void main(String[] args)
	{
		m.put(11,"yash");
		m.put(33,"Technology");
		m.put(43,"Welcome");
		Set s=m.entrySet();//convert set to traverse
		Iterator i=s.iterator();
		while(i.hasNext())
		{
			Map.Entry entry =(Map.Entry)i.next();//value separation
			System.out.println("Key: "+entry.getKey()+" Value: "+entry.getValue());
		}
		/*Map<Integer,String> map=new HashMap<Integer,String>();
		map.put(11,"yash");
		map.put(33,"Technology");
		map.put(43,"Welcome");
		for(Map.Entry me:map.entrySet()) 
			System.out.println("Key: "+me.getKey()+" Value: "+me.getValue());*/
		System.out.println("Sorted by keys: ");
		sortkey();
		System.out.println("Sorted by value: ");
		sortvalue();
	}
}
import java.util.HashMap;
import java.util.Iterator;
class HashMap3
{
	public static void main(String[] args)
	{
		HashMap<String,String> ContactList =new HashMap<String,String>();
		ContactList.put("Harshita","987655432");
		ContactList.put("Khyati","1234567790");
		Iterator it=ContactList.keySet().iterator();
		while(it.hasNext())
		{
			String key=(String)it.next();
			System.out.println(key+" "+ContactList.get(key));
		}
		System.out.println(ContactList.containsKey("Harshi"));
		System.out.println(ContactList.containsValue("23223232"));
	}
}
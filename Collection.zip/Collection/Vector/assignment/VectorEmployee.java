import java.util.Vector;
import java.util.Iterator;
import java.util.Enumeration;
class Employee
{
	String name;
	int id;
	Employee(String name, int id)
	{
		this.name=name;
		this.id=id;
	}
	public String toString()
	{
		return name+" "+id;
	}
}
class VectorEmployee
{
	public static void main(String[] args)
	{
     Vector<Employee> e = new Vector<Employee>();
	 e.add(new Employee("Harshita",120));
	 Iterator i=e.iterator();
	 while(i.hasNext())
	 {
		System.out.println(i.next());
	 }
	 Enumeration en=e.elements();
	 while(en.hasMoreElements())
	 {
		 System.out.println(en.nextElement());
	 }
	}
}
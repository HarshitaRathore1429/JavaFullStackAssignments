import java.util.ArrayList;
class Numbers
{
	public static void main(String[] args)
	{
		ArrayList<Number> a=new ArrayList<>();
		a.add(10);
		a.add(1.1);
		a.add("Harshita");
		System.out.println(a);
	}
}
import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;
class ArraySum 
{
	public static void main(String[] args)
	{
		ArrayList<String> a=new ArrayList<String>();
		a.add("jan");
		a.add("feb");
		a.add("mar");
		a.add("apr");
		a.add("may");
		a.add("june");
		a.add("july");
		a.add("aug");
		a.add("sep");
		a.add("oct");
		a.add("nov");
		a.add("dec");
		System.out.println(a);
		for(String i:a)
		{
			System.out.println(i);
		}
		Iterator<String> i=a.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
		ListIterator li=a.listIterator();
		li.next();
		li.next();
		while(li.hasPrevious())
		{
			System.out.println(li.previous());
		}
		li.add("yash");
		System.out.println(a);
		li.set("Technologies");
		System.out.println(a);
	}
}
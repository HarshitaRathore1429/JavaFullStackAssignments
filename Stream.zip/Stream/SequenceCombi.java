import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.SequenceInputStream;
import java.io.File;
class SequenceCombi
{
	public static void main(String[] args) throws Exception
	{
		FileInputStream f1=new FileInputStream("C:/Users/Harshita.Rathore/Desktop/Java program/Stream/xyz.txt");
		FileInputStream f2=new FileInputStream("C:/Users/Harshita.Rathore/Desktop/Java program/Stream/abc.txt");
		FileOutputStream f=new FileOutputStream("C:/Users/Harshita.Rathore/Desktop/Java program/Stream/Combined.txt");
		SequenceInputStream st=new SequenceInputStream(f2,f1);
		int i;
		while((i=st.read())!=-1)
		{
			f.write(i);
		}
		st.close();
		f2.close();
		f1.close();
	}
}
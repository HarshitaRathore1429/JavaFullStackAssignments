import java.io.*;
import java.io.ObjectOutputStream;
import java.util.Scanner;
class Employee1 implements Serializable
{
	String name,department,designation;
	double salary;
	Employee1(String name,String department,String designation,double salary)
	{
		this.name=name;
		this.department=department;
		this.designation=designation;
		this.salary=salary;
	}
	public String toString()
	{
		return "name: "+name+" department: "+department+" designation:"+designation+" salary: "+salary;
	}
}
class ObjectStreamCons
{
	public static void main(String[] args)throws Exception
 	{   
	    Scanner sc=new Scanner(System.in);
		Employee1 e=new Employee1("harshita","Software","Junior",700000);
		System.out.println(e);
		File g=new File("C:/Users/Harshita.Rathore/Desktop/Java program/Stream/Yash1.txt");
	 	ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(g));
	    oos.writeObject(e);
	    ObjectInputStream ois=new ObjectInputStream(new FileInputStream(g));
	    Employee1 m=(Employee1)ois.readObject();
	    System.out.println(m);
	    oos.close();
	    ois.close();
	}
}
	
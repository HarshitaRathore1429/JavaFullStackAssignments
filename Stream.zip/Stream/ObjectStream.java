import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.*;
import java.io.IOException;
class Employee implements Serializable
{
	private String name,department,designation;
	private double salary;
	public void set(String name,String department,String designation,double salary)
	{
	  	this.name=name;
		this.department=department;
		this.designation=designation;
		this.salary=salary;
	}
	public String toString()
	{
		return "name: "+name+" department: "+department+" designation:"+designation+" salary: "+salary;
	}
}
class ObjectStream
{
	public static void main(String[] args)throws Exception
 	{
		Employee e=new Employee();
		e.set("harshita","Software","Junior",700000);
		System.out.println(e);
		File g=new File("C:/Users/Harshita.Rathore/Desktop/Java program/Stream/yash.txt");
	 	ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(g));
	    oos.writeObject(e);
	    ObjectInputStream ois=new ObjectInputStream(new FileInputStream(g));
	    Employee m=(Employee)ois.readObject();
	    System.out.println(m);
	    oos.close();
	    ois.close();
	}
}
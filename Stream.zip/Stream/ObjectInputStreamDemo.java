import java.io.*;
class EmployeeDemo implements Serializable
{
	int empId;
	String empName;
	EmployeeDemo(int empId, String empName)
	{
		this.empId=empId;
		this.empName=empName;
	}
	public String toString()
	{
		return empId+ " " +empName;
	}
}
class ObjectInputStreamDemo
{
	public static void main(String[] args) throws Exception
	{
		File f=new File("C:/Users/Harshita.Rathore/Desktop/Java program/Stream/xyz.txt");
		ObjectInputStream ois=new ObjectInputStream(new FileInputStream(f));
		EmployeeDemo e=(EmployeeDemo)ois.readObject();
		ois.close();
		System.out.println(e);
	}
}
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
class DataStream
{
	public static void main(String[] args)throws Exception
	{
		FileInputStream f=new FileInputStream("C:/Users/Harshita.Rathore/Desktop/Java program/Stream/xyz.txt");
		DataInputStream di=new DataInputStream(f);
		FileOutputStream fo=new FileOutputStream("C:/Users/Harshita.Rathore/Desktop/Java program/Stream/pqr.txt");
		DataOutputStream d=new DataOutputStream(fo);
		int i;
		while((i=di.read())!=-1)
		{   fo.write(i);
			System.out.println(i);
		}
		d.writeInt(65);
	}
}
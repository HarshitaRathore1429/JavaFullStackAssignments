import java.io.FileInputStream;
import java.io.ByteArrayInputStream;
import java.io.FileOutputStream;
import java.io.ByteArrayOutputStream;
class ByteArray
{
	public static void main(String[] args)throws Exception
  	{
		byte[] arr={65,67,68};
		ByteArrayInputStream ai=new ByteArrayInputStream(arr);
		FileOutputStream fo=new FileOutputStream("C:/Users/Harshita.Rathore/Desktop/Java program/Stream/abc.txt");
		ByteArrayOutputStream ao=new ByteArrayOutputStream();
		int i;
		while((i=ai.read())!=-1)
		{   fo.write(i);
			System.out.println(i);
	    }
	}
}
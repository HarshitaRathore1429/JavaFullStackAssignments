import java.io.FileOutputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.BufferedInputStream;
class BufferedOutputStreamDemo
{
	public static void main(String[] args)
	{   try
		{  
		  FileInputStream fin=new FileInputStream("C:/Users/Harshita.Rathore/Desktop/Java program/Stream/xyz.txt");
		  BufferedInputStream binput=new BufferedInputStream(fin);
		  FileOutputStream fout=new FileOutputStream("C:/Users/Harshita.Rathore/Desktop/Java program/Stream/abc.txt");
		  BufferedOutputStream boutput=new BufferedOutputStream(fout);
		  int c;
		  while((c=binput.read())!=-1)
		  {
			  boutput.write(c);
			System.out.println((char)c);
		  }
		  boutput.close();
          fout.close();
		}
        catch(Exception e)
        {
           e.printStackTrace();
        }
    }
} 	
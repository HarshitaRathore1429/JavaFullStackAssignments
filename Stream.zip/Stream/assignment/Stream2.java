import java.io.FileInputStream;
class Stream2
{
	public static void main(String[] args)throws Exception
	{
		FileInputStream i=new FileInputStream("C:/Users/Harshita.Rathore/Desktop/Java program/Stream/xyz.txt");
		int c,vcount=0,acount=0,ecount=0,icount=0,ocount=0,ucount=0;
		while((c=i.read())!=-1)
		{
			if((char)c=='a' || (char)c=='e' || (char)c=='i' || (char)c=='o' || (char)c=='u')
			{
               	vcount++;
			}
			if((char)c=='a')
			{
				acount++;
			}
			else if((char)c=='e')
			{
				ecount++;
			}
			else if((char)c=='i')
			{
				icount++;
			}
			else if ((char)c=='o')
			{
				ocount++;
			}
			else if((char)c=='u')
			{
				ucount++;
			}
		}
		System.out.println("Number of vowels:" +vcount+" Number of a:"+acount+" Number of e:"+ecount+" Number of i:"+icount+" Number of o: "+ocount+" Number of u: "+ucount);
	}
}
import java.io.FileInputStream;
import java.io.BufferedReader;
class Stream1
{
	public static void main(String[] args)throws Exception
	{
		FileInputStream f=new FileInputStream("C:/Users/Harshita.Rathore/Desktop/Java program/Stream/xyz.txt");
		int i,count=0;
		int space=0,words=0;
		while((i=f.read())!=-1)
		{   
			count=count+1;
			if((char)i == ' ')
			{
				space=space+1;
			}
		}
		System.out.println("Number of characters: "+count+" Number of space: "+space+" Number of words: "+(space+1));
    }
}
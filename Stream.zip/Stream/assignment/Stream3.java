import java.io.FileInputStream;
import java.util.Scanner;
class Stream3
{
	public static void main(String[] args)throws Exception
	{   Scanner s=new Scanner(System.in);
		FileInputStream f=new FileInputStream("C:/Users/Harshita.Rathore/Desktop/Java program/Stream/xyz.txt");
		System.out.println("Enter the character:");
		char c=s.next().charAt(0);
		String str="";
		int i,count=0;
		while((i=f.read())!=-1)
		{
			str +=(char)i;
		}
		for(int j=0;j<str.length();j++)
		{
          if(c == (str.charAt(j)))
		  {
            count++;
          }
		}
		System.out.println("Character "+c+" appeared "+count+" times in file");
	}
}
import java.io.FileOutputStream;
import java.io.BufferedOutputStream;
class BufferedOutputStreamDemo
{
	public static void main(String[] args)
	{   try
		{
		FileOutputStream fout=new FileOutputStream("c:/Users/Harshita.Rathore/Desktop/Java program/Stream/abc/txt");
		BufferedOutputStream boutput=new BufferedOutputStream(fout);
		int i;
		while((i=boutput.read())!=-1)
		{
			System.out.println((char)i);
		}
		boutput.close();
        fout.close();
		}
        catch(Exception e)
        {
           e.printStackTrace();
        }
    }
} 	
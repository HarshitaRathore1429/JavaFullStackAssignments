import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.*;
class Employee implements Serializable
{
	int empId;
	String empName;
	Employee(int empId, String empName)
	{
		this.empId=empId;
		this.empName=empName;
	}
	public String toString()
	{
		return empId+ " " +empName;
	}
}
class ObjectOutputStreamDemo
{
	public static void main(String[] args)throws Exception
	{
		Employee e= new Employee(20,"Harshita");
		System.out.println(e);
		File f=new File("C:/Users/Harshita.Rathore/Desktop/Java program/Stream/xyz.txt");
		ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(f));
		oos.writeObject(e);
		oos.close();
	}
}
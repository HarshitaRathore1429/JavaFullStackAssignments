class Outer
{   void display()
	{
		System.out.println("Outer show");
	}
	class Inner
	{
		void show()
		{
			System.out.println("Inner show");
		}
	}
}
public class OuterNon
{
	public static void main(String[] args)
	{
		Outer o=new Outer();
		OuterInner oi=new Inner();
		oi.show();
		oi.display();
		o.display();
	}
}
	
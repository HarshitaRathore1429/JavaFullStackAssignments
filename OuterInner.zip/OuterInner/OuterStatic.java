class Outer
{
	static class Inner
	{
		void show()
		{
			System.out.println("Outer Show");
		}
	}
}
public class OuterStatic
{
	public static void main(String[] args)
	{
		Outer.Inner oi=new Outer.Inner();
		oi.show();
	}
}
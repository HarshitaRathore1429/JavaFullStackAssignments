class Outer
{   void display()
	{
		System.out.println("Outer show");
	}
	protected class Inner
	{
		void show()
		{
			System.out.println("Inner show");
		}
	}
}
public class OuterNon
{
	public static void main(String[] args)
	{
		Outer o=new Outer();
		Outer.Inner oi=o.new Inner();
		oi.show();
		o.display();
	}
}
	
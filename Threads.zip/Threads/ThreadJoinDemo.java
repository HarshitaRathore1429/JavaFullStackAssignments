public class ThreadJoinDemo extends Thread{
	public void run()
	{
		try
		{
			for(int i=1;i<=3;i++)
			{
				System.out.println("run thread "+i);
				Thread.sleep(1000);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	public static void main(String[] args)throws Exception
	{
		ThreadJoinDemo td=new ThreadJoinDemo();
		td.start();
		td.join();
		try
		{
			for(int j=1;j<=3;j++)
			{
				System.out.println("Main thread: "+j);
				Thread.sleep(1000);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
class ThreadSleepDemo extends Thread{
	public void run()
	{
		for(int i=0;i<3;i++)
		{
		   try
		   {
			   Thread.sleep(2n);
			   System.out.println(Thread.currentThread().getName());
		   }
		   catch(Exception e)
		   {
			   e.printStackTrace();
		   }
		   System.out.println(i);
		}
	}
	public static void main(String[] args)
	{
		ThreadSleepDemo tsd=new ThreadSleepDemo();
		tsd.setName("Harshita");
		tsd.setPriority(5);
		tsd.start();
		ThreadSleepDemo ts=new ThreadSleepDemo();
		ts.setName("Rathore");
		ts.setPriority(10);
		ts.start();
	}
}
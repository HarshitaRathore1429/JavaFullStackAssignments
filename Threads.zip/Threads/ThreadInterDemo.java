class ThreadInterDemo extends Thread{
	public void run()
	{
		
		System.out.println(Thread.currentThread().isInterrupted());
		//System.out.println(Thread.currentThread().interrupted());
		try
		{
			for(int i=1;i<=3;i++)
			{
				System.out.println(i);
				System.out.println(Thread.currentThread().interrupted());
				sleep(100);
				//System.out.println(Thread.currentThread().isInterrupted());
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void main(String[] args)
	{
		ThreadInterDemo td=new ThreadInterDemo();
		System.out.println(Thread.currentThread().interrupted());
		td.start();
		td.interrupt();
	}
}
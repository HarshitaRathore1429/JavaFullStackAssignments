public class ThreadJoinMain extends Thread{
	static Thread t;
	public void run()
	{
		try
		{
		   t.join();
			for(int i=1;i<=3;i++)
			{
				System.out.println("run thread "+i);
				Thread.sleep(1000);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	public static void main(String[] args)throws Exception
	{
		t=Thread.currentThread();
		System.out.println("Main Thread");
		ThreadJoinMain tj=new ThreadJoinMain();
		tj.start();
		try
		{
			for(int j=1;j<=3;j++)
			{
				System.out.println("Main thread: "+j);
				Thread.sleep(1000);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
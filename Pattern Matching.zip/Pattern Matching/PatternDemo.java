import java.util.regex.*;
class PatternDemo
{
  public static void main(String args[])
  {
  System.out.println(Pattern.matches(".a", "sa"));
  System.out.println(Pattern.matches(".s", "mk"));
  System.out.println(Pattern.matches("...s", "mmms"));
  System.out.println(Pattern.matches(".t", "amms"));
  System.out.println(Pattern.matches("..s", "mas"));
  System.out.println(Pattern.matches("[amn]?", "a"));
  System.out.println(Pattern.matches("[amn]+", "aaa"));
  System.out.println(Pattern.matches("\\d", "1"));
System.out.println(Pattern.matches("\\d", "4443"));
  }
}
import java.util.Scanner;
class Extractdigit
{
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		String str=s.next();
		String digit=str.replaceAll("[^0-9]","");
		System.out.println(digit);
	}
}	
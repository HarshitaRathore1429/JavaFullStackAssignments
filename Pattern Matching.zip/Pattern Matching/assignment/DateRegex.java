class DateRegex
{
	public static void main(String[] args)
	{
		
	}
}n
import java.util.regex.Pattern;
import java.util.regex.Matcher;
class ExtractString
{
	public static void main(String[] args)
	{
		Pattern p=Pattern.compile("\\b\\w+@XYZ\\.com\\b");
		Matcher match=p.matcher("r@XYZ.com\n"+"hdf@XYZ.com\n"+"hjsd@XYZ");
		while(match.find())
		{
			System.out.println(match.group());
		}
		String pattern="(0/91)?[7-9][0-9]{9}";
	Pattern pa=Pattern.compile(pattern);
	String[] check={"9008854321","087821212"};
	for(String inputString :check)
	{
		System.out.print(inputString + ": "); 
		if (inputString.matches(pattern))
		{     
            System.out.println("Valid"); 
        }
		else
		{     
            System.out.println("Invalid"); 
        }
    }
	  String url="(http:|https:\\www.\\w+.com\\b)";
	  Pattern urlpa=Pattern.compile(url);
	  Matcher m=urlpa.matcher("https:www.harshita.com");
	  while(m.find())
	  {
		System.out.println(m.group());
	  }
    }
}
class RegexPrime
{
	public static void main(String[] args)
	{
		int n=10;
		String s=new String(new char[n]);
		boolean prime=s.matches(".{0,1}|(.{2,})\\1+");
		System.out.println(!prime);
	}
}
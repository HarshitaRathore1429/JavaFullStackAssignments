class SplitString
{
	public static void main(String[] args)
	{
		String text="Yash Technology is an It company"+ "\n"+" From 25 years";
		String[] result=text.split("\n");
		System.out.print("result = ");
        for (String str : result) {
         System.out.print(str + ", ");
        }
	}
}
package com.yash.springormjpa.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class App {
	public static void main(String[] args) {
		StudenDao s = new StudenDao();
		System.out.println("Hello World!");
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("put");
		EntityManager em = emf.createEntityManager();
		// System.out.println(s);
		s.setId(109);
		s.setName("Harshita");
		em.getTransaction().begin();
		em.persist(s);
		em.getTransaction().commit();
		System.out.println(s.toString());
	}
}

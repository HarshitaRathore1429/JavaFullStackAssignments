package springci;

import javax.annotation.Resource;

public class Employee {
	private String name;
	private int empid;
	@Resource(name = "mydept")
	private Department dept;

	public Employee(String name, int empid, Department dept) {
		super();
		this.name = name;
		this.empid = empid;
		this.dept = dept;
	}

	@Override
	public String toString() {
		return "Employee [name=" + name + ", empid=" + empid + ", dept=" + dept + "]";
	}
}

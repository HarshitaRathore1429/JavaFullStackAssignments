package springci;
public class Department {
private String deptname;

public Department(String deptname) {
	super();
	this.deptname = deptname;
}

@Override
public String toString() {
	return "Department [deptname=" + deptname + "]";
}

}


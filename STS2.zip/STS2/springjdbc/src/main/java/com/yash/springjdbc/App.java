package com.yash.springjdbc;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.yash.springjdbc.dao.StudentDao;
import com.yash.springjdbc.entities.Student;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		System.out.println("Hello User!");
		ApplicationContext context = new ClassPathXmlApplicationContext("com/yash/springjdbc/applicationcontext.xml");
		Scanner s = new Scanner(System.in);
		int id;
		String pass;
		System.out.print("Enter the login id:");
		id = s.nextInt();
		System.out.println("Enter the password");
		pass = s.next();
		if (id == 1 && pass.equals("admin"))
		{
			StudentDao stdao = context.getBean("StudentDao", StudentDao.class);
			System.out.println("Enter 1 for insert, 2 for update, 3 for delete, 4 for read");
			int choice = s.nextInt();
			int sid;
			Student st = new Student();
			String name;
			switch (choice)
			{
			case 1:
				System.out.println("Enter student id:");
				sid = s.nextInt();
				st.setId(sid);
				System.out.print("Enter name:");
				name = s.next();
				st.setName(name);
				int r = stdao.insert(st);
				System.out.println(r + "Student added Successfully ");
				break;
			case 2:
				System.out.println("Enter student id:");
				sid = s.nextInt();
				st.setId(sid);
				System.out.print("Enter name:");
				name = s.next();
				st.setName(name);
				int x = stdao.updatedetails(st);
				System.out.println(x + "Student updated successfully");
				break;
			case 3:
				System.out.println("Enter student id:");
				sid = s.nextInt();
				st.setId(sid);
				int y = stdao.deletedetails(sid);// delete the details
				System.out.println(y + "Student deleted Successfully ");
				break;
			case 4:
				List<Student> students = stdao.listStudents();
				for (Student record : students) {
					System.out.print("ID : " + record.getId());
					System.out.print(", Name : " + record.getName());}
				break;
			}
		} 
			else {
			System.out.println("Enter correct id and password");
		}
	}
	// s.setId(101);
	// s.setName("Yash");
	// int r = stdao.insert(s);
	// System.out.println(r + "Student added Successfully ");
	// int x=stdao.updatedetails(s);
	// System.out.println(x+"Student updated successfully");
	// int y=stdao.deletedetails(107);//delete the details
	// System.out.println(y + "Student deleted Successfully ");
	/*
	 * Student s=stdao.selectDetails(101); System.out.println(s);
	 * System.out.println("------Listing Multiple Records--------" ); List<Student>
	 * students = stdao.listStudents();
	 * 
	 * for (Student record : students) { System.out.print("ID : " + record.getId()
	 * ); System.out.print(", Name : " + record.getName() ); }
	 */
}

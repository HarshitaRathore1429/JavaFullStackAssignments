package springcollection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class App {

	public static void main(String[] args) {
		System.out.println("Welcome to Spring FirstApplication");
		ApplicationContext context=new ClassPathXmlApplicationContext("applicationcontext.xml");
		Datatype e=(Datatype) context.getBean("datacoll");
		System.out.println(e);
	}

}

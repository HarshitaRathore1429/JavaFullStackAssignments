package springfirstapp;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class App {
public static void main(String[] args)
{
	System.out.println("Welcome to Spring FirstApplication");
	ApplicationContext context=new ClassPathXmlApplicationContext("appplicationcontext.xml");
	Employee e=(Employee) context.getBean("employee");
	Employee e1=(Employee) context.getBean("employee1");
	System.out.println(e);
	System.out.println(e1);
}
}

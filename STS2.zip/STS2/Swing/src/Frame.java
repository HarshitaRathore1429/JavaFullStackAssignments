import javax.swing.*;
class Frame
{
	public static void main(String[] args)
	{
	    f=new JFrame();
		f.setSize(500,600);
		f=f.getDefaultCloseOperation();
		JButton b=new JButton("OK");
		b.setBounds(50,100,100,30);
		f.add(b);
		JTextField l=new JTextField("Harshita");
		l.setBounds(50,60,80,30);
		f.add(l);
		JTextArea area=new JTextArea("Welcome to Yash Technology");  
        area.setBounds(50,150, 200,200);  
        f.add(area);  
		JCheckBox checkBox1 = new JCheckBox("Done");  
        checkBox1.setBounds(200,100, 90,50);  
		f.add(checkBox1);
		f.setLayout(null);
		f.setVisible(true);
	}
}
class LargeSmall
{
	public static void main(String[] args)
	{
		int[] a= {1,3,2,15,10,4,13};
		int i;
		for(i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
			int temp=0;
			if(a[i]>a[i+1])
		    {
				temp=a[i];
				a[i]=a[i+1];
				a[i+1]=temp;
			}
			}
		}
		System.out.println("Largest number is:" +a[(a.length)-1]);
		System.out.println("Smallest number is: "+a[0]);
		
	}
}
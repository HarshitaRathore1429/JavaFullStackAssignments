class TwoNo
{
	public static void main(String[] args)
	{
		int[] a={2,1,5,7,19,12,10};
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				int temp=0;
				if(a[i]>a[j])
				{
				temp=a[i];
				a[i]=a[j];
				a[j]=temp;
				}
			}
		}
		for(int k:a)
		{
			System.out.println(k);
		}
		System.out.println("Two Largest numbers are: " +a[a.length-1]+", " +a[a.length-2]);
		System.out.println("Two Smallest numbers are: " +a[0]+", " +a[1]);
	}
}
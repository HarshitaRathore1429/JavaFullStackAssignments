class Array
{
	public static void main(String[] args)
	{
		int[] a={10,20,30};
		int[][] b={{1,2,3},{4,5,6}};
		int total=0,sum=0,count=0;
		for(int i:a)
		{
			total=total+i;
		}
		System.out.println("Sum is: " +total);
		System.out.println("Average is: " +(total/a.length));
		for(int jr[]:b)
	    {
			for(int j:jr)
			{
				sum=sum+j;
				count++;
			}
		}
			System.out.println("Sum of 2d array is: " +sum);
			System.out.println("Averge of 2d array is: "+(sum/count));
	}
}
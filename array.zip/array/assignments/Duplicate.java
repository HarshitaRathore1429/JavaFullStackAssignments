class Duplicate
{
	public static void main(String[] args)
	{
		int[]a ={12,30,15,16,30};
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
			int temp=0;
			if(a[i]>a[i+1])
		    {
				temp=a[i];
				a[i]=a[i+1];
				a[i+1]=temp;
			}
			}
		}
		int n=a.length;
		int j=0;
		for(int i=0;i<n-1;i++)
	    {
			if(a[i]!=a[i+1])
			{
				a[j++]=a[i];
			}
		}
		a[j++]=a[n-1];
		for(int i=0;i<j;i++)
		{
			System.out.println(a[i]);
		}
	}
}
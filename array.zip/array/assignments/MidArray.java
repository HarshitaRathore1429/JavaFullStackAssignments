class MidArray
{
	public static void main(String[] args)
	{
		int[] a={1,2,3};
		int[] b={4,5,6};
		int[] c;
		c=new int[2];
		c[0]=a[ (a.length/2)];
		c[1]=b[(b.length/2)];
		for(int k=0;k<2;k++)
		{
			System.out.println(c[k]);
		}
	}
}
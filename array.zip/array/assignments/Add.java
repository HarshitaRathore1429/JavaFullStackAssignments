class Add
{
	public static void main(String[] args)
	{
		int[] a={10,3,6,1,2,7,9};
		int t1=0,t2=0;
		for(int i=0;i<a.length;i++)
		{
			if(a[i]==6)
			{
				t1=i;
			}
			if(a[i]==7)
			{
				t2=i;
			}
		}
		int sum=0;
		for(int i=0;i<t1;i++)
		{
			sum+=a[i];
		}
		for(int i=t2+1;i<a.length;i++)
		{
			sum+=a[i];
		}
		System.out.println(sum);
	}
}
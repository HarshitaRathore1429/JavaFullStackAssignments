class CheckNo
{
	public static void main(String[] args)
	{
		int a= Integer.parseInt(args[0]);
		int[] b={1,3,2,20,45,22};
		for(int i=0;i<b.length;i++)
		{
			if(a!=b[i])
			{
				continue;
			}
		else if(a==b[i]){
			System.out.println("Number is present at " +(i+1));
				break;
		}
		else{
	     System.out.println("-1");
		}
		}
	}
}
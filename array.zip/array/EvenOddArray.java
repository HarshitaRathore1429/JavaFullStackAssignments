class EvenOddArray
{
	public static void main(String[] args)
	{
		int[] a={1,0,1,0,0,1,1};
		for(int i=0;i<a.length;i++)
		{
			for( int j=i+1;j<a.length;j++)
			{ 
		      int temp;
			  if(a[i]%2!=0 && a[j]%2==0)
			  {
				  temp=a[i];
				  a[i]=a[j];
				  a[j]=temp;
			  }
			}
		}
		for(int k:a)
		{
			System.out.println(k);
		}
	}
}
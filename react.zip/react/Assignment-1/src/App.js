import Logo from './views/Logo';
import Bigimg from './views/Bigimg';
import Content1 from './views/Content1';
import Content2 from './views/Content2';
import Navmenu from './views/Navmenu';
import Queryform from './Queryform';
import './App.css';

function App()
{
  return(
    <div className='wrapper'>
      <div className='img'>
       <Logo />
       <Navmenu />
       <Queryform />
      </div> 
      <div className='content'>
        <Bigimg />
        <Content1 />
        <Content2 />
      </div>
    </div>
  );
}
export default App;
import React,{Component} from "react";
class Content1 extends Component
{
    render()
    {
        return(
            <div className="content1">
                This is content1 area
            </div>
        );
    }
}
export default Content1
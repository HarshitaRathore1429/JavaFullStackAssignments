import React,{Component} from "react";
class Bigimg extends Component
{
    render()
    {
        return(
          <div className="bigimage">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSShGrK9oDE8C5mEEvgCs3GP_7lFXpIYpEbjA&usqp=CAU" width="600px" height="150px"></img>
          </div>  
        );
    }
}
export default Bigimg
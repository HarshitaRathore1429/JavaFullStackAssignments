import React,{Component} from "react";
class Logo extends Component
{
    render()
    {
        return(
          <div className="image">
          <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSShGrK9oDE8C5mEEvgCs3GP_7lFXpIYpEbjA&usqp=CAU" height="135px" />
          </div>  
        );
    }
}
export default Logo
import React,{Component} from 'react';
import { BrowserRouter as Router,Routes, Route, Link } from 'react-router-dom';
import Home from './views/Home';
import About from './views/About';
import './App.css';

class App extends Component {
  render()
{
  return (
    <Router>
           <div className="App">
            <ul>
              <li>
                <Link className="App-header" to="/">Home</Link>
              </li>
              <li>
                <Link className="App-header" to="/about">About Us</Link>
              </li>
            </ul>
           <Routes>
                 <Route path='/' element={< Home />}></Route>
                 <Route path='/about' element={< About />}></Route>
          </Routes>
          </div>
       </Router>
  );
}
}
export default App;

import React,{Component} from 'react';
class About extends Component
{
    render()
    {
        return(
            <div className='about'>
                <h1>About</h1>
                <p>This is the about us page</p>
            </div>           
        );
    }
}
export default About
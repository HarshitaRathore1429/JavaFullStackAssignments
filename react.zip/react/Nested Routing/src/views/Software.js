import React,{Component} from "react";
class Software extends Component
{
    render()
    {
        return(
            <div className="software">
                <p>The company provide solution to business requirment using softwares</p>
            </div>
        );
    }
}
export default Software
import React,{Component} from "react";
class Home extends Component{
    render()
    {
        return(
            <div className="home">
                <p>This is the home page</p>
            </div>
        );
    }
}
export default Home
import React,{Component} from 'react';
class Login extends Component
{
    render()
    {
        return(
            <div className='loginform'>
               <form>
                <h1>Login Form</h1>
                <label>UserName</label><br></br>
                <input type="text" placeholder='Enter your name here' /><br></br>
                <label>Password</label><br></br>
                <input type="password" placeholder='Enter your password' /><br></br>
                <input type="submit" value="Login" />
                </form> 
            </div>

        );
    }
}
export default Login

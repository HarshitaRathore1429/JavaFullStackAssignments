
import React, {Component} from 'react';
class Testimonials extends Component
{
  render()
  {
    return (
        <div className='testimonials'>
            <ul>
            <li>The best place to work ranked again in 2022</li>          

            </ul>
        </div>

    );
  }
}
export default Testimonials
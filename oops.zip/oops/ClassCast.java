class Organization
{
	String orgname;
	Organization(String orgname)
	{  
      this.orgname = orgname;  
    }  
    void show() 
	{  
     System.out.println("This is organization");  
    }  
}  
class Employee extends Organization
{   String empname;
    Employee(String empname)
	{  
       super(empname);  
	   this.empname=empname;
    }  
    void show()
	{  
     System.out.println("This is Employee");  
    }  
}    
class Main 
{  
     public static void main(String[] args) 
	 {    
     Organization org = new Organization("Yash");  
	 Employee emp = new Employee("Harshita"); 
     org = emp;    
	 org.show();
     Organization org1 = new Organization("Technologies");  
     Employee e = (Employee)org1;  
}  
}
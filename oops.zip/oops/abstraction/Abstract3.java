import java .util.Random;
abstract class Compartment
{
	abstract String notice();
}
class FirstClass extends Compartment
{
   String notice()
   { 
     String s="FirstClass";
     return s;
   }	 
}
class Ladies extends Compartment
{
	String notice()
	{    String s1="Ladies";
		return s1;
	}
}
class General extends Compartment
{
	String notice()
	{    String s2="General";
		 return s2;
	}
}
class Luggage extends Compartment
{
	String notice()
	{    String s3="Luggage";
		 return s3;
	}
}
class TestCompartment 
{
	public static void main(String[] args)
	{
		Compartment a[]=new Compartment[10];
		Random r=new Random();
		for(int i=0;i<10;i++)
		{ 
	      int x=r.nextInt(4);
		  if(x==0)
		  {
			  a[i]=new FirstClass();
		  }
		  else if(x==1)
		  {
			  a[i]=new Ladies();
		  }
		  else if(x==2)
		  {
			  a[i]=new General();
		  }
		  else if(x==3)
		  {
			  a[i]=new Luggage();
		  }
		  System.out.println(a[i].notice());
		}
	}
}
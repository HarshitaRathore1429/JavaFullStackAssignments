abstract class Food
{
	abstract void use();
}
class Indian extends Food
{
	void use()
	{
		System.out.println("Indian ingredients are used");
	}
}
class Chinese extends Food
{
	void use()
	{
		System.out.println("Chinese ingredients are used");
	}
	public static void main(String[] args)
	{
		Indian i=new Indian();
		Chinese c=new Chinese();
		i.use();
		c.use();
	}
}
abstract class GeneralBank
{
   abstract void getSavingsInterestRate();
   abstract void getFixedDepositInterestRate();
}
class ICICBank extends GeneralBank
{
	void getSavingsInterestRate()
	{
		System.out.println("Saving rate is 4%");
	}
	void getFixedDepositInterestRate()
	{
		System.out.println("Fixed deposit rate is 8.5%");
	}
}
class SBIBank extends GeneralBank
{
	void getSavingsInterestRate()
	{
		System.out.println("Saving rate is 4%");
	}
	void getFixedDepositInterestRate()
	{
		System.out.println("Fixed deposit rate is 7%");
	}
}
class Abstract2
{
	public static void main(String[] args)
	{
		ICICBank i=new ICICBank();
		SBIBank s=new SBIBank();
		GeneralBank g=new SBIBank();
		GeneralBank f=new ICICBank();
		i.getSavingsInterestRate();
		i.getFixedDepositInterestRate();
		s.getFixedDepositInterestRate();
		s.getSavingsInterestRate();
		g.getFixedDepositInterestRate();
		f.getFixedDepositInterestRate();
		
	}
}
class Fruit
{
 public String name , size;
 void eat()
 {	
  System.out.println("Fruit class");
 }
}
class Apple  extends Fruit 
{
  Apple(String name , String size)
  {
  this.name=name;
  this.size=size;
  }
  void eat()
  {
	System.out.println("Apple class");
    System.out.println(name);
    System.out.println(size);
  }
}

class  Orange extends Fruit
 {
   Orange(String name , String size)
  {
   this.name=name;
   this.size=size;
  }
   void eat()
   {
    System.out.println("Orange class");	
    System.out.println(name);
    System.out.println(size);
   }
   public static void main(String[]jaj args)
   {
   Orange o = new Orange("Orange ", "Small");
   Apple a = new Apple("Apple ","Medium");
   o.eat();
   a.eat();
   Fruit f = new Fruit(); 
   f.eat();
   }
}
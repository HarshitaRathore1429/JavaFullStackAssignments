class Parent
{
	String display(String s)
	{
		System.out.println("Child Class");
		return s;
	}
}
class Child extends Parent
{
	 private Object display(Object ob)
	{
		System.out.println("Parent Class");
		return ob;
	}
	public static void main(String[] args)
	{
		Parent p=new Parent();
		Parent c=new Child();
		c.display("jaynam");
		p.display("jay");
	}
}
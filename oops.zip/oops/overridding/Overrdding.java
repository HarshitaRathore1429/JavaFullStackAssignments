class Parent
{
	void display()
	{
		System.out.println("Parent Class")
	}
}
class Child 
{
	void display()
	{
		System.out.println("Child Class");
	}
	public static void main(String[] args)
	{
		Child c=new Child();
		c.display();
	}
}
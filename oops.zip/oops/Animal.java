class Animal
{
	void eat()
	{
		System.out.println("I am eating");
	}
	public static void main(String[] args)
	{
		System.out.println("Hello");
		Animal sheru= new Animal();
		sheru.eat();
		Birds b1=new Birds();
		b1.fly();
		
	}
}
class Birds
{
	void fly()
	{
		System.out.println("I am flying");
	}
}
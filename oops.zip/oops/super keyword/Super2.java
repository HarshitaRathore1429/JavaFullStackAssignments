class Bank
{
	void name()
	{
		System.out.println("This is bank name");
	}
}
class Super2 extends Bank
{
	void name()
	{
		System.out.println("This is customer name");
	}
	void display()
	{
		super.name();
		name();
	}
	public static void main(String[] args)
	{
		Super2 s=new Super2();
		s.display();
	}
}
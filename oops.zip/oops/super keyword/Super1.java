class Employee
{
	String name="Trainee";
}
class Promotion extends Employee
{
	String name="Junior Engineer";
	void show(String name)
	{
		System.out.println(super.name);
		System.out.println(this.name);
		System.out.println(name);
	}
     public static void main(String[] args)
	 {
		 Promotion p=new Promotion();
		 p.show("Senior Engineer");
	 }
}
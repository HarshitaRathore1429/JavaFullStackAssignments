class Pen
{
	Pen()
	{
		System.out.println("This is pen");
	}
}
class Bluepen extends Pen
{
	Bluepen()
	{
		System.out.println("This is bluepen");
	}
	public static void main(String[] args)
	{
		Bluepen b=new Bluepen();
	}
}
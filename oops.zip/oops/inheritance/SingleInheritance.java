class A
{
	void show()
	{
		System.out.println("This is the parent class");
	}
}
class SingleInheritance extends A
{
	void display()
	{
		System.out.println("This is extended class");
	}
	public static void main(String[] args)
	{
		SingleInheritance s= new SingleInheritance();
		s.show();
		s.display();
	}
}
		
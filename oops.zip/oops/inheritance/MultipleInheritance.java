interface College
{
	void showCollege();
}
interface Subjects
{
	void showSubjects();
}
class Teacher implements College,Subjects
{   
	public void showCollege()
	{
	  	System.out.println("Teacher is in college");
	}	
	public void showSubjects()
	{
		System.out.println("Teacher teaches subject");
	}
	public static void main(String[] args)
	{
		Teacher t=new Teacher();
		t.showCollege();
		t.showSubjects();
	}
}
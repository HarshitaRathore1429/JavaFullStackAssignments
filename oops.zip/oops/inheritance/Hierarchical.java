class Employee
{
	void show()
	{
		System.out.println("New employee");
	}
}
class Engineer extends Employee
{
	void say()
	{
		System.out.println("Trainee");
	}
}
class Marketing extends Employee
{
	void display()
	{
		System.out.println("Marketing field");
	}
	public static void main(String[] args)
	{
		Engineer e=new Engineer();
		e.show();
		e.say();
		Marketing m=new Marketing();
		m.show();
		m.display();
	}
}
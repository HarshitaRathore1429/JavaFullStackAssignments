class Parent
{
	void parent()
	{
		System.out.println("This is the parent class method");
	}
}
class Child1 extends Parent
{
	void child1()
	{
		System.out.println("This is child1");
	}
}
class Child2 extends Child1
{
	void child2()
	{
		System.out.println("This is child2");
	}
	public static void main(String[] args)
	{
		Child1 c1=new Child1();
		c1.parent();
		c1.child1();
		Child2 c2=new Child2();
		c2.child1();
		c2.child2();
	}
}
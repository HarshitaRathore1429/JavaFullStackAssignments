class Person
{
	String name,dateOfBirth;
	Person(String name, String dateOfBirth)
	{
		this.name=name;
		this.dateOfBirth=dateOfBirth;
	}
}
class Teacher extends Person
{
	int salary;
	String subject;
	Teacher(String name,String dateOfBirth, int salary, String subject)
	{
		super(name,dateOfBirth);
		this.salary=salary;
		this.subject=subject;
	}
}
class Student extends Person
{
	int studentId;
	Student(String name, String dateOfBirth, int studentId)
	{
		super(name,dateOfBirth);
		this.studentId=studentId;
	}
}
class CollegeStudent extends Student
{
	String collegeName,year;
	CollegeStudent(String name, String dateOfBirth, int studentId, String collegeName, String year)
	{
	 super(name,dateOfBirth,studentId);
     this.collegeName=collegeName;
     this.year=year;	 
	}
	void display()
	{
		System.out.println("Name :" +name+ " dateOfBirth: "+dateOfBirth+ " studentId:  " +studentId+ " collegeName: "+collegeName+ " year:" +year);
	}
}
class Inheritance2
{
	public static void main(String[] args)
	{
		Person p=new Person("harshita","29-1-2001");
		Teacher t=new Teacher("Sikha","23-9-2018",2000000,"ds");
		Student s=new Student("Mansi","30-12-2014",101);
		CollegeStudent cs=new CollegeStudent("harshi","28-4-2013", 122,"mediacaps","fourth");
		cs.display();
	
		
	}
}
		
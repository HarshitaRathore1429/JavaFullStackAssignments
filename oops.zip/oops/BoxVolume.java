class BoxVolume
{
	int width;
	int height;
	int depth;
	BoxVolume(int w,int h,int d)
	{
		width=w;
		height=h;
		depth=d;
	}
		void VolumeBox()
		{
		  System.out.println("Volume is "+(width*height*depth));
		}
	public static void main(String[] args)
	{
		BoxVolume b=new BoxVolume(10,5,10);
		b.VolumeBox();
	}
}
import java.util.Scanner;
class Author
{
	private String authname,email;
	private char gender;
	Author(String authname, String email, char gender)
   {
        this.authname=authname;
		this.email=email;
		this.gender=gender;	 
   }
   public String tostring()
   {
	   return " Author name: "+ authname+" Email_id: "+email+"Gender: " +gender;
   }
}
class Book 
{		
	private String bookname;
	private double price;
	private int qtyInStock;
	Author author;
	Book(String bookname,Author author,double price, int qtyInStock )
    {    
		this.bookname=bookname;
		this.author=author;
		this.price=price;
		this.qtyInStock=qtyInStock;
    }
	void display()
    {
		System.out.println(" Bookname:" +bookname+ " Price: " +price+ " Quantity in Stock: " +qtyInStock+ " Author details: "+ author.tostring());
	}
}
class EncapsulationBook
{
	public static void main(String[] args)
	{   Author a=new Author("Rahul","rahul@gmail.com",'M');
	    Book b=new Book("Rise and Shine",a,3000, 3);
		b.display();
		
	}
}
	
	
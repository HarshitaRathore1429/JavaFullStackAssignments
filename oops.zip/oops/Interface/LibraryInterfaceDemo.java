interface LibraryUser
{
	void registerAccount();
	void requestBook();
}
class KidsUser implements LibraryUser
{
	int age;
	String bookType;
	public void setdetails(int age, String bookType)
	{
		this.age=age;
		this.bookType=bookType;
	}
	public void registerAccount()
	{
		if(age<12)
		{
			System.out.println("You have successfully registered under a Kids Account");
		}
		else if(age>12)
		{
			System.out.println("Sorry, age must be less than 12 to register as a kid");
		}
	}
	public void requestBook()
	{
		if(bookType.equals("Kids") && age<12)
		{
			System.out.println("Book issued successfully, please return the book within 10 days");
		}
		else
		{
			System.out.println("Oops, you are not allowed to take only kids book");
		}
	}
}
class AdultUser implements LibraryUser
{
	int age;
	String bookType;
	public void setdetails(int age, String bookType)
	{
		this.age=age;
		this.bookType=bookType;
	}
	public void registerAccount()
	{
		if(age>12)
		{
			System.out.println("You have successfully registered under a Adult Account");
		}
		else if(age<12)
		{
			System.out.println("Sorry, age must be greater than 12 to register as a adult");
		}
	}
	public void requestBook()
	{
		if(bookType.equals("Fiction"))
		{
			System.out.println("Book issued successfully, please return the book within 7 days");
		}
		else
		{
			System.out.println("Oops, you are allowed to take only adult Fiction book");
		}
	}
}
class LibraryInterfaceDemo
{ 
   public static void main(String[] args)
   {
	   KidsUser k=new KidsUser();
	   k.setdetails(20,"Kids");
	   k.registerAccount();
	   k.requestBook();
	   AdultUser a=new AdultUser();
	   a.setdetails(24,"Kids");
	   a.registerAccount();
	   a.requestBook();
   }
}
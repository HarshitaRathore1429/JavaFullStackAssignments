class Constructor
{
	Constructor()
	{
		System.out.println("This is user defined constructor");
	}
	String name;
	int emp_id;
	Constructor(String name, int emp_id)
	{
		this.name=name;
		this.emp_id=emp_id;
	}
	void display()
	{
	  System.out.println(name+ " "+ emp_id);	  
	}
	public static void main(String[] args)
	{
		Constructor n= new Constructor("Harshita", 1012);
		Constructor c= new Constructor();
		n.display();
	}
}
class ThisDemo4
{   void release(ThisDemo4 n)
	{
	System.out.println("The data is released");
	}
	void processed()
	{
		release(this);
	}
	public static void main(String[] args)
	{
	ThisDemo4 n=new ThisDemo4();
	n.processed();
	}
}
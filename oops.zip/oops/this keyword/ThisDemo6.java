class ThisDemo6
{
	String name;
	int id;
	ThisDemo6()
	{
		name="Harshita";
		id=101;
	}
	ThisDemo6 get()
	{
		return this;
	}
	void show()
	{
		System.out.println("Name is " +name+ " and id is "+id);
	}
	public static void main(String[] args)
	{
	  ThisDemo6 t=new ThisDemo6();
      t.get().show();	  
	}
}
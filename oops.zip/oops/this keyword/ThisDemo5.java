class ThisDemo51
{
  ThisDemo5 obj;
  ThisDemo51(ThisDemo5 obj)
  {
  this.obj=obj;
  }	
  void display()
  {
	System.out.println(obj.value);
  }
}
class ThisDemo5
{ 
  int value=12;
  ThisDemo5()
  {
	ThisDemo51 n=new ThisDemo51(this);
	n.display();
  }
  public static void main(String[] args)
  {
	ThisDemo5 ne= new ThisDemo5();
  }
}

class ThisDemo2
{
	void data()
	{
		System.out.println("The data is of employee here");
	}
	void show()
	{
		data();
	}
  public static void main(String[] args)
  {
		ThisDemo2 t =new ThisDemo2();
		t.show();
  }
}
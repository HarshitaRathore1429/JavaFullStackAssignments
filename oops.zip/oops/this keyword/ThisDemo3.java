class ThisDemo3
{
	ThisDemo3()
	{
	System.out.println("The employee is trainee");
	}
	ThisDemo3(int a)
	{  this();
		System.out.println("The employee training is on java");
	}
	public static void main(String[] args)
	{
		ThisDemo3 n=new ThisDemo3(101);
	}
}
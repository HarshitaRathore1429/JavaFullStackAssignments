class PatientInfo
{
	String name;
	double height;
	double weight;
	PatientInfo(String n, double h, double w)
	{
	  name=n;
      height=h;
      weight=w;	  
	}	
	void computeBMI()
	{
		System.out.println("BMI is "+((weight/height)*height));
	}	
	public static void main(String[] args)
	{
		PatientInfo p=new PatientInfo("Harshita",7,50);
		p.computeBMI();
	}
}
import org.hibernate.*;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class Store {
	public static void main(String[] args) {

		try {
			StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernet.cfg.xml").build();
			Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();
			SessionFactory factory = meta.getSessionFactoryBuilder().build();
			Session session = factory.openSession();
			Transaction t = session.beginTransaction();
			Employee e1 = new Employee();
			e1.setName("Harshita Rathore");
			e1.setEmail("rathoreharshita@gmail.com");
			Address address1 = new Address();
			address1.setAddressRoad("65-B,Mangal nagar");
			address1.setCity("Indore");
			address1.setState("Mp");
			e1.setAddress(address1);
			address1.setEmployee(e1);
			session.persist(e1);
			t.commit();
			session.close();
			System.out.println("success");
		} catch (Throwable ex) {
			System.err.println("Failed to create sessionFactory object." + ex);
			throw new ExceptionInInitializerError(ex);
		}
	}
}

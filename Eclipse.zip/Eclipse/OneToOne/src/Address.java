public class Address {
	private int addressid;  
	private String addressRoad,city,state; 
	private Employee employee;  
	public int getAddressid()
	{
		return addressid;
	}
	public void setAddressid(int addressid)
	{
		this.addressid=addressid;
	}
	public String getAddressRoad()
	{
		return addressRoad;
	}
	public void setAddressRoad(String addressRoad)
	{
		this.addressRoad=addressRoad;
	}
	public String getCity()
	{
		return city;
	}
	public void setCity(String city)
	{
		this.city=city;
	}
	public String getState()
	{
		return state;
	}
	public void setState(String state)
	{
		this.state=state;
	}
	public Employee getEmployee()
	{
		return employee;
	}
	public void setEmployee(Employee employee)
	{
		this.employee=employee;
	}
}


public class Employee {
private int employeeid;
private String name,email;
private Address address;
public int getEmployeeid() {
	return employeeid;
}
public void setEmployeeid(int employeeid)
{
	this.employeeid=employeeid;
}
public String getName()
{
	return name;
}
public void setName(String name)
{
	this.name=name;
}
public String getEmail()
{
	return email;
}
public void setEmail(String email)
{
	this.email=email;
}
public void setAddress(Address address)
{
	this.address=address;
}
public Address getAddress()
{
	return address;
}
}

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ViewServlet
 */
@WebServlet("/ViewServlet")
public class ViewServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");  
        PrintWriter out=response.getWriter();  
        out.print("<style>");
        out.print("nav a{");
        out.print("padding:10px;");
        out.print("text-decoration:none;");
	    out.print("}");
	    out.print("nav{");
        out.print("text-align:center");
        out.print("}");
        out.print("body{");
        out.print("background-color: #DCDCDC;");
        out.print("}");
        out.print("td a{");
        out.print("color:blue;");
        out.print("text-decoration:none;");
        out.print("}");
        out.print("</style>");
        out.print("<nav>");
        out.print("<a href='index1.html'>Home</a>");
        out.print("<a href='filldetails.html'>Save details</a>");
        out.print("<a href='ViewServlet'>View Students</a>");
        out.print("<a href='LogoutServlet'>Logout</a>");
        out.print("</nav>"); 
        out.print("<h1>All Student Details</h1>");
        List<Details> list=DetailsCon.getAllDetails();
        out.print("<table border='1' widht='100%'");
        out.print("<tr><th>Student_id</th><th>Username</th><th>Gender</th><th>Email</th><th>Department</th><th>Semester</th><th>Password</th><th>Edit</th><th>Delete</th></tr>");
        for (Details d:list)
        {
        	out.print("<tr><td>"+d.getStudent_id()+"</td><td>"+d.getUsername()+"</td><td>"+d.getGender()+"</td><td>"+d.getEmail()+"</td><td>"+d.getDepartment()+"</td><td>"+d.getSemester()+"</td><td>"+d.getPassword()+"</td><td><a href='EditServlet?id="+d.getStudent_id()+"'>edit</a></td><td><a href='DeleteServlet?id="+d.getStudent_id()+"'>delete</a></td></tr>");
        }
        out.print("</table>");
        
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

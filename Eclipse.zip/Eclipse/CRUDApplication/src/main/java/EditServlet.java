

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EditServlet
 */
@WebServlet("/EditServlet")
public class EditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");  
        PrintWriter out=response.getWriter();  
        String id=request.getParameter("id");
        Details d=DetailsCon.getDetailsbyId(id);
        out.print("<form action='EditServlet1' method='post'>");
        out.print("<table>");
        out.print("<tr><td></td><td><input type='hidden' name='student_id' value='"+d.getStudent_id()+"'/></td></tr>");
        out.print("<tr><td>Username</td><td><input type='text' name='username' value='"+d.getUsername()+"'/></td></tr>");
        out.print("<tr><td>Gender</td><td><input type='text' name='gender' value='"+d.getGender()+"'/></td></tr>");
        out.print("<tr><td>Email</td><td><input type='email' name='email' value='"+d.getEmail()+"'/></td></tr>");
        out.print("<tr><td>Department</td><td><input type='text' name='department' value='"+d.getDepartment()+"'/></td></tr>");
        out.print("<tr><td>Semester</td><td><input type='text' name='semester' value='"+d.getSemester()+"'/></td></tr>");
        out.print("</table>");
        out.print("<input type='submit' value='Edit & Save'/>");
	    out.print("</form>");
	    out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

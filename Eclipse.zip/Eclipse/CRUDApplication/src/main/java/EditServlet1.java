

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EditServlet1
 */
@WebServlet("/EditServlet1")
public class EditServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");  
        PrintWriter out=response.getWriter();  
        out.println("<h1>Update Details</h1>"); 
        String id=request.getParameter("student_id");
        String username=request.getParameter("username");
        String gender=request.getParameter("gender");
        String email=request.getParameter("email");
        String department=request.getParameter("department");
        String semester =request.getParameter("semester");
        String password=request.getParameter("password");
        Details d=new Details();
        d.setStudent_id(id);
        d.setUsername(username);
        d.setGender(gender);
        d.setEmail(email);
        d.setDepartment(department);
        d.setSemester(semester);
        d.setPassword(password);
        int status=DetailsCon.update(d);
        if(status>0)
        {
        	response.sendRedirect("ViewServlet");
        }
        else
        {
        	out.print("Unable to update record!");
        }
        out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

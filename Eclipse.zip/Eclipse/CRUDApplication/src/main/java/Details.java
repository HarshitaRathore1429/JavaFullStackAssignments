public class Details {
private String username,gender,email,student_id,department,semester,password;

public String getUsername()
{
	return username;
}
public void setUsername(String username)
{
	this.username=username;
}
public String getEmail()
{
	return email;
}
public void setEmail(String email)
{
	this.email=email;
}
public String getGender()
{
	return gender;
}
public void setGender(String gender)
{
	this.gender=gender;
}
public String getStudent_id()
{
	return student_id;
}
public void setStudent_id(String student_id)
{
	this.student_id=student_id;
}
public String getDepartment()
{
	return department;
}
public void setDepartment(String department)
{
	this.department=department;
}
public String getSemester()
{
	return semester;
}
public void setSemester(String semester)
{
	this.semester=semester;
}
public String getPassword()
{
	return password;
}
public void setPassword(String password)
{
	this.password=password;
}
}

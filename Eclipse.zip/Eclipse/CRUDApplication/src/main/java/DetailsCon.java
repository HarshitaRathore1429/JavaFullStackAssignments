import java.util.*;
import java.sql.*;

public class DetailsCon {
	public static Connection getConnect() {
		Connection con=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/harshita","root","root");
		} catch (Exception e) {
			System.out.print(e);
		}
		return con;
	}

	public static int save(Details d) {
		int status = 0;
		try {
			Connection con = DetailsCon.getConnect();
			PreparedStatement ps = con.prepareStatement(
					"Insert into details(student_id,username,gender,email,department,semester,password) values(?,?,?,?,?,?,md5(?))");
			ps.setString(1, d.getStudent_id());
			ps.setString(2, d.getUsername());
			ps.setString(3, d.getGender());
			ps.setString(4, d.getEmail());
			ps.setString(5, d.getDepartment());
			ps.setString(6, d.getSemester());
			ps.setString(7, d.getPassword());
			status = ps.executeUpdate();
			con.close();
		} catch (Exception e) {
			System.out.print(e);
		}
		return status;
	}

	public static int update(Details d) {
		int status = 0;
		try {

			Connection con = DetailsCon.getConnect();
			PreparedStatement ps = con.prepareStatement(
					"update details set username=?, gender=?,email=?,department=?,semester=? password=md5(?) where student_id=?");
			ps.setString(1, d.getUsername());
			ps.setString(2, d.getGender());
			ps.setString(3, d.getEmail());
			ps.setString(4, d.getDepartment());
			ps.setString(5, d.getSemester());
			ps.setString(6, d.getStudent_id());
			ps.setString(7, d.getPassword());
			status = ps.executeUpdate();
			con.close();
		} catch (Exception e) {
			System.out.print(e);
		}
		return status;
	}

	public static int delete(String student_id) {
		int status = 0;
		try {
			Connection con = DetailsCon.getConnect();
			PreparedStatement ps = con.prepareStatement("delete from details where student_id=?");
			ps.setString(1, student_id);
			status = ps.executeUpdate();
			con.close();
		} catch (Exception e) {
			System.out.print(e);
		}
		return status;
	}

	public static Details getDetailsbyId(String student_id) {
		Details d = new Details();
		try {
			Connection con = DetailsCon.getConnect();
			PreparedStatement ps = con.prepareStatement("Select * from details where student_id=?");
			ps.setString(1, student_id);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				d.setStudent_id(rs.getString(1));
				d.setUsername(rs.getString(2));
				d.setGender(rs.getString(3));
				d.setEmail(rs.getString(4));
				d.setDepartment(rs.getString(5));
				d.setSemester(rs.getString(6));
				d.setPassword(rs.getString(7));
			}
			con.close();
		} catch (Exception e) {
			System.out.print(e);
		}
		return d;
	}

	public static List<Details> getAllDetails() {
		List<Details> list = new ArrayList<Details>();
		try {
		
		    Connection con = DetailsCon.getConnect();
			//System.out.print(conec);
			PreparedStatement ps = con.prepareStatement("Select * from details");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Details d = new Details();
				d.setStudent_id(rs.getString(1));
				d.setUsername(rs.getString(2));
				d.setGender(rs.getString(3));
				d.setEmail(rs.getString(4));
				d.setDepartment(rs.getString(5));
				d.setSemester(rs.getString(6));
				d.setPassword(rs.getString(7));
				list.add(d);
			}
			con.close();
		} catch (Exception e) {
			System.out.print(e);
		}
		return list;
	}
}

package com.yash.demprestapi;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
@Path("myresource")
public class MyResource {
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Resource getResource() {
		System.out.println("yash console");
		Resource r = new Resource();
		r.setName("Jaynam");
		r.setMarks(100);
		return r;
	}
}
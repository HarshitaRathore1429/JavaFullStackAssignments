public class Square {
public int square(int n)
{
	return n*n;
}
}

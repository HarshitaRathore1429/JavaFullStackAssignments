
import java.io.PrintWriter;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=res.getWriter();
		String username=req.getParameter("u");
		String password=req.getParameter("p");
		String email=req.getParameter("e");
		String gender=req.getParameter("g");
		String field=req.getParameter("f");
		String dateofbirth=req.getParameter("bd");
		String joiningdate=req.getParameter("j");
		String month=req.getParameter("m");
		String week=req.getParameter("w");
		String github=req.getParameter("git");
		String experience=req.getParameter("ex");
		/*if(password.equals("yash"))
		{
			out.println("Welcome to yash technology");
		}
		else
		{
			out.println("error");
		}*/
		out.println(username);
		out.println(password);
		out.println(email);
		out.println(gender);
		out.println(field);
		out.println(dateofbirth);
		out.println(joiningdate);
		out.println(month);
		out.println(week);
		out.println(github);
		out.println(experience);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(req, res);
	}

}

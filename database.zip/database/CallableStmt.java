import java.sql.*;
class CallableStmt
{
	public static void main(String[] args)
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/harshita";
			String user="root";
			String pass="root";
			Connection con=DriverManager.getConnection(url,user,pass);
			CallableStatement cstmt=con.prepareCall("{call insert into employee VALUES(?,?)}");
			cstmt.setInt(1,10082);
			cstmt.setString(2,"Rashmi");
			cstmt.execute();
			System.out.println("Success");
			con.close();
		}
        catch(Exception e)
		{
            e.printStackTrace();
        }			
	}
}
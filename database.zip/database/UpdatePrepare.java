import java.sql.*;
class UpdatePrepare
{
	public static void main(String[] args)
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/harshita";
			String user="root";
			String pass="root";
			Connection con=DriverManager.getConnection(url,user,pass);
			String query="Update employee SET empId=? where name=?";
			PreparedStatement pstmt=con.prepareStatement(query);
			String name="Rakhi";
			int empId=1009;
			pstmt.setInt(1,empId);
			pstmt.setString(2,name);
			int i=pstmt.executeUpdate();
			System.out.println("Records updated: "+i);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
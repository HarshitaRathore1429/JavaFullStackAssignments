import java.sql.*;
import java.io.*;
class PreparedStmt
{
	public static void main(String[] args)
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/harshita";
			String user="root";
			String pass="root";
			Connection con=DriverManager.getConnection(url,user,pass);
			String query="insert into employee(empId,name) values(?,?)";
			PreparedStatement pstmt=con.prepareStatement(query);
			/*pstmt.setInt(1,1009);
			pstmt.setString(2,"Rani");			
			int upd=pstmt.executeUpdate();
			System.out.println("Records updated: "+upd);*/
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
            do
			{
               System.out.println("Enter the employee id:");
               int empId=Integer.parseInt(br.readLine());
			   System.out.println("Enter the name of employee: ");
			   String name=br.readLine();
			   pstmt.setInt(1,empId);
			   pstmt.setString(2,name);
			   int i=pstmt.executeUpdate();
			   System.out.println("Records Updated: "+i);
			System.out.println("Do you want to continue: y/n");  
            String s=br.readLine();  
            if(s.startsWith("n")){  
               break;  
            }  
            }while(true);  
  
			con.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
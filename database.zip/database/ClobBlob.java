import java.sql.*;
import java.io.*;
class ClobBlob
{
	public static void main(String[] args)
	{
		    try
			{
			String url="jdbc:mysql://localhost:3306/harshita";
			String user="root";
			String pass="root";
			Connection con=DriverManager.getConnection(url,user,pass);
			String query="Insert into employee(empId,name,photo,description) Values(?,?,?,?)";
			PreparedStatement pstmt=con.prepareStatement(query);
			pstmt.setInt(1,1429);
			pstmt.setString(2,"Ram");
			InputStream ist=new FileInputStream("C:/Users/Harshita.Rathore/Desktop/Java program/database/photo.png");
			pstmt.setBlob(3,ist);
			FileReader fr=new FileReader("C:/Users/Harshita.Rathore/Desktop/Java program/database/description.txt");
			pstmt.setClob(4,fr);
			pstmt.execute();
			System.out.println("Record Inserted");
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * from employee");
            while(rs.next()) {
				int empId=rs.getInt("empId");
				String name=rs.getString("name");
				Blob blob=rs.getBlob("photo");
				Clob clob=rs.getClob("description");
				System.out.println("empId: "+empId);
				System.out.println("name: "+name);
				System.out.println("Blob value: "+blob);
                System.out.println("Clob value: "+clob);
                System.out.println("");
                System.out.print("Clob data is stored at: ");
                //Storing clob to a file
                int i, j =0;
                Reader r = clob.getCharacterStream();
                String filePath = "C:/Users/Harshita.Rathore/Desktop/Java program/database"+name+"des.txt";
                FileWriter writer = new FileWriter(filePath);
                while ((i=r.read())!=-1) {
                    writer.write(i);
                }
                writer.close();
                System.out.println(filePath);
                j++;
                System.out.print("Blob data is stored at: ");
                InputStream is = blob.getBinaryStream();
                byte byteArray[] = new byte[is.available()];
                is.read(byteArray);
                filePath = "C:/Users/Harshita.Rathore/Desktop/Java program/database"+name+"photo.png";
                FileOutputStream outPutStream = new FileOutputStream(filePath);
                outPutStream.write(byteArray);
                System.out.println(filePath);
		    	con.close();
			}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
	}
}
package com.automobile.twowheeler;
import com.automobile.Vehicle;
public class Hero extends Vehicle
{
	public int getSpeed()
	{
		return 100;
	}
	public void radio()
	{
		System.out.println("Provide facility to control radio devices");
	}
	public String getModelName()
	{
		return "HERO";
	}
	public String getRegistrationumber()
	{
		return "44332";
	}
	public String getOwnerName()
	{
		return "harshi";
	}
}
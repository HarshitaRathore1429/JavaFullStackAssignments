package com.automobile.twowheeler;
import com.automobile.Vehicle;
public class Honda extends Vehicle
{
	public int getSpeed()
	{
		return 200;
	}
	public void cdPlayer()
	{
		System.out.println("CD player");
	}
	public String getModelName()
	{
		return "Honda";
	}
	public String getRegistrationumber()
	{
		return "Mp323";
	}
	public String getOwnerName()
	{
		return "Harshita";
	}
}
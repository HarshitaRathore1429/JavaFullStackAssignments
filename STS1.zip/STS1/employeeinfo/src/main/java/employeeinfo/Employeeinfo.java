package employeeinfo;
public class Employeeinfo {
private String name;
private int empid;
private String email;
private long salary;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getEmpid() {
	return empid;
}
public void setEmpid(int empid) {
	this.empid = empid;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public long getSalary() {
	return salary;
}
public void setSalary(long salary) {
	this.salary = salary;
}
@Override
public String toString() {
	return "Employeeinfo [name=" + name + ", empid=" + empid + ", email=" + email + ", salary=" + salary + "]";
}

}

import java.util.Scanner;
import java.sql.*;
import java.io.*;
import java.util.InputMismatchException;
class Login
{
	private String user_name,user_password;
	private int user_id;
	Login(int user_id,String user_name,String user_password)
	{
		this.user_id=user_id;
		this.user_name=user_name;
		this.user_password=user_password;
	}
	 public String tostring()
    {
	   return " User name: "+ user_name+" Password: "+user_password;
    }
}
class User
{
	String email,user_address;
	long phone_no;
	Login l;
	User(Login l, String email, long phone_no, String user_address)
	{
		this.l=l;
		this.email=email;
		this.phone_no=phone_no;
		this.user_address=user_address;
	}
	void display()
	{
		System.out.println(l.tostring()+" User email :"+email+" User phone no: "+phone_no+" User address: "+user_address);
	}
} 
class Success
{
	String sucvenue,stitle;
	Success(String stitle,String sucvenue)
	{
      	this.stitle=stitle;
	    this.sucvenue=sucvenue;
	}
	void sdisplay()
	{
		System.out.println("Title for success party is: "+stitle);
		System.out.println("Selected venue is: "+sucvenue);
	}
}
class Welcome
{
	String welvenue,weltagline;
	Welcome(String weltagline,String welvenue)
	{
      	this.weltagline=weltagline;
	    this.welvenue=welvenue;
	}
	void wdisplay()
	{
		System.out.println("Title for success party is: "+weltagline);
		System.out.println("Selected venue is: "+welvenue);
	}
}
class Farewell
{
	String fname,favenue;
	Farewell(String fname,String favenue)
	{
      	this.fname=fname;
	    this.favenue=favenue;
	}
	void fdisplay()
	{
		System.out.println("Title for success party is: "+fname);
		System.out.println("Selected venue is: "+favenue);
	}
}
class Birthday
{
	String name,venue;
	Birthday(String name,String venue)
	{
		this.name=name;
		this.venue=venue;
	}
	void name()
	{
		System.out.println("Birthday boy/girl: "+name);
	}
	void confirm()
	{
		System.out.println("Basic details are filled!!");
	}
	void displayvenue()
	{
		System.out.println("Selected venue for birthday is: "+venue);
	}
}
class Anniversary 
{
	String men,women,annvenue;
	Anniversary(String men,String women, String annvenue)
	{
		this.men=men;
		this.women=women;
		this.annvenue=annvenue;
	}
	void showname()
	{
		System.out.println("Anniversary is of "+men+" & "+women);
	}
	void confirm()
	{
		System.out.println("Basic details are filled!!");
	}
	void displayvenue()
	{
		System.out.println("Selected venue for birthday is: "+annvenue);
	}
}
class Festival
{
	String fvenue,fname,farrange;
	Festival(String fvenue,String fname,String farrange)
	{
		this.fvenue=fvenue;
		this.fname=fname;
		this.farrange=farrange;
	}
	void fdisplay()
	{
		System.out.println("Your festive is: "+fname);
		System.out.println("Your choosed venue is: "+fvenue);
		if(farrange=="Yes")
			System.out.println("We will arrange festive items!");
		else
			System.out.println("Festive items are not arranged by us.");
	}
}
abstract class Food
{
	abstract void use();
}
class Indian extends Food
{
	void use()
	{
		System.out.println("Indian cuisine is confirmed");
	}
}
class Chinese extends Food
{
	void use()
	{
		System.out.println("Chinese cuisine is confirmed");
	}
}	
class Event
{
	public static void main(String[] args)
	{
		 String user_name,user_password, user_email,user_address,party,event_type,event_name;
		 int user_id;
		 long user_mobile;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
		    String url="jdbc:mysql://localhost:3306/EventMgmt";
		    String user="root";
		    String pass="root";
		    Connection con=DriverManager.getConnection(url,user,pass);
		    Statement stmt=con.createStatement();
		    BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			   System.out.println("Enter the user id:");
			   user_id=Integer.parseInt(br.readLine());
               System.out.println("Enter the user name:");
               user_name=br.readLine();
			   System.out.println("Enter the password: ");
			   user_password=br.readLine();
			   ResultSet rs=stmt.executeQuery("select user_name from login where user_name like '"+'%'+user_name+'%'+"'");
               if(rs.next()){
                    System.out.println("User already exist");
					String query2="Select * from user_details where user_id='"+user_id+"'";
					String query3="Select * from event_details where user_id='"+user_id+"'";
					ResultSet rst=stmt.executeQuery(query2);
					if(rst.next())
					{
				        System.out.println("User id: "+rst.getInt(1) + " " + "User email: " +rst.getString(2)+ " "+"User mobile: "+rst.getLong(3)+" "+"User address: "+rst.getString(4));
			        }
					ResultSet rt=stmt.executeQuery(query3);
					if(rt.next())
					{
				        System.out.println("User id: "+rt.getInt(1)+" "+"Event type: "+rt.getString(2)+" "+"Event name "+rt.getString(3));
			        }
				}
			   else{
				   String query="Insert into login(user_id,user_name,user_password) values (?,?,?)";
				   String query1="Insert into user_details(user_id,user_email,user_mobile,user_address) values(?,?,?,?)";
				   PreparedStatement pstmt=con.prepareStatement(query);
				   pstmt.setInt(1,user_id);
				   pstmt.setString(2,user_name);
				   pstmt.setString(3,user_password);
				   pstmt.executeUpdate();
				   PreparedStatement pst=con.prepareStatement(query1);
				   System.out.println("User is registered");
			   Login l=new Login(user_id,user_name, user_password);
			   System.out.println("Setup user profile");
			   pst.setInt(1,user_id);
			   System.out.println("Enter email:");
			   user_email=br.readLine();
			   pst.setString(2,user_email);
			   System.out.println("Enter user phone no: ");
			   user_mobile=Long.parseLong(br.readLine());
			   pst.setLong(3,user_mobile);
			   System.out.println("Enter your address: ");
			   user_address=br.readLine();
			   pst.setString(4,user_address);
			     pst.executeUpdate();
			   User user1=new User(l, user_email,user_mobile,user_address);
			  // user1.display();
			  int c,price,guestno;
		String tagline,venue,title,farename,bname,cmen,cwomen,festive,arrange;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter 1 for corporate events, Enter 2 for personal events.");
		c=s.nextInt();
		if(c==1)
		{
			System.out.println("1. Welcome party");
			System.out.println("2. Success party");
			System.out.println("3. Farwell party");
			System.out.println("Please select type of corporate event by choosing number.");
		    event_name=s.next();
			switch(event_name)
			{
				case"Welcomeparty":
				System.out.println("Enter welcome party's tagline:");
				tagline=s.next();
				System.out.println("Write venue between two choice: a) office b) hotel");
		        venue=s.next();
				Welcome w=new Welcome(tagline,venue);
				w.wdisplay();
				break;
				case"Successparty":
				System.out.println("Enter success party's title:");
				title=s.next();
				System.out.println("Write venue between two choice: a) office b) hotel");
		        venue=s.next();
				Success sc=new Success(title,venue);
				sc.sdisplay();
				break;
				case"Farewellparty":
				System.out.println("Enter name for whom the farewell party is:");
				farename=s.next();
				System.out.println("Write venue between two choice: a) office b) hotel");
		        venue=s.next();
				Farewell f=new Farewell(farename,venue);
				f.fdisplay();
				break;
			}
			event_type="Corporate event";
		String q="Insert into event_details(user_id,event_type,event_name) values(?,?,?)";
		PreparedStatement ps=con.prepareStatement(q);
		ps.setInt(1,user_id);
		ps.setString(2,event_type);
		ps.setString(3,event_name);
		ps.executeUpdate();
		}
		if(c==2)
		{
			System.out.println("1. Birthday");
			System.out.println("2. Anniversary");
			System.out.println("3. Festive party");
			System.out.println("Please choose number according to event.");
		    event_name=s.next();
			switch(event_name)
		    {
	      	case"Birthday":
		    System.out.println("Enter the birthday person name:");
		    bname=s.next();
		    System.out.println("Write venue between two choice: a) house b) hotel");
		    venue=s.next();
		    Birthday bn=new Birthday (bname,venue);
            bn.name();
		    bn.displayvenue();
		    bn.confirm();
		    break;
		    case"Anniversary":
		    System.out.println("Enter the men name:");
		    cmen=s.next();
		    System.out.println("Enter the name of women:");
		    cwomen=s.next();
		    System.out.println("Write venue between two choice: a)house b) hotel");
		    venue=s.next();
		    Anniversary an=new Anniversary(cmen,cwomen,venue);
		    an.showname();
		    an.displayvenue();
		    an.confirm();
		    break;
			case"Festive party":
			System.out.println("Enter festive name:");
			festive=s.next();
			System.out.println("Write venue between two choice: a)house b)hotel");
			venue=s.next();
			System.out.println("Do you want us to arrange festive items: Yes or No");
			arrange=s.next();
			Festival f=new Festival(festive,venue,arrange);
			f.fdisplay();
			break;
		    }
	    }
		System.out.println("Please choose cuisine, Indian or Chinese");
		String cuisine=s.next();
		switch(cuisine)
		{
			case"Indian":
			{
				Indian i=new Indian();
		        i.use();
				System.out.println("Enter per plate price of your choice:");
				price=s.nextInt();
				System.out.println("Enter the total number of guest:");
		        guestno=s.nextInt();
				System.out.println("Total cost of food is:" +price*guestno);
			    break;
			}
			case"Chinese":
			{ 
			  Chinese ch=new Chinese();
			  ch.use();
			  System.out.println("Enter per plate price of your choice:");
			  price=s.nextInt(); 
			  System.out.println("Enter the total number of guest:");
		      guestno=s.nextInt();
			  System.out.println("Total price of food:" + price*guestno);
			  break;
			}
		}
		}
		}
		catch(InputMismatchException im)
		{
			im.printStackTrace();
		}
		catch(NumberFormatException ne)
		{
			System.out.println(ne);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
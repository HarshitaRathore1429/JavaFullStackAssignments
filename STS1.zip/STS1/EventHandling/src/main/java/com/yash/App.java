package com.yash;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		context.start();
		Employee obj = (Employee) context.getBean("Employee");
		System.out.println(obj);
		context.stop();
	}

}

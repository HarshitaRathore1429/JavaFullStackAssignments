public class DebuggerDemo {
public static void main(String[] args) {
   System.out.println("Hello!! Harshita");	
   int i=100;
   show();
   if(i<120)
   {
	   System.out.println("Value is greater than 100");
   }
   else
   {
	   System.out.println("Value is less than 120");
   }
}
static void show()
{
	for(int i=0;i<5;i++)
	{
		System.out.println(i);
	}
}
}

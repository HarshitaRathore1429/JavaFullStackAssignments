package com.yash.employeejdbc;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.employeejdbc.dao.*;
import com.yash.employeejdbc.entities.Employee;

public class App {
	public static void main(String[] args) throws Exception {
		System.out.println("Hello World!");
		ApplicationContext context = new ClassPathXmlApplicationContext("com/yash/employeejdbc/applicationcontext.xml");
		EmployeeDao empdao = context.getBean("EmployeeDao", EmployeeDao.class);

		Employee e = new Employee();
		e.setEmpname("Harshit");
		e.setEmail("harshit.patidar@yash.com");
		String sDate1 = "9/05/2002";
		Date date1 = new SimpleDateFormat("dd/MM/yyyy").parse(sDate1);
		e.setDob(date1);
		e.setContactno("9826323893");
		e.setSalary(800000);
		// int r = empdao.insert(e);
		// System.out.println(r + "Student added Successfully ");
		// int x=empdao.update(e);
		// System.out.println(x+"Student updated successfully");
		int y = empdao.delete("Yash");// delete the details
		System.out.println(y + "Student deleted Successfully ");

	}
}
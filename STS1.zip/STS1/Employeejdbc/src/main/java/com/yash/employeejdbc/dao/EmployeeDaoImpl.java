package com.yash.employeejdbc.dao;

import com.yash.employeejdbc.entities.*;

import java.util.List;

import javax.swing.tree.RowMapper;

import org.springframework.jdbc.core.JdbcTemplate;

public class EmployeeDaoImpl implements EmployeeDao {
	private JdbcTemplate jdbctemp;

	public int insert(Employee emp) {
		String q = "insert into employee(empname,email,dob,contactno,salary) values(?,?,?,?,?)";
		int msg = this.jdbctemp.update(q, emp.getEmpname(), emp.getEmail(), emp.getDob(), emp.getContactno(),
				emp.getSalary());
		return msg;
	}

	public int update(Employee emp) {
		String q = "update employee set email=? where empname=?";
		int msg = this.jdbctemp.update(q, emp.getEmail(), emp.getEmpname());
		return msg;
	}


	public JdbcTemplate getJdbctemp() {
		return jdbctemp;
	}

	public void setJdbctemp(JdbcTemplate jdbctemp) {
		this.jdbctemp = jdbctemp;
	}

	public int delete(String empname) {
		String q = "delete from employee where empname=?";
		int msg = this.jdbctemp.update(q, empname);
		return msg;
	}

}
package com.yash.employeejdbc.dao;

import java.util.List;

import com.yash.employeejdbc.entities.*;

public interface EmployeeDao {
	public int insert(Employee emp);

	public int update(Employee emp);

	public int delete(String empname);
}

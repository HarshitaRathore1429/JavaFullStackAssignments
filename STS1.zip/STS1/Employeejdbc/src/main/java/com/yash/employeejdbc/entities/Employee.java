package com.yash.employeejdbc.entities;

import java.util.Date;

public class Employee {
	private String empname;
	private String email;
	private Date dob;
	private String contactno;
	private int salary;

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getContactno() {
		return contactno;
	}

	public void setContactno(String contactno) {
		this.contactno = contactno;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [empname=" + empname + ", email=" + email + ", date=" + dob + ", contactno=" + contactno
				+ ", salary=" + salary + "]";
	}

	public Employee(String empname, String email, Date dob, String contactno, int salary) {
		super();
		this.empname = empname;
		this.email = email;
		this.dob = dob;
		this.contactno = contactno;
		this.salary = salary;
	}

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
}

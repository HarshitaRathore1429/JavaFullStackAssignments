import java.lang.Class;
class Bank{}
class ReflectionDemo
{
	public static void main(String[] args)throws Exception
	{
		Class a = Class.forName("Bank");
		System.out.println(a.getName());
		Class c=ReflectionDemo.class;
		System.out.println(c.getName());	n	
	}
}
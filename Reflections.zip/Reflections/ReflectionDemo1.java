import java.lang.Class;
class ReflectionDemo1
{
	public static void main(String[] args)
	{
		int arr[]={1,3,40,23,41};
		Class cl=arr.getClass();
		System.out.println(cl.isArray());
		boolean b=int.class.isPrimitive();
		System.out.println(b);
	}
}
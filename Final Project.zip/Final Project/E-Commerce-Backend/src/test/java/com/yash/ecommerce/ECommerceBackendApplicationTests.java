package com.yash.ecommerce;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;

import com.yash.ecommerce.model.Customer;
import com.yash.ecommerce.repository.CustomerRepository;

@SpringBootTest
class ECommerceBackendApplicationTests {

	@Autowired
	CustomerRepository customerrepository;

	@Test
    public void saveCustomerTest()
    {
        Customer customer = new Customer();
        
        customer.setId(6);
        customer.setFname("aastha");
        customer.setLname("yadav");
        customer.setEmail("nikhil@gmail.com");
        customer.setPassword("nikhil");
        customer.setGender("Female");
        customer.setPhone("878787887");
        customerrepository.save(customer);
    }
}
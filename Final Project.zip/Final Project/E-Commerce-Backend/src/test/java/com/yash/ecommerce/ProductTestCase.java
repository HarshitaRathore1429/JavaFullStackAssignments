package com.yash.ecommerce;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMultipartHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.yash.ecommerce.model.Order;
import com.yash.ecommerce.model.Product;
import com.yash.ecommerce.repository.ProductRepository;

@SpringBootTest
public class ProductTestCase {


	Product product = new Product();

	@Autowired
	ProductRepository productrepository;

	@Test
	public void ProductCreateTestCase() {

		product.setId((int) 1L);
		product.setName("jens");
		product.setColour("red");
		product.setDescription("Cotton Jens");
		product.setIdealFor("Men");
		product.setSize("XXL");
		product.setType("Upper Wear");
		product.setPrice(600);
		product.setSellerId("2");
		productrepository.save(product);
	}

	@Test
	public void ProductDeleteTestcase() {
		productrepository.deleteById((int) 21L);
		assertThat(productrepository.existsById((int) 21L)).isFalse();
	}

	@Test
	public void GetAllProductTestCase() {
		List<Product> list = (List<Product>) productrepository.findAll();
		assertThat(list).size().isGreaterThan(2);
	}
}

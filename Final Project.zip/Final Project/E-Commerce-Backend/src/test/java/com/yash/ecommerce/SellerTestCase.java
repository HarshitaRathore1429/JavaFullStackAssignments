package com.yash.ecommerce;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.yash.ecommerce.model.Customer;
import com.yash.ecommerce.model.Seller;
import com.yash.ecommerce.repository.SellerRepository;

@SpringBootTest
public class SellerTestCase {

	Seller seller = new Seller();

	@Autowired
	SellerRepository sellerrepository;

	@Test
	public void saveSellerTest() {

		seller.setFname("purv");
		seller.setLname("sahu");
		seller.setEmail("purv@gmail.com");
		seller.setPassword("nikhil%$3212");
		seller.setGender("Male");
		seller.setPhone("8787878871");
		// sellerrepository.save(seller);
	}

	@Test
	public void loginSeller_existTest() {
		List<Seller> list = (List<Seller>) sellerrepository.findAll();
		assertThat(list).size().isGreaterThan(0);
	}
	
	
	@Test
	public void SellerloginTestCase()
	{
		
		List<Seller> list = sellerrepository.findByEmail("ykushal920@gmail.com");
		assertThat(list).size().isGreaterThan(0);
	}

	
	@Test
	public void SellerloginTestCasePassword () {
		List<Seller> seller = sellerrepository.findByPassword("12345");
		assertThat(seller).size().isGreaterThan(0);	
		}
}

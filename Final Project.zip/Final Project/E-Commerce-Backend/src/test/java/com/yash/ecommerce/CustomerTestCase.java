package com.yash.ecommerce;

import static org.assertj.core.api.Assertions.assertThat;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.yash.ecommerce.model.Customer;
import com.yash.ecommerce.repository.CustomerRepository;

@SpringBootTest
public class CustomerTestCase {
	Customer customer = new Customer();
	@Autowired
	CustomerRepository customerrepository;
	@Test
	public void saveCustomerTest() {
		customer.setFname("shubham");
		customer.setLname("patil");
		customer.setEmail("shubham@gmail.com");
		customer.setPassword("shubam@%4312");
		customer.setGender("Male");
		customer.setPhone("9881883889");
		customerrepository.save(customer);
		//assertNotNull(customerrepository.findById((int) 1).get());
	}
	@Test
	public void loginCustomer_existTest() {
		List<Customer> list = (List<Customer>) customerrepository.findAll();
		assertThat(list).size().isGreaterThan(0);
	}
	@Test
	public void CustomerloginTestCase()
	{
		
		List<Customer> list = customerrepository.findByEmail("sahuhritik9479@gmail.com");
		assertThat(list).size().isGreaterThan(0);
	}
	@Test
	public void CustomerloginTestCasePassword () {
		List<Customer> customer = customerrepository.findByPassword("1");
		assertThat(customer).size().isGreaterThan(0);	
		}
}






package com.yash.ecommerce;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.yash.ecommerce.model.Customer;
import com.yash.ecommerce.model.Order;
import com.yash.ecommerce.repository.OrderRepository;

@SpringBootTest
public class OrderTestCase {

	Order order = new Order();

	@Autowired
	OrderRepository orderrepository;

	@Test
	public void OrderTestCase() {
		order.setId((int) 1L);
		order.setCustomerId(3);
		order.setDate("07/07/2022");
		order.setTime("12:12:12 PM");
		order.setAllProductsName("black");
		order.setQuantity("10");
		order.setPrice("600");
		orderrepository.save(order);
	}

	
	@Test
	public void GetOrderTestCase() {
		List<Order> list = (List<Order>) orderrepository.findAll();
		assertThat(list).size().isGreaterThan(0);
	}
	
	
	@Test
	public void ProductDeleteTestcase() {
		orderrepository.deleteById((int) 16L);
		assertThat(orderrepository.existsById((int) 16L)).isFalse();
	}

}

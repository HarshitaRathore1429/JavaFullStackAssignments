package com.yash.ecommerce.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.yash.ecommerce.model.Cart;

@Repository
public interface CartRepository extends CrudRepository<Cart, Integer> {
	
	@Transactional
	@Modifying
	@Query("delete from cart_details where customer_id=?1 and product_id=?2")
	public void removeProductFromCart(int customer_id, int product_id);
	
	
	@Query(value="select * from cart_details where customer_id=?1",nativeQuery = true)
	public List<Cart> getAddCartProduct(int customer_id);

	@Transactional
	public void deleteAllByCustomerId(int customerId);
}

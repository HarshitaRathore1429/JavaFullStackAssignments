package com.yash.ecommerce.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.ecommerce.model.Cart;
import com.yash.ecommerce.model.Product;
import com.yash.ecommerce.repository.CartRepository;
import com.yash.ecommerce.repository.ProductRepository;
import com.yash.ecommerce.service.CartService;

@Service
public class CartServiceImpl implements CartService {

	@Autowired
	private CartRepository cartRepository;

	@Autowired
	private ProductRepository productRepository;

	// CartAddServiceImpl
	@Override
	public Cart addCart(Cart cart) {
		return cartRepository.save(cart);
	}

	// CartDeleteServiceImpl
	@Override
	public String deleteCart(Cart cart) {
		cartRepository.removeProductFromCart(cart.getCustomerId(), cart.getProductId());
		return "Product delete from cart!";
	}

	// CartDeleteAllServiceImpl
	@Override
	public String deleteAllCart(Cart cart) {
		cartRepository.deleteAllByCustomerId(cart.getCustomerId());
		return "All Products remove from cart successfully!";
	}

	// CartGetCustomerProductServiceImpl
	@Override
	public List<Product> getCustomerProductCart(int[] productCart) {
		List<Product> list = new ArrayList<Product>();
		for (int i = 0; i < productCart.length; i++) {
			List<Product> oneProduct = productRepository.findById(productCart[i]);
			list.add(oneProduct.get(0));
		}
		return list;
	}

	// CartGetCustomerCartServiceImpl
	@Override
	public List<Cart> getCustomerCart(Cart cart) {
		return cartRepository.getAddCartProduct(cart.getCustomerId());
	}

}

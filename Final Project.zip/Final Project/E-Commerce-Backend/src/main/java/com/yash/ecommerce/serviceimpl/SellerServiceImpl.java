package com.yash.ecommerce.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.ecommerce.model.Seller;
import com.yash.ecommerce.repository.SellerRepository;
import com.yash.ecommerce.service.SellerService;

@Service
public class SellerServiceImpl implements SellerService {

	@Autowired
	private SellerRepository sellerRepository;

	// SellerLoginServiceImpl
	@Override
	public List<Seller> sellerLogin(Seller seller) {
		List<Seller> list = sellerRepository.findByEmail(seller.getEmail());

		String value = "" + list;
		if (value.equals("[]")) {
			return list;
		} else {
			String password = seller.getPassword();
			seller = list.get(0);
			if (password.equals(seller.getPassword())) {
				return list;
			}
			return null;
		}
	}

	// SellerRegisterServiceImpl
	@Override
	public Seller registerSeller(Seller seller) {
		return sellerRepository.save(seller);
	}

	// SellerGetIdServiceImpl
	@Override
	public int getId(Seller seller) {

		List<Seller> sel = sellerRepository.findByEmail(seller.getEmail());
		return sel.get(0).getId();
	}
}

package com.yash.ecommerce.service;

import java.util.List;

import com.yash.ecommerce.model.Customer;

public interface CustomerService {

	// CustomerLoginService
	public List<Customer> customerLogin(Customer customer);

	// CustomerRegisterService
	public Customer registerCustomer(Customer customer);

	// CustomerExistService
	public List<Customer> customerExist(Customer customer);

	// CustomerGetOtpService
	public String getOtp(Customer customer);

	// CustomerGetIdService
	public int getId(Customer customer);

	// CustomerGetNameService
	public String getName(Customer customer);
}

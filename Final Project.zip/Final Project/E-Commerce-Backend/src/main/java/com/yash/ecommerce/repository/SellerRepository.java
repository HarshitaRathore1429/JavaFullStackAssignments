package com.yash.ecommerce.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.yash.ecommerce.model.Seller;

@Repository
public interface SellerRepository extends CrudRepository<Seller,Integer>  {
	
	List<Seller> findByEmail(String email);
	List<Seller> findByPassword(String password);
}

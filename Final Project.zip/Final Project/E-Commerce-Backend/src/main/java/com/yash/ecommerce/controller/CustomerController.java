package com.yash.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.ecommerce.model.Customer;
import com.yash.ecommerce.model.Order;
import com.yash.ecommerce.service.CustomerService;
import com.yash.ecommerce.service.OrderService;

@RestController
@CrossOrigin
@RequestMapping("/customer")
public class CustomerController {

	@Autowired
	private CustomerService customerService;
	
	@Autowired
	private OrderService orderService;
	
	@PostMapping("/register")
	public String register(@RequestBody Customer customer) {
		customerService.registerCustomer(customer);
		return "Customer registered successfully!";
	}
	
	@PostMapping("/customer_exist")
	public String customerExist(@RequestBody Customer customer) {
		List<Customer> list = customerService.customerExist(customer);
		String value=""+list;
		if(value.equals("[]")){
			return "Customer not registered!";
		}else{
			return "Customer already registered!";
		}
	}
	
	@PostMapping("/login")
	public String customerLogin(@RequestBody Customer customer) {
		List<Customer> list = customerService.customerLogin(customer);
		String value=""+list;
		if(value.equals("[]")){
			return "Customer not registered!";
		}else if(list==null){
			return "Password is incorrect!";
		}else{
			return "Customer successfully logged in!";
		}
	}
	
	@PostMapping("/getCustomerId")
	public int getCustomerId(@RequestBody Customer customer){
		return customerService.getId(customer);
	}
	
	@PostMapping("/getOtp")
	public String getValidationOtp(@RequestBody Customer customer){
		return customerService.getOtp(customer);
	}
	
	@PostMapping("/addOrder")
  	public String addOrder(@RequestBody Order order) {
		orderService.addNewOrder(order);
		return "New order added!";
	}
	
	@PostMapping("/getOrder")
	public List<Order> getOrder(@RequestBody Order order){
		return orderService.getAllOrder(order);
	}
	
	@PostMapping("/getCustomerName")
	public String getCustomerName(@RequestBody Customer customer){
		return customerService.getName(customer);
	}
}

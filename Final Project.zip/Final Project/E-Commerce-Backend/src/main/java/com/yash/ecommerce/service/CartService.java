package com.yash.ecommerce.service;

import java.util.List;

import com.yash.ecommerce.model.Cart;
import com.yash.ecommerce.model.Product;

public interface CartService {

	// CartAddService
	public Cart addCart(Cart cart);

	// CartDeleteService
	public String deleteCart(Cart cart);

	// CartDeleteAllService
	public String deleteAllCart(Cart cart);

	// CartGetCustomerCartService
	public List<Cart> getCustomerCart(Cart cart);

	// CartGetCustomerProductCartService
	public List<Product> getCustomerProductCart(int[] productCart);
}

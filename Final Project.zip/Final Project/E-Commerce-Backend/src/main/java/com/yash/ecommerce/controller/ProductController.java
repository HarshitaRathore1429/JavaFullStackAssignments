package com.yash.ecommerce.controller;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.yash.ecommerce.model.Product;
import com.yash.ecommerce.service.ProductService;

@RestController
@CrossOrigin
@RequestMapping("/product")
public class ProductController {

	@Autowired
	private ProductService productService;

	@PostMapping("/productAdd")
	public String add(@RequestBody Product product) {
		productService.addProduct(product);
		return "Product add successfully!";
	}
	
	@PostMapping("/productDelete")
	public String delete(@RequestBody Product product) {
		String message = productService.deleteProduct(product);
		return message ;
	}
    
	@GetMapping("/getProducts")
	public List<Product> listOfProducts(){
		return productService.getAllProducts();
	}
	
	@PostMapping("/saveImage")
	public String saveImage(@RequestParam("img") MultipartFile file) throws Exception {
		String Path_Directory="C:\\Users\\Hritik.Sahu\\Desktop\\Java Full Stack\\React\\e-commerce-frontend\\public\\productImages";
		Files.copy(file.getInputStream(),Paths.get(Path_Directory+File.separator+file.getOriginalFilename()),StandardCopyOption.REPLACE_EXISTING);
		return "Image upload successfully!";
	}
	
}

package com.yash.ecommerce.service;

import java.util.List;

import com.yash.ecommerce.model.Order;

public interface OrderService {

	//OrderAddService
	public Order addNewOrder(Order order);
	
	//OrderGetAllService
	public List<Order> getAllOrder(Order order);
}

package com.yash.ecommerce.service;

import java.util.List;

import com.yash.ecommerce.model.Product;

public interface ProductService {

	//ProductAddService
	public Product addProduct(Product product);
	
	//ProductDeleteService
	public String deleteProduct(Product product);
	
	//ProductGetAllService
	public List<Product> getAllProducts();
}

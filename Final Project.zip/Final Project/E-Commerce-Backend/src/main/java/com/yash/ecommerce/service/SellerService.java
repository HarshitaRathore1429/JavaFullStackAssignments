package com.yash.ecommerce.service;

import java.util.List;

import com.yash.ecommerce.model.Seller;

public interface SellerService {

	// SellerLoginService
	public List<Seller> sellerLogin(Seller seller);

	// SellerRegisterService
	public Seller registerSeller(Seller seller);

	// SellerGetIdService
	public int getId(Seller seller);
}

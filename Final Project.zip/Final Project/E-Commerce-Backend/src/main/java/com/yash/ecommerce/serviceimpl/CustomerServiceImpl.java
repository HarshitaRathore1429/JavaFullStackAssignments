package com.yash.ecommerce.serviceimpl;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.yash.ecommerce.model.Customer;
import com.yash.ecommerce.repository.CustomerRepository;
import com.yash.ecommerce.service.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private JavaMailSender mailSender;

	// CustomerLoginServiceImpl
	@Override
	public List<Customer> customerLogin(Customer customer) {

		List<Customer> list = customerRepository.findByEmail(customer.getEmail());

		String value = "" + list;
		if (value.equals("[]")) {
			return list;
		} else {
			String password = customer.getPassword();
			customer = list.get(0);
			if (password.equals(customer.getPassword())) {
				return list;
			}
			return null;
		}
	}

	// CustomerRegisterServiceImpl
	@Override
	public Customer registerCustomer(Customer customer) {
		return customerRepository.save(customer);
	}

	// CustomerExistServiceImpl
	@Override
	public List<Customer> customerExist(Customer customer) {

		List<Customer> list = customerRepository.findByEmail(customer.getEmail());
		return list;
	}

	// CustomerGetOtpServiceImpl
	@Override
	public String getOtp(Customer customer) {

		Random rnd = new Random();
		int otp = rnd.nextInt(999999);

		SimpleMailMessage message = new SimpleMailMessage();
		message.setFrom("yashtechnologiesecommerce@gmail.com");
		message.setTo(customer.getEmail());
		message.setText("" + otp);
		message.setSubject("Your OTP for login");

		mailSender.send(message);
		return "" + otp;
	}

	// CustomerGetIdServiceImpl
	@Override
	public int getId(Customer customer) {

		List<Customer> cus = customerRepository.findByEmail(customer.getEmail());
		return cus.get(0).getId();
	}
	
	// CustomerGetNameServiceImpl
		@Override
		public String getName(Customer customer) {

			List<Customer> cus = customerRepository.findByEmail(customer.getEmail());
			String name=cus.get(0).getFname()+" "+cus.get(0).getLname();
			return name;
		}
}

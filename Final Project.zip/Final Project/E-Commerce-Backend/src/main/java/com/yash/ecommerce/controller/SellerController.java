package com.yash.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.ecommerce.model.Seller;
import com.yash.ecommerce.service.SellerService;

@RestController
@CrossOrigin
@RequestMapping("/seller")
public class SellerController {
	
	@Autowired
	private SellerService sellerService;

	
	@PostMapping("/register")
	public String register(@RequestBody Seller seller){
		sellerService.registerSeller(seller);
		return "Seller registered successfully!";
	}
	
	@PostMapping("/login")
	public String sellerLogin(@RequestBody Seller seller) {
		List<Seller> list = sellerService.sellerLogin(seller);
		String value=""+list;
		if(value.equals("[]")){
			return "Seller not registered!";
		}else if(list==null){
			return "Password is incorrect!";
		}else{
			return "Seller successfully logged in!";
		}
	}
	
	@PostMapping("/getSellerId")
	public int getSellerId(@RequestBody Seller seller) {
		return sellerService.getId(seller);
	}
	
}

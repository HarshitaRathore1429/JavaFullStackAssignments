package com.yash.ecommerce.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.ecommerce.model.Product;
import com.yash.ecommerce.repository.ProductRepository;
import com.yash.ecommerce.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductRepository productRepository;

	// ProductAddServiceImpl
	@Override
	public Product addProduct(Product product) {
		return productRepository.save(product);
	}

	// ProductDeleteServiceImpl
	@Override
	public String deleteProduct(Product product) {
		productRepository.deleteById(product.getId());
		return "Product remove successfully!";
	}

	// ProductGetAllServiceImpl
	@Override
	public List<Product> getAllProducts() {
		return (List<Product>) productRepository.findAll();
	}
}

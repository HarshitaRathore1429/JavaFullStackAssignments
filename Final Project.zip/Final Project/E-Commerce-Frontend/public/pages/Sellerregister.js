import react from 'react';
import Sellernavbar from '../views/Sellernavbar';
function Sellerregister() {
    return (
        <div className='sellerregister'>
            <Sellernavbar />
            <div className='pt-4'>
                <form className=' col-md-6 offset-md-3 border rounded  shadow p-2 text-start'>
                    <h4 className='text-center'>Seller Register</h4>
                    <div className="form-group form-row">
                        <label className="col-sm-4 form-control-label" >Seller First Name</label>

                        <input type="text" className="form-control" placeholder='Enter your first name'/>

                    </div>
                    <div className="form-group form-row">
                        <label className="col-sm-4 form-control-label">Seller Last Name</label>
                        <input type="text" className="form-control" placeholder='Enter your last name' />
                    </div>
                    <label>Gender</label>
                    <input type="radio" name="gender" value="Male" />
                    <label for="Male" className="mx-2">Male</label>
                    <input type="radio" name="gender" value="Female" />
                    <label for="Female" className="mx-2">Female</label><br></br>


                    <div className="form-group form-row">
                        <label className="col-sm-4 form-control-label">Seller Email Id</label>
                        <input type="email" name="userid" className="form-control" placeholder='Enter your email id' />
                    </div>
                    <div className="form-group form-row">
                        <label className="col-sm-4 form-control-label">Seller Phone</label>
                        <input type="text" maxLength="10" name="phone" className="form-control" placeholder='Enter your phone number' />

                    </div>
                    <div className="form-group form-row">
                        <label className="col-sm-4 form-control-label">Password</label>

                        <input type="password" name="pwd" className="form-control" placeholder='Enter your password' />

                    </div>
                    <div className="form-group form-row">
                        <label className="col-sm-4 form-control-label">Confirm Password</label>

                        <input type="password" name="cpwd" className="form-control" placeholder='Enter your password again' />

                    </div>
                    <button className="btn btn-primary float-right mt-2">Register</button>
                </form>
            </div>
        </div>
    );
}
export default Sellerregister
import React,{Component} from 'react';
import Navigationbar from '../views/Navigationbar';
class Contact extends Component {
    render() {
        return (
            <div className='contact'>
                <Navigationbar />
            <form className=" col-md-6 offset-md-3 border shadow mt-5 rounded p-3">
                <h3 className="text-uppercase text-center">Contact Us</h3>
                <div className="form-outline mb-4">
                    <label className="form-label">Name</label>
                    <input type="email" id="form3Example3" className="form-control form-control-lg"
                    />
                    <label className="form-label">Email</label>
                    <input type="email" id="form3Example3" className="form-control form-control-lg"
                    />
                </div>
                <div className="form-outline mb-3">
                    <label className="form-label" >Mobile Number</label>
                    <input type="number" id="form3Example4" className="form-control form-control-lg"
                         />
                </div>
                <label className="form-label" >Write your query</label><br></br>
                <textarea className="form-control form-control-lg"></textarea>
                <div className="text-center text-md-start mt-2 ">
                    <button className="btn btn-primary btn-lg border-rounded w-100 p-1">Submit</button>
                </div>
            </form>
            </div>
        );
    }
} 
export default Contact

import react,{Component} from 'react';
import Sellerlogin from './Sellerlogin';
class Seller extends Component{
    render()
    {
        return(
            <div className='seller'>
                <Sellerlogin/>
            </div>
        );
    }
}
export default Seller
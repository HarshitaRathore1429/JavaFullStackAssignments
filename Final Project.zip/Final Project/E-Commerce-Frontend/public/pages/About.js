import React,{Component} from 'react';
import Navigationbar from '../views/Navigationbar';
class About extends Component{
    render()
    {
        return(
            <div className='aboutus'>
                 <Navigationbar />
            <div className='container-fluid mt-5'>
            <div className='row about'>
                <div className='col-md-6 col-6 text-start'>
                    <h3>About Us</h3>
                </div>
                <div className='col-md-6 col-6'>
                    <img src={'/images/logo.png'} width="350vw" height="350vh"></img>
                </div>
            </div>
            </div>
            </div>
        );  
      }
}
export default About
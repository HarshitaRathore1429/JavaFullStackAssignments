import styled from "styled-components";
import Sellerloginnavbar from "../views/Sellerloginnavbar";
const Container = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
`;

const Wrapper = styled.div`
  width: 40%;
  padding: 80px;
  background-color: white;

`;

const Title = styled.h1`
  font-size: 24px;
  font-weight: 300;
  text-align: center;
  padding: 20px;
`;

const Form = styled.form`
  display: flex;
  flex-wrap: wrap;
`;

const Input = styled.input`
  flex: 1;
  min-width: 40%;
  margin: 20px 10px 0px 0px;
  padding: 10px;
`;

const Select = styled.select`
  flex: 1;
  min-width: 40%;
  margin: 20px 10px 0px 0px;
  padding: 10px;
`;
const Label = styled.label`
  flex: 1;
  min-width: 40%;
  margin: 20px 10px 0px 20px;
  padding: 10px;
`;


const Button = styled.button`
  width: 40%;
  border: none;
  padding: 15px 20px;
  background-color: teal;
  color: white;
  cursor: pointer;
  margin:auto;
`;


const Productupperwearform = () => {
  return (
    <div className="productupper">
        <Sellerloginnavbar />
    <Container>
    <Wrapper>
      <Title>Add product</Title>
      <Form>
        <Input placeholder="Product Name"/>
        <Input placeholder="Product Description" />
        <br></br>
        <Select placeholder="Category">
        <option value="Mens">Mens</option>
        <option value="Womens">Womens</option>
        <option value="Kids">Kids</option>
      </Select>
       
        <Input placeholder="Price" />
        <Input placeholder="Color" />
        <Select placeholder="Size">
        <option value="S">S</option>
        <option value="M">M</option>
        <option value="L">L</option>
        <option value="XL">XL</option>
        </Select>
        <Label for="img">Select Product image:</Label>
        <Input type="file" id="file"
        onchange="return fileValidation()" />
 
 <div className="imagePreview"></div>
    
    {
        function fileValidation() {
            var fileInput =
                document.getElementById('file');
             
            var filePath = fileInput.value;
         
            // Allowing file type
            var allowedExtensions =
                    /(\.jpg|\.jpeg)$/i;
             
            if (!allowedExtensions.exec(filePath)) {
                alert('Invalid file type');
                fileInput.value = '';
                return false;
            }
            else
            {
             
                // Image preview
                if (fileInput.files && fileInput.files[0]) {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        document.getElementById(
                            'imagePreview').innerHTML =
                            '<img src="' + e.target.result
                            + '"/>';
                    };
                     
                    reader.readAsDataURL(fileInput.files[0]);
                }
            }
        }
      }
        <Button>Submit</Button>
      </Form>
      <br></br>
      <br></br>
      
    </Wrapper>
  
  </Container>
  </div>
  );
};

export default Productupperwearform;
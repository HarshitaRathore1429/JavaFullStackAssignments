import React, { Component } from 'react';
import { Card } from 'react-bootstrap';
import { Button } from 'react-bootstrap';
import Secondnav from '../views/Secondnav';
class Menpants extends Component {
    render()
      {
        return (
            <div className='menpants'>
                <Secondnav />
                <div className='row m-2 mt-5'>
                    <div className='col-6 col-md-3  '>
                        <Card>
                            <Card.Img variant="top" src={'/images/tshirt.jpg'} />
                            <Card.Body>
                                <Card.Title>Upper Wear</Card.Title>
                                <Card.Text>
                                    T-Shirt
                                </Card.Text>
                                <Button variant="danger">Add to Cart</Button>
                                <Button className='text-danger bg-light mx-2'>Buy Now</Button>
                            </Card.Body>
                        </Card>
                    </div>
                    <div className='col-6 col-md-3'>
                        <Card>
                            <Card.Img variant="top" src={' /images/men.jpg'} height="265vh" />
                            <Card.Body>
                                <Card.Title>Upper Wear</Card.Title>
                                <Card.Text>
                                    Shirt
                                </Card.Text>
                                <Button variant="danger">Add to Cart</Button>
                                <Button className='text-danger bg-light mx-2'>Buy Now</Button>
                            </Card.Body>
                        </Card>
                    </div>
                    < div className='col-6 col-md-3'>
                        <Card>
                            <Card.Img variant="top" src={' /images/shirt.jpg'} height="10%" />
                            <Card.Body>
                                <Card.Title>Upper Wear</Card.Title>
                                <Card.Text>
                                    Shirt
                                </Card.Text>
                                <Button variant="danger">Add to Cart</Button>
                                <Button className='text-danger bg-light mx-2'>Buy Now</Button>
                            </Card.Body>
                        </Card>
                    </div>
                    <div className='col-6 col-md-3'>
                        <Card>
                            <Card.Img variant="top" src={' /images/women.jpg'} />
                            <Card.Body>
                                <Card.Title>Upper Wear</Card.Title>
                                <Card.Text>
                                    Kids Set
                                </Card.Text>
                                <Button variant="danger">Add to Cart</Button>
                                <Button className='text-danger bg-light mx-2'>Buy Now</Button>
                            </Card.Body>
                        </Card>
                    </div>
                </div>
                <div className='row m-2 mt-5'>
                    <div className='col-6 col-md-3  '>
                        <Card>
                            <Card.Img variant="top" src={'/images/tshirt.jpg'} />
                            <Card.Body>
                                <Card.Title>Upper Wear</Card.Title>
                                <Card.Text>
                                    T-Shirt
                                </Card.Text>
                                <Button variant="danger">Add to Cart</Button>
                                <Button className='text-danger bg-light mx-2'>Buy Now</Button>
                            </Card.Body>
                        </Card>
                    </div>
                    <div className='col-6 col-md-3'>
                        <Card>
                            <Card.Img variant="top" src={' /images/men.jpg'} height="265vh" />
                            <Card.Body>
                                <Card.Title>Upper Wear</Card.Title>
                                <Card.Text>
                                    Shirt
                                </Card.Text>
                                <Button variant="danger">Add to Cart</Button>
                                <Button className='text-danger bg-light mx-2'>Buy Now</Button>
                            </Card.Body>
                        </Card>
                    </div>
                    < div className='col-6 col-md-3'>
                        <Card>
                            <Card.Img variant="top" src={' /images/shirt.jpg'} height="10%" />
                            <Card.Body>
                                <Card.Title>Upper Wear</Card.Title>
                                <Card.Text>
                                    Shirt
                                </Card.Text>
                                <Button variant="danger">Add to Cart</Button>
                                <Button className='text-danger bg-light mx-2'>Buy Now</Button>
                            </Card.Body>
                        </Card>
                    </div>
                    <div className='col-6 col-md-3'>
                        <Card>
                            <Card.Img variant="top" src={' /images/women.jpg'} />
                            <Card.Body>
                                <Card.Title>Upper Wear</Card.Title>
                                <Card.Text>
                                    Kids Set
                                </Card.Text>
                                <Button variant="danger">Add to Cart</Button>
                                <Button className='text-danger bg-light mx-2'>Buy Now</Button>
                            </Card.Body>
                        </Card>
                    </div>
                </div>
            </div>
        );

    }
}
export default Menpants
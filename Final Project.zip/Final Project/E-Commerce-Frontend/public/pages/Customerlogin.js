import React, { Component } from "react";
import { Link} from 'react-router-dom';
import '../App.css';
import Navigationbar from "../views/Navigationbar";
class Customerlogin extends Component {
    render() {
        return (
            <div className="customerlogin ">
             <Navigationbar />
                <div className="container-fluid row mt-3">
                    <div className="col-md-6 col-12">
                        <img src={'/images/loginimg.png'} width="100%" height="100%" />
                    </div>
                    <form className=" col-md-6 col-12 mt-5 p-5 border shadow">
                        <h3 className="text-uppercase text-center">Login</h3>
                        <div className="form-outline mb-4">
                            <label className="form-label">Email address</label>
                            <input type="email" id="form3Example3" className="form-control form-control-lg"
                                placeholder="Enter email address" />
                        </div>
                        <div className="form-outline mb-3">
                            <label className="form-label" >Password</label>
                            <input type="password" id="form3Example4" className="form-control form-control-lg"
                                placeholder="Enter password" />
                        </div>
                        <div className="text-center text-md-start ">
                          <Link to='/customerhome'><button className="btn btn-primary btn-lg border-rounded w-100 p-2">Login</button></Link>
                            <div className="mt-2">
                                <a href="#!" id="forgot" className="text-body text-decoration-none text-muted">Forgot password?</a>
                    
                            </div>
                            <p className="small fw-bold mt-2 pt-1 mb-0">Don't have an account?<Link  className=" text-danger text-decoration-none" to ='/register'>Register</Link></p>
                        </div>
                    </form>
                </div> 
            </div>
        );
    }
}
export default Customerlogin
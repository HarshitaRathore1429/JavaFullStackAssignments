import react from 'react';
import Sellernavbar from '../views/Sellernavbar';
import {Link} from 'react-router-dom';
function Sellerlogin()
{
    return(
        <div className='sellerlogin'>
            <Sellernavbar />
            <form className="mt-5 p-5 border shadow w-50 m-auto">
                        <h5 className="text-uppercase text-center">Seller Login</h5>
                        <div className="form-outline mb-4">
                            <label className="form-label">Seller Email address</label>
                            <input type="email" className="form-control form-control-lg"
                                placeholder="Enter email address" />
                        </div>
                        <div className="form-outline mb-3">
                            <label className="form-label" >Password</label>
                            <input type="password"  className="form-control form-control-lg"
                                placeholder="Enter password" />
                        </div>
                        <div className="text-center text-md-start ">
                          <Link to='/sellerhome'><button className="btn btn-primary btn-lg border-rounded w-100 p-2">Login</button></Link>
                            <div className="mt-2">
                                <a href="#!" id="forgot" className="text-body text-decoration-none text-muted">Forgot password?</a>
                    
                            </div>
                            <p className="small fw-bold mt-2 pt-1 mb-0">Don't have an account?<Link  className=" text-danger text-decoration-none" to ='/sellerregister'>Register</Link></p>
                        </div>
                    </form>
        </div>
    );
}
export default Sellerlogin
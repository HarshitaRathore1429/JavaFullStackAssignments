import React, { Component } from "react";
import Secondnav from '../views/Secondnav';
import Slider from '../views/Slider';
import Dashboard from "../views/Dashboard";
import Footer from '../views/Footer';
class Customerhome extends Component {
    render() {
        return (
            <div className='customerhome'>
                <Secondnav />
                <Slider />
                <Dashboard />
                <Footer />
            </div>
        );
    }
}
export default Customerhome
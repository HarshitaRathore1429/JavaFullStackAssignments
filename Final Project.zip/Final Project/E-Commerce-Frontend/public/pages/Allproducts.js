import '../App.css';
import {Link} from 'react-router-dom';
function Allproducts() {
  return (
    <div className='allproduct'>
      <nav className='bg-light p-2'>
        <li><Link to='/'><button className='btn btn-outline-success btn1'>Home</button></Link></li>
        </nav>  
      <div className="container-fluid">
          <table className="table table-striped table-hover">
            <thead className="headTable">
            <tr>
              <th >Product Name</th>
              <th >Product Type</th>
              <th >Product Subtype</th>
              <th >Product Price</th>        
              <th >Product Color</th>
              <th >Product Size</th>              
              <th >Product Image</th>
              <th >Delete Product</th>
            </tr>
            </thead>
            <tbody>
            <tr>
              <td>Shirt</td>
              <td>Mens</td>
              <td>Upper wear</td>
              <td>1200</td>        
              <td>Blue</td>
              <td>XL</td>              
              <td><img src={'/images/menshirt.png'} className="imageEdit"/></td>
              <td> <button className="btn btn-outline-danger btn1" type="submit">Delete This Product</button></td>
            </tr>
            <tr>
              <td>T-Shirt</td>
              <td>Mens</td>
              <td>Upper wear</td>
              <td>700</td>        
              <td>Black</td>
              <td>L</td>              
              <td><img src={'/images/mentshirt.png'} className="imageEdit"/></td>
              <td> <button className="btn btn-outline-danger btn1" type="submit">Delete This Product</button></td>
            </tr>
            <tr>
              <td>Kid's T-Shirt</td>
              <td>Kids</td>
              <td>Upper wear</td>
              <td>450</td>        
              <td>white</td>
              <td>S</td>              
              <td><img src={'/images/kidstshirt1.png'} className="imageEdit"/></td>
              <td> <button className="btn btn-outline-danger btn1" type="submit">Delete This Product</button></td>
            </tr>
            <tr>
              <td>Lehenga</td>
              <td>Womens</td>
              <td>Lower wear</td>
              <td>1500</td>        
              <td>Black</td>
              <td>36</td>              
              <td><img src={'/images/lehanga.png'} className="imageEdit"/></td>
              <td> <button className="btn btn-outline-danger btn1" type="submit">Delete This Product</button></td>
            </tr>
            <tr>
              <td>Kurta</td>
              <td>Mens</td>
              <td>Upper wear</td>
              <td>1100</td>        
              <td>Yellow</td>
              <td>L</td>              
              <td><img src={'/images/menkurta1.png'} className="imageEdit"/></td>
              <td> <button className="btn btn-outline-danger btn1" type="submit">Delete This Product</button></td>
            </tr>
            
            </tbody>
          </table>
        </div>
        </div>
  );
}

export default Allproducts
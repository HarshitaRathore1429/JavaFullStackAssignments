import styled from "styled-components";
import Sellerloginnavbar from "../views/Sellerloginnavbar";
const Container = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
`;

const Wrapper = styled.div`
  width: 40%;
  padding: 80px;
  background-color: white;

`;

const Title = styled.h1`
  font-size: 24px;
  font-weight: 300;
  text-align: center;
  padding: 20px;
`;

const Form = styled.form`
  display: flex;
  flex-wrap: wrap;
`;

const Input = styled.input`
  flex: 1;
  min-width: 40%;
  margin: 20px 10px 0px 0px;
  padding: 10px;
`;

const Select = styled.select`
  flex: 1;
  min-width: 40%;
  margin: 20px 10px 0px 0px;
  padding: 10px;
`;
const Label = styled.label`
  flex: 1;
  min-width: 40%;
  margin: 20px 10px 0px 20px;
  padding: 10px;
`;


const Button = styled.button`
  width: 40%;
  border: none;
  padding: 15px 20px;
  background-color: teal;
  color: white;
  cursor: pointer;
  margin:auto;
`;

const Productbottomwearform = () => {
    return (
        <div className="bottomform">
            <Sellerloginnavbar />
            <Container>
                <Wrapper>
                    <Title>Add Product</Title>
                    <Form>
                        <Input placeholder="Product Name" />
                        <Input placeholder="Product Description" />
                        <br></br>
                        <Select placeholder="Category">
                            <option value="Mens">Mens</option>
                            <option value="Womens">Womens</option>
                            <option value="Kids">Kids</option>
                        </Select>

                        <Input placeholder="Price" />
                        <Input placeholder="Color" />
                        <Select placeholder="Size">
                            <option value="24">24</option>
                            <option value="26">26</option>
                            <option value="28">28</option>
                            <option value="30">30</option>
                            <option value="32">32</option>
                            <option value="34">34</option>
                            <option value="36">36</option>
                            <option value="38">38</option>
                            <option value="40">40</option>
                            <option value="42">42</option>

                        </Select>
                        <Label for="img">   Select Product image:</Label>
                        <Input placeholder="Upload Image" input type="file" id="myFile" name="filename"></Input>
                        <br></br>
                        <Button>Submit</Button>
                    </Form>
                    <br></br>
                    <br></br>
            </Wrapper>
       </Container>
       </div>
    );
};

export default Productbottomwearform
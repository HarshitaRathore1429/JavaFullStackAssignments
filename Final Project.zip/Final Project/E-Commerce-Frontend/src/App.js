import About from './pages/About';
import Contact from './pages/Contact';
import Customerregister from './views/Customerregister';
import Menkurta from './pages/Menkurta';
import Navigationbar from './views/Navigationbar';
import Menshirt from './pages/Menshirt';
import Mentshirt from './pages/Mentshirt';
import Menjeans from './pages/Menjeans';
import Mentrouser from './pages/Mentrouser';
import Menpants from './pages/Menpants';
import Womentop from './pages/Womentop';
import Womentshirt from './pages/Womentshirt';
import Womenkurti from './pages/Womenkurti';
import Womenjeans from './pages/Womenjeans';
import Womenplazzo from './pages/Womenplazzo';
import Womenshorts from './pages/Womenshorts';
import Kidsshirt from './pages/Kidsshirt';
import Kidstshirt from './pages/Kidstshirt';
import Kidsbabysuit from './pages/Kidsbabysuit';
import Kidsjeans from './pages/Kidsjeans';
import Kidsshorts from './pages/Kidsshorts';
import Productupperwearform from './pages/Productupperwearform';
import { Routes, Route } from 'react-router-dom';
import Customerlogin from './pages/Customerlogin';
import Home from './views/Home';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import './App.css'
import React, { Component } from 'react';
import Productbottomwearform from './pages/Productbottomwearform';
import Sellerlogin from './pages/Sellerlogin';
import Seller from './pages/Seller';
import Sellerregister from './pages/Sellerregister';
import Sellerhome from './views/Sellerhome';
import Customerhome from './pages/Customerhome';
import Sellerallproduct from './pages/Sellerallproduct';
import Addtocart from './pages/Addtocart';
import Customerloginnavbar from './views/Customerloginnavbar';
import Orderdetails from './pages/Orderdetails';
import Ordertable from './pages/Ordertable';
function App () {
   
    return (
      <div className="App">
        <Routes>
          <Route path='/' element={< Home />}></Route>
          <Route path='/about' element={< About />}></Route>
          <Route path='/customerlogin' element={< Customerlogin />}></Route>
          <Route path='/customerregister' element={< Customerregister />}></Route>
          <Route path='/contact' element={<Contact />}></Route>
          <Route path='/mens/upperwear/shirt' element={< Menshirt />}></Route>
          <Route path='/mens/upperwear/tshirt' element={< Mentshirt />}></Route>
          <Route path='/mens/upperwear/kurta' element={< Menkurta />}></Route>
          <Route path='/mens/bottomwear/jeans' element={< Menjeans />}></Route>
          <Route path='/mens/bottomwear/trouser' element={< Mentrouser />}></Route>
          <Route path='/mens/bottomwear/pants' element={< Menpants />}></Route>
          <Route path='/women/upperwear/top' element={< Womentop />}></Route>
          <Route path='/women/upperwear/tshirt' element={< Womentshirt />}></Route>
          <Route path='/women/upperwear/kurti' element={< Womenkurti />}></Route>
          <Route path='/women/bottomwear/jeans' element={< Womenjeans />}></Route>
          <Route path='/women/bottomwear/plazzo' element={< Womenplazzo />}></Route>
          <Route path='/women/bottomwear/shorts' element={< Womenshorts />}></Route>
          <Route path='/kids/upperwear/shirt' element={< Kidsshirt />}></Route>
          <Route path='/kids/upperwear/tshirt' element={< Kidstshirt />}></Route>
          <Route path='/seller'  element={< Seller />  } ></Route>
          <Route path='/addproductupperwear' element={< Productupperwearform/>}></Route>
          <Route path='/addproductbottomwear' element={<Productbottomwearform/>}></Route>
          <Route path='/kids/upperwear/babysuit' element={< Kidsbabysuit />}></Route>
          <Route path='/kids/bottomwear/jeans' element={< Kidsjeans />}></Route>
          <Route path='/kids/bottomwear/shorts' element={< Kidsshorts />}></Route>
          <Route path='/customerhome' element={<Customerhome/>}></Route>
          <Route path='/sellerlogin' element={<Sellerlogin/>}></Route>
          <Route path='/sellerregister' element={<Sellerregister/>}></Route>
          <Route path='/sellerhome' element={<Sellerhome/>}></Route>
          <Route path='/sellerallproduct' element={<Sellerallproduct/>}></Route>
          <Route path='/customercart' element={<Addtocart/>}></Route>
          <Route path='/customerloginnavbar' elemenet={<Customerloginnavbar/>}></Route>
          <Route path='/addproduct' element={<Addtocart/>}></Route>
          <Route path='/orderdetails' element={<Orderdetails/>}></Route>
          <Route path='/ordertable' element={<Ordertable/>}></Route>
        </Routes>
      </div>
    );
  }
export default App;

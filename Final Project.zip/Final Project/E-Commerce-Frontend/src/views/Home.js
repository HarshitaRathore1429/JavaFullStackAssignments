import React, { Component } from "react";
import Secondnav from './Secondnav';
import Slider from './Slider';
import Dashboard from "./Dashboard";
import Navigationbar from './Navigationbar';
import Footer from './Footer';
class Home extends Component {
    render() {
        return (
            <div className='home'>
                <Navigationbar />
                <Slider />
                <Dashboard />
                <Footer />
            </div>
        );
    }
}
export default Home
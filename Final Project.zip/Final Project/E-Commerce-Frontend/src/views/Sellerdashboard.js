import React, { Component, useEffect, useState } from "react";
import { useNavigate } from 'react-router-dom';


export default function Sellerdashboard() {

    const navigate = useNavigate();
    const [email, setEmail] = useState(localStorage.getItem("seller_id"));
    const [allProducts, setAllProducts] = useState([]);
    const [currentSellerId, setSellerId] = useState('');

    var upperwear = 0;
    var bottomwear = 0;
    useEffect(() => {

        if (localStorage.getItem("seller_id") === "null") {
            navigate("/");
        } else {
            const seller = { email };
            fetch("http://localhost:8080/seller/getSellerId", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(seller)
            }).then(res => res.json())
                .then((result) => {
                    setSellerId(result)
                });

            fetch("http://localhost:8080/product/getProducts")
                .then(res => res.json())
                .then((result) => {
                    setAllProducts(result);
                })
        }

    })
    allProducts.map(countUpperWear)

    function countUpperWear(product) {
        if (product.sellerId == currentSellerId && product.type == "Upper Wear") {
            upperwear = upperwear + 1;
        }
        if (product.sellerId == currentSellerId && product.type == "Bottom Wear") {
            bottomwear = bottomwear + 1;
        }
        document.getElementById("upper").innerHTML = upperwear;
        document.getElementById("bottom").innerHTML = bottomwear;
    }


    return (
        <div className="sellerdashboard mt-5">
            <div className="pt-5">
                <h1 className="text-center">Welcome Seller</h1>
                <div className=' mt-3 card shadow bg-light text-center rounded-5 border-3 border-dark mb-5' >
                    <div className='content text-dark'>
                        <h2 className=' fs-1'><span id="upper"></span></h2>
                        <p>Upper wear products listed till now</p>
                    </div>
                </div>
                <div className='card shadow bg-light text-center rounded-5 border-3 border-dark mb-5' >
                <div className='content text-dark'>
                    <h2 className=' fs-1'><span id="bottom"></span></h2>
                    <p>Bottom wear products listed till now</p>
                </div>
            </div>
        </div>
        </div>
    );

}
import {Nav} from 'react-bootstrap';
import {Link} from 'react-router-dom';
import {Navbar} from 'react-bootstrap';
function Sellernavbar() {
  return (
<div className='sellernavbar'>
            <Navbar className='sellernavbar bg-primary' expand="md">
            <Navbar.Brand><Nav.Link className="navbar-brand navhead"><Link className='text-light text-decoration-none' to='/'>Yash Store<i class="fa-solid fa-bag-shopping mx-3"></i></Link></Nav.Link></Navbar.Brand>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav">
                    <Nav className='ms-auto'>
                        <Nav.Link><button className='btn bg-light rounded px-3 mx-3'><Link className='text-primary text-decoration-none ' to='/'>Customer</Link></button></Nav.Link>
                        <Nav.Link><button className='btn bg-light rounded mx-3 px-3'><Link className='text-primary text-decoration-none ' to='/sellerlogin'>Login</Link></button></Nav.Link>
                        <Nav.Link><button className=' btn bg-light px-3 rounded mx-3'><Link className='text-primary text-decoration-none ' to='/sellerregister'>Register</Link></button></Nav.Link>
                    </Nav>
                </Navbar.Collapse>
            </Navbar>
        </div>
  );
}

export default Sellernavbar;
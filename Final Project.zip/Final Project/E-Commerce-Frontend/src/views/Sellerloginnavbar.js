import React from 'react';
import { Link } from 'react-router-dom';
import { NavDropdown } from 'react-bootstrap';
import {Nav} from 'react-bootstrap';
import {Navbar} from 'react-bootstrap';
function Sellerloginnavbar() {
    return (
        <div className='sellerloginnavbar '>
            <Navbar className='sellernavbar bg-primary fixed-top' expand="md">
                <Navbar.Brand><Nav.Link className="navbar-brand navhead"><Link className='text-light text-decoration-none' to='/sellerhome'>Yash Store<i class="fa-solid fa-bag-shopping mx-3"></i></Link></Nav.Link></Navbar.Brand>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav">
                    <Nav className='ms-auto'>
                        <Nav.Link><NavDropdown id="basic-nav-dropdown" className='text-primary rounded bg-light px-2 ' title={
                                    <span className="text-primary">Add Product</span>}>
                            <NavDropdown.Item ><Link className='text-dark text-decoration-none' to='/addproductupperwear'>Upper wear</Link></NavDropdown.Item>
                            <NavDropdown.Item><Link className='text-dark text-decoration-none' to='/addproductbottomwear'>Bottom wear</Link></NavDropdown.Item>
                        </NavDropdown></Nav.Link>
                        <Nav.Link><button className='btn bg-light rounded p-2'><Link className='text-primary text-decoration-none bg-light p-2 mx-2' to='/sellerallproduct'>All Product</Link></button></Nav.Link>
                        <Nav.Link><button className=' btn bg-light rounded p-2'><Link className='text-primary text-decoration-none  p-2 mx-2' to='/seller'>Logout</Link></button></Nav.Link>
                    </Nav>
                </Navbar.Collapse>
            </Navbar>
        </div>
    );
}
export default Sellerloginnavbar
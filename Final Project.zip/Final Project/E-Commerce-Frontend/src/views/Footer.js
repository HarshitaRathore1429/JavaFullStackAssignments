import React, { Component } from 'react';
import {Link} from 'react-router-dom';
class Footer extends Component {
    render() {
        return (
            <div className='footer bg-primary'>
            <footer  className='text-center text-lg-start text-muted'  >
            <div className='d-flex justify-content-center justify-content-lg-between p-4 border-bottom' style={{color:"white"}}>
              <div className='me-5 d-none d-lg-block'>
                <span>Get connected with us on social networks:</span>
              </div>
      
              <div>
                <a href='' className='me-4 text-reset'>
                  <i className='fab fa-facebook-f'></i>
                </a>
                <a href='' className='me-4 text-reset'>
                  <i className='fab fa-twitter'></i>
                </a>
                <a href='' className='me-4 text-reset'>
                  <i className='fab fa-google'></i>
                </a>
                <a href='' className='me-4 text-reset'>
                  <i className='fab fa-instagram'></i>
                </a>
      
              </div>
            </div>
      
            <section className=''>
              <div className='container text-center text-md-start mt-5'>
                <div className='row'>
                  <div className='col-md-3 col-lg-4 col-xl-3 mx-auto'>
                    <h6 className='text-uppercase fw-bold mb-4'>
                      
                      <span style={{color:"white"}}>E-Commerce</span>
                    </h6>
                    <p style={{color:"white"}}>
                   E-Commerce is a shopping website which have a category of fashion of mens, women and kids.
                    </p>
                  </div>
      
      
      
                  <div className='col-md-3 col-lg-2 col-xl-2 mx-auto mb-4'>
                    <h6 className='text-uppercase fw-bold mb-4' style={{ color: "white" }} >Useful links</h6>
                    <p>
                      <Link to='/about' className='text-light text-decoration-none'>About</Link>
                    </p>
                    <p>
                        <Link to='/contact' className='text-light text-decoration-none'>Contact</Link>
                    </p>
                  </div>
      
                  <div className='col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4' style={{ color: "white" }}>
                    <h6 className='text-uppercase fw-bold mb-4'>Contact</h6>
                    <p>
                      <i className='fas fa-home me-3'></i>Indore, M.P, India..
                    </p>
                    <p>
                      <i className='fas fa-envelope me-3'></i>
                      ecommerce@gmail.com
                    </p>
                    <p>
                      <i className='fas fa-phone me-3'></i>+91 9479695178
                    </p>
                  </div>
                </div>
              </div>
            </section>
      
            <div className='text-center p-4' style={{ color: "white"  }}>
              © 2021 Copyright:
              <Link to='/' className='text-reset fw-bold'>
                E-Commerce.com
              </Link>
            </div>
          </footer>
          </div>
        );
    }
}
export default Footer
import React, { Component } from "react";
import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import {Navbar} from 'react-bootstrap';
import {Nav} from 'react-bootstrap';
class Navigationbar extends Component {
  render() {
    return (
      <Navbar expand="md" className="bg-primary fixed-top">
        <Navbar.Brand><Nav.Link className="navbar-brand navhead"><Link className='text-light text-decoration-none' to='/'>Yash Store<i class="fa-solid fa-bag-shopping mx-2"></i></Link></Nav.Link></Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className='ms-auto'>
            <Nav.Link><Link className="text-light text-uppercase text-decoration-none mx-1" to='/'><i className="fas fa-home mx-1" aria-hidden="true"></i>Home</Link></Nav.Link>
            <Nav.Link><Link className="text-light text-uppercase text-decoration-none mx-1" to='/customerlogin'><i className="fas fa-user mx-1" aria-hidden="true"></i>Login</Link></Nav.Link>
            <Nav.Link><Link className="text-light text-uppercase text-decoration-none mx-1" to='/customerregister'><i className="fas fa-user-plus mx-1" aria-hidden="true"></i>Registration</Link></Nav.Link>
            <Nav.Link><Link className="text-light text-uppercase text-decoration-none mx-3" to='/seller'><i className="fas fa-store mx-1"></i>Become a seller</Link></Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Navbar>
    );
  }
}
export default Navigationbar
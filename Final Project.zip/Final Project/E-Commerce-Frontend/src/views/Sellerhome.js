import React from "react";
import Sellerloginnavbar from '../views/Sellerloginnavbar';
import Footer from "../views/Footer";
import Sellerlogin from "../pages/Sellerlogin";
import Sellerdashboard from "./Sellerdashboard";
function Sellerhome() {
    return (
        <div className="sellerhome">
            <Sellerloginnavbar />
            <Sellerdashboard />
            <Footer/>
        </div>
    );
}
export default Sellerhome
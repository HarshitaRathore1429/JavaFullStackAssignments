import React from 'react';
import { useState } from 'react';
import Navigationbar from '../views/Navigationbar';
import { Link, useNavigate } from 'react-router-dom';

export default function Customerregister() {

    const [fname, setFname] = useState('');
    const [lname, setLname] = useState('');
    const [gender, setGender] = useState('Male');
    const [email, setEmail] = useState('');
    const [phone, setPhone] = useState();
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const navigate = useNavigate();

    const handleClick = (e) => {
        e.preventDefault();
        if(phone.length>10 )
        {
            alert("Please enter a valid phone no.")
        }else if(phone.length<10){
            alert("Please enter a valid phone no.")
        }else{
        const customeremail = {email};
        fetch("http://localhost:8080/customer/customer_exist", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(customeremail)
        }).then(res => res.text())
            .then((result) => {
                if("Customer already registered!"==result){
                    alert(result)
                }else{
                    if (password === confirmPassword) {
                        document.getElementById("myH1").disabled = true;
                        fetch("http://localhost:8080/customer/getOtp", {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({ email })
                        }).then(res => res.text())
                            .then((result) => {
                                let inputOtp = prompt("Enter OTP");
                                let check=2;
                                while(inputOtp != result && check>0){
                                    inputOtp = prompt("Enter OTP (" +check+" attempt left)");
                                    check--;
                                }
                                if(check==0)
                                {
                                    document.getElementById("myH1").disabled = false;
                                }
                                if (inputOtp == result) {
                                    const customer = { fname, lname, gender, email, phone, password };
                                    fetch("http://localhost:8080/customer/register", {
                                        method: "POST",
                                        headers: { "Content-Type": "application/json" },
                                        body: JSON.stringify(customer)
                                    }).then(res => res.text())
                                        .then((result) => {
                                            alert(result);
                                        });
                                    navigate('/customerlogin');
                                }
                            });
                    } else {
                        alert("Password and Confirm Password is not equal");
                    }
                }
            });

        
    }}

    return (
        <section>
            <div className="customerregister ">
                <Navigationbar />
                <div className='pt-4 mt-5'>

                    <form onSubmit={handleClick} className=' col-md-6 offset-md-3 rounded-5 border-dark p-5 border shadow  p-5 text-start mb-5 border-2'>
                        <h4 className='text-center'>Customer Register</h4>

                        <div className="form-group form-row">
                            <label className="col-sm-4 form-control-label m-2" >First Name</label>
                            <input type="text" className="form-control m-2" placeholder='Enter your first name' required onChange={(e) => setFname(e.target.value)} />
                        </div>

                        <div className="form-group form-row">
                            <label className="col-sm-4 form-control-label m-2">Last Name</label>
                            <input type="text" className="form-control m-2" placeholder='Enter your last name' required onChange={(e) => setLname(e.target.value)} />
                        </div>

                        <label className='m-2'>Gender</label>
                        <select className=' form-select m-2' aria-label="Default select example" required onChange={(e) => setGender(e.target.value)} >
                            <option value="Male" selected >Male</option>
                            <option value="Female" >Female</option>
                        </select>

                        <div className="form-group form-row">
                            <label className="col-sm-4 form-control-label m-2">Email Id</label>
                            <input type="email" name="userid" className="form-control m-2" placeholder='Enter your email id' required onChange={(e) => setEmail(e.target.value)} />
                        </div>

                        <div className="form-group form-row">
                            <label className="col-sm-4 form-control-label m-2">Phone</label>
                            <input type="number" maxLength={10} name="phone" className="form-control m-2" placeholder='Enter your phone number' required onChange={(e) => setPhone(e.target.value)} />
                        </div>

                        <div className="form-group form-row">
                            <label className="col-sm-4 form-control-label m-2">Password</label>
                            <input type="password" name="pwd" className="form-control m-2" placeholder='Enter your password' required onChange={(e) => setPassword(e.target.value)} />
                        </div>

                        <div className="form-group form-row">
                            <label className="col-sm-4 form-control-label m-2">Confirm Password</label>
                            <input type="password" name="cpwd" className="form-control m-2" placeholder='Enter your password again' required
                                onBlur={(e) => { if (e.target.value === password) { setConfirmPassword(e.target.value) } else { alert("password mismatch") } }} />
                        </div>
                        <div className='text-center'>
                        <button type="submit" id="myH1" className="btn bg-primary text-light float-right mt-4 px-5">Register Now</button>
                        </div>
                    </form>

                </div>
            </div>
        </section>
    )
}
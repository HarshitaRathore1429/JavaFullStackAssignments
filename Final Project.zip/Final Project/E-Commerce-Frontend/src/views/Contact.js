import React,{Component} from 'react';
class Contact extends Component {
    render() {
        return (
            <form className=" col-md-6 offset-md-3 border-dark border-2 shadow mt-5 rounded p-3">
                <h3 className="text-uppercase text-center">Conatct Us</h3>
                <div className="form-outline mb-4">
                    <label className="form-label">Name</label>
                    <input type="email" id="form3Example3" className="form-control form-control-lg"/>
                    <label className="form-label">Email</label>
                    <input type="email" id="form3Example3" className="form-control form-control-lg"/>
                </div>
                <div className="form-outline mb-3">
                    <label className="form-label" >Mobile Number</label>
                    <input type="number" id="form3Example4" className="form-control form-control-lg"
                         />
                </div>
                <label className="form-label" >Write your query</label><br></br>
                <textarea className="form-control form-control-lg"></textarea>
                <div className="text-center text-md-start mt-2 ">
                    <button className="btn btn-primary btn-lg border-rounded w-100 p-1">Submit</button>
                </div>
            </form>
        );
    }
} 
export default Contact

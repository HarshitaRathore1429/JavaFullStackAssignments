import React,{useState} from 'react';
import { Nav } from 'react-bootstrap';
import { Navbar } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import {useNavigate} from 'react-router-dom';
import {useEffect} from 'react';
import Footer from './Footer';
function Customerloginnavbar() {

    const [email, setEmail] = useState(localStorage.getItem("customer_id"));

    const navigate = useNavigate();
    useEffect(() => {
        if (localStorage.getItem("customer_id") === "null") {
            navigate("/");
        }
        const customerName={email};
        fetch("http://localhost:8080/customer/getCustomerName", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(customerName)
        }).then(res => res.text())
            .then((result) => document.getElementById("name").innerHTML=result)
    })

    const handleClick = (e) => {
        localStorage.setItem("customer_id", "null");
        navigate("/");
    }
    return (
        <div className='customerloginnavbar'>
            <Navbar className='customernav bg-primary fixed-top' expand="md">
                <Navbar.Brand><Nav.Link className="navbar-brand navhead"><Link className='text-light text-decoration-none' to='/customerhome'>Yash Store<i class="fa-solid fa-bag-shopping  mx-3"></i></Link></Nav.Link></Navbar.Brand>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav">
                    <Nav className='ms-auto'>
                        <Nav.Link className='text-light mx-3 mt-1 ' >Welcome! <span id="name" className='fw-bold'>Customer</span></Nav.Link>
                        <Nav.Link className='mt-1'><Link className='text-light text-decoration-none mx-3 ' to='/customerhome'>Home</Link></Nav.Link>
                        <Nav.Link className="mt-1"><Link className='text-light text-decoration-none mx-3' to='/ordertable'>Orders</Link></Nav.Link>
                        <Nav.Link><button onClick={handleClick} className=' btn bg-light  rounded mx-3 '><Link className='text-primary text-decoration-none' to='/customerlogin'>Logout</Link></button></Nav.Link>
                    </Nav>
                </Navbar.Collapse>
            </Navbar>
        </div>
    );
}
export default Customerloginnavbar
import React, { Component, useEffect, useState } from 'react';
import { Card } from 'react-bootstrap';
import { Button } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

function Dashboard() {

    const [products, setProducts] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        if(localStorage.getItem("customer_id") === "null"){
            localStorage.setItem("price",2000);
        }
        
        fetch("http://localhost:8080/product/getProducts")
            .then(res => res.json())
            .then((result) => {
                setProducts(result);
            })
    })

    const [email, setEmail] = useState(localStorage.getItem("customer_id"));
    const [pid, setPid] = useState('');
    const [cid, setCid] = useState('');

    const handleClick = (e) => {
        if (localStorage.getItem("customer_id") === "null") {
            navigate("/customerlogin");
        }
        
        e.preventDefault();
        const customer = { email };
        fetch("http://localhost:8080/customer/getCustomerId", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(customer)
        }).then(res => res.json())
            .then((result) => {
                setCid(result)
            });
        if (cid !== '') {
            let customerId = cid;
            let productId = pid;
            let customer = { customerId, productId };
            fetch("http://localhost:8080/cart/add", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(customer)
            }).then(res => res.text())
                .then((result) => {
                    alert(result);
                });
        }
    }
    return (
        <div className='nav123'>
            <div className='row m-2 mt-1'>

                {products.map(product => {

                    return (product.price <= localStorage.getItem("price")) ?

                        <div className='col-6 col-md-2 mt-5 mb-5'>
                            <Card className='shadow-lg card'>
                                <Card.Img  variant="top" src={' /productImages/'+product.imageName} height="180vh" />
                                <Card.Body>
                                    <Card.Title>{product.name}</Card.Title>
                                    <Card.Text>
                                        <div className='productDescription'>
                                            {product.description}
                                        </div>
                                        <div className='row'>
                                            <div className='col-8'>
                                                {product.colour}
                                            </div>
                                            <div className='col-4'>
                                                {product.size}
                                            </div>
                                        </div>
                                        <p className='fw-bold'>
                                            ₹ {product.price}</p>

                                    </Card.Text>
                                    <Button id="addButton" onMouseOver={(e) => setPid(product.id)} onClick={handleClick}>Add to Cart</Button>
                                </Card.Body>
                            </Card>
                        </div>
                        :
                        <></>
                })}
            </div>
            <center><h5>No products to show</h5><br/></center>
        </div>
    );
}

export default Dashboard
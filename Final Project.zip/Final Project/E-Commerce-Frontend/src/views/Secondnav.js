import react, { Component } from 'react';
import { Link } from 'react-router-dom';
import { Nav } from 'react-bootstrap';
import { Container } from 'react-bootstrap';
import { Navbar } from 'react-bootstrap';
import { NavDropdown } from 'react-bootstrap';
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';



function Secondnav() {
    const navigate = useNavigate();
    const [email, setEmail] = useState(localStorage.getItem("customer_id"));
    const [customerCart, setCustomerCart] = useState([]);
    const [customerId, setCustomerId] = useState('');
    const [price,setPrice]=useState('')

    useEffect(() => {

        if (localStorage.getItem("customer_id") === "null") {
            navigate("/");
        } else {

            const customer = { email };
            fetch("http://localhost:8080/customer/getCustomerId", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(customer)
            }).then(res => res.json())
                .then((result) => {
                    setCustomerId(result)
                });

            const sendCustomerId = { customerId };
            fetch("http://localhost:8080/cart/getCustomerCart", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(sendCustomerId)
            }).then(res => res.json())
                .then((result) => {
                    setCustomerCart(result)
                });
        }
    })
    const quant = customerCart.length;
    const valueChange = () => {
        const slider = document.getElementById("range");
        localStorage.setItem("price", slider.value);
        var output = document.getElementById("demo");
        output.innerHTML = slider.value;
        slider.oninput = function () {
            output.innerHTML = this.value;
        }
    }

    return (
        <div className='navitwo'>
            <Navbar expand="md" id="navtwo" className='border-bottom mt-5'>
                <Container className='mt-3'>
                    <Navbar.Toggle aria-controls="basic-navbar-nav" />
                    <Navbar.Collapse id="basic-navbar-nav">
                        <Nav className="navi border-down">
                            <NavDropdown id="basic-nav-dropdown" className='mx-3 ' title={
                                <span className="text-dark my-auto fw-bold">Men</span>
                            }>
                                <NavDropdown id="basic-nav-dropdown" title={
                                    <span className="text-dark my-auto fw-bold">Upper wear</span>
                                } drop="end">
                                    <NavDropdown.Item><Link className='text-dark text-decoration-none' to='/mens/upperwear/shirt'>Shirt</Link></NavDropdown.Item>
                                    <NavDropdown.Item><Link className='text-dark text-decoration-none' to="/mens/upperwear/tshirt">T-Shirt</Link></NavDropdown.Item>
                                    <NavDropdown.Item><Link className='text-dark text-decoration-none' to="/mens/upperwear/kurta">Kurta</Link></NavDropdown.Item>
                                </NavDropdown>
                                <NavDropdown id="basic-nav-dropdown" title={
                                    <span className="text-dark my-auto fw-bold">Bottom wear</span>
                                } drop="end">
                                    <NavDropdown.Item> <Link className='text-dark text-decoration-none' to="/mens/bottomwear/jeans">Jeans</Link></NavDropdown.Item>
                                    <NavDropdown.Item>  <Link className='text-dark text-decoration-none' to="/mens/bottomwear/trouser">Trouser</Link></NavDropdown.Item>
                                    <NavDropdown.Item>  <Link className='text-dark text-decoration-none' to="/mens/bottomwear/pants">Pants</Link></NavDropdown.Item>
                                </NavDropdown>
                            </NavDropdown>
                            <NavDropdown id="basic-nav-dropdown m-5" className='mx-3 ' title={
                                <span className="text-dark my-auto fw-bold">Women</span>
                            }>
                                <NavDropdown id="basic-nav-dropdown" title={
                                    <span className="text-dark my-auto fw-bold">Upper wear</span>
                                } drop="end">
                                    <NavDropdown.Item> <Link className='text-dark text-decoration-none' to="/women/upperwear/top">Top</Link></NavDropdown.Item>
                                    <NavDropdown.Item>  <Link className='text-dark text-decoration-none' to="/women/upperwear/tshirt">Shirt</Link></NavDropdown.Item>
                                    <NavDropdown.Item>  <Link className='text-dark text-decoration-none' to="/women/upperwear/kurti">Kurti</Link></NavDropdown.Item>
                                </NavDropdown>
                                <NavDropdown id="basic-nav-dropdown" title={
                                    <span className="text-dark my-auto fw-bold">Bottom wear</span>
                                } drop="end">
                                    <NavDropdown.Item> <Link className='text-dark text-decoration-none' to="/women/bottomwear/jeans">Jeans</Link></NavDropdown.Item>
                                    <NavDropdown.Item>  <Link className='text-dark text-decoration-none' to="/women/bottomwear/plazzo">Plazzo</Link></NavDropdown.Item>
                                    <NavDropdown.Item>  <Link className='text-dark text-decoration-none' to="/women/bottomwear/shorts">Shorts</Link></NavDropdown.Item>
                                </NavDropdown>
                            </NavDropdown>
                            <NavDropdown id="basic-nav-dropdown mx-2" className='mx-3' title={
                                <span className="text-dark my-auto fw-bold">Kids</span>
                            }>
                                <NavDropdown id="basic-nav-dropdown" title={
                                    <span className="text-dark my-auto fw-bold">Upper wear</span>
                                } drop="end">
                                    <NavDropdown.Item> <Link className='text-dark text-decoration-none' to="/kids/upperwear/shirt">Shirt</Link></NavDropdown.Item>
                                    <NavDropdown.Item>  <Link className='text-dark text-decoration-none' to="/kids/upperwear/tshirt">T-Shirt</Link></NavDropdown.Item>
                                    <NavDropdown.Item>  <Link className='text-dark text-decoration-none' to="/kids/upperwear/babysuit">Baby Suit</Link></NavDropdown.Item>
                                </NavDropdown>
                                <NavDropdown id="basic-nav-dropdown" title={
                                    <span className="text-dark my-auto fw-bold">Bottom wear</span>
                                } drop="end">
                                    <NavDropdown.Item> <Link className='text-dark text-decoration-none' to="/kids/bottomwear/jeans">Jeans</Link></NavDropdown.Item>
                                    <NavDropdown.Item>  <Link className='text-dark text-decoration-none' to="/kids/bottomwear/shorts">Shorts</Link></NavDropdown.Item>
                                </NavDropdown>
                            </NavDropdown>
                        </Nav>
                        <Nav className=' ms-auto '>
                            <Nav.Link><span className='text-dark text-decoration-none fw-bold mx-2 '>Price</span>
                                <input type="range" name="income" min="200" max="2000" id="range" onChange={valueChange}/>
                                    <span id="demo">2000</span></Nav.Link>
                            <Nav.Link><Link className='text-dark' to='/addproduct'><i class="fa-solid fa-cart-plus fs-4"></i></Link></Nav.Link>{quant}
                        </Nav>

                    </Navbar.Collapse>
                </Container>
            </Navbar>
        </div>
    );
}

export default Secondnav
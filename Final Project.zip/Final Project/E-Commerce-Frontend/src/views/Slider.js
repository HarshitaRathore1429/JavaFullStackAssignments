import React, { Component } from 'react';
import { Carousel } from 'react-bootstrap';
class Slider extends Component {
    render() {
        return (
            <div className='slide p-2 mt-5'>
                <Carousel className='mt-3'>
                    <Carousel.Item>
                        <img className="d-block w-100" src={'/images/Slider1.png'}/>
                    </Carousel.Item>
                    <Carousel.Item>
                        <img className="d-block w-100" src={'/images/Slide2.png'} />
                    </Carousel.Item>
                    <Carousel.Item>
                        <img className='d-block w-100' src={'/images/Slider3.png'} />
                    </Carousel.Item>
                </Carousel>
            </div>
        );
    }
}
export default Slider
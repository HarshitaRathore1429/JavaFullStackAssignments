import React, { Component } from 'react';
import { Card } from 'react-bootstrap';
import { Button } from 'react-bootstrap';
import Secondnav from '../views/Secondnav';
import Footer from '../views/Footer';
import Customerloginnavbar from '../views/Customerloginnavbar';
import { useEffect,useState } from 'react';
export default function Menjeans() {

    const [products, setProducts] = useState([]);

    useEffect(() => {
        fetch("http://localhost:8080/product/getProducts")
            .then(res => res.json())
            .then((result) => {
                setProducts(result);
            })
    })

    const [email, setEmail] = useState(localStorage.getItem("customer_id"));
    const [pid, setPid] = useState('');
    const [cid, setCid] = useState('');
    const [shirt, setShirt] = useState('Shirt');

    const handleClick = (e) => {
        e.preventDefault();
        const customer = { email };
        fetch("http://localhost:8080/customer/getCustomerId", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(customer)
        }).then(res => res.json())
            .then((result) => {
                setCid(result)
            });
        if (cid !== '') {
            let customerId = cid;
            let productId = pid;
            
            let customer = { customerId, productId };
            fetch("http://localhost:8080/cart/add", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(customer)
            }).then(res => res.text())
                .then((result) => {
                    alert(result);
                });
        }


    }

    return (
        <div className='nav123'>
            <Customerloginnavbar />
            <Secondnav/>
            <div className='row m-2 mt-2'>
                {products.map(product => {
                    return (product.name == "Jeans" && product.idealFor == "Men") ?
                        <div className='col-6 col-md-2 mt-3 card'>
                            <Card className='shadow-lg'>
                                <Card.Img variant="top" src={' /productImages/'+product.imageName} height="180vh" />
                                <Card.Body>
                                    <Card.Title>{product.name}</Card.Title>
                                    <Card.Text>
                                        <div className='productDescription'>
                                            {product.description}
                                        </div>
                                        <div className='row'>
                                            <div className='col-8'>
                                                {product.colour}
                                            </div>
                                            <div className='col-4'>
                                                {product.size}
                                            </div>
                                        </div>
                                        <p className='fw-bold'>
                                            ₹ {product.price}</p>

                                    </Card.Text>
                                    <Button variant="primary" onMouseOver={(e) => setPid(product.id)} onClick={handleClick}>Add to Cart</Button>
                                </Card.Body>
                            </Card>
                        </div>
                        :
                        <></>
                })



                }

            </div>
            <Footer />
        </div>
    );
}

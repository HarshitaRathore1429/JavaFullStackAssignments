import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom'
import Customerloginnavbar from "../views/Customerloginnavbar";
import QRCode from 'qrcode.react'

function Orderdetails() {

    const navigate = useNavigate();
    const [email, setEmail] = useState(localStorage.getItem("customer_id"));
    const [customerCart, setCustomerCart] = useState([]);
    const [customerId, setCustomerId] = useState('');
    var current = new Date();
    var time = current.toLocaleTimeString();
    var date = current.toLocaleDateString();

    const [houseNo, setHouseNo] = useState('');
    const [street, setStreet] = useState('');
    const [colony, setColony] = useState('');
    const [city, setCity] = useState('Indore');
    const [state, setState] = useState('Madhya Pradesh');
    const [pinCode, setPinCode] = useState('');
    const [country, setCountry] = useState('');

    const address = houseNo + ", " + street + ", " + ", " + colony + ", " + city + ", " + state + ", " + pinCode + ", " + country

    useEffect(() => {

        if (localStorage.getItem("customer_id") === "null") {
            navigate("/");
        } else {
            const customer = { email };
            fetch("http://localhost:8080/customer/getCustomerId", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(customer)
            }).then(res => res.json())
                .then((result) => {
                    setCustomerId(result)
                });

            const sendCustomerId = { customerId };
            fetch("http://localhost:8080/cart/getCustomerCart", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(sendCustomerId)
            }).then(res => res.json())
                .then((result) => {
                    setCustomerCart(result)
                });

        }
    })

    const quantity = customerCart.length;
    var price = 0;

    customerCart.map(total);

    function total(cart) {
        price = price + cart.price;
    }

    var allProductsName = '';

    customerCart.map(name);

    function name(cart) {
        if (allProductsName == '') {
            allProductsName = allProductsName + cart.description;
        } else {
            allProductsName = allProductsName + ", " + cart.description;
        }

    }


    const handleClick = (e) => {
        e.preventDefault();
        const sendAllOrder = { customerId, date, time, quantity, price, allProductsName, address };
        fetch("http://localhost:8080/customer/addOrder", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(sendAllOrder)
        }).then(res => res.text())
            .then((result) => {
                alert(result)
            });
        const customerRemoveCartId={customerId}
        fetch("http://localhost:8080/cart/removeAllCartProducts", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(customerRemoveCartId)
        }).then(res => res.text())
            .then((result) => {
                
            });
            navigate("/ordertable")
    }
    const generateQR = "Your total amount is: " + price;

    const [isDisabled, setIsDisabled] = useState(true);
    const [checked, setChecked] = useState(false)

    const dataSubmit = () => {
        return checked ? setIsDisabled(true) : setIsDisabled(false);
    };

    const onCheckboxClick = () => {
        setChecked(!checked);
        return dataSubmit();
    };
    return (
        <div className='orderdetails'>
            <Customerloginnavbar />
            <div className='FormDivison  shadow-lg'>
                <form onSubmit={handleClick}>
                    <h1 className="H1style">Order Details</h1>
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Receiver's Name</label>
                        <div class="row">
                            <div class="col-6 col-md-6">
                                <input type="text" class="form-control" placeholder="First name" aria-label="First name" required />
                            </div>
                            <div class="col-6 col-md-6">
                                <input type="text" class="form-control" placeholder="Last name" aria-label="Last name" required/>
                            </div>
                        </div>
                    </div>
                    <div class=" col-12 mb-3">
                        <label for="exampleInputEmail1" class="form-label">Email address</label>
                        <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com" required/>
                    </div>
                    <div class=" col-12mb-3">
                        <label for="exampleInputEmail1" class="form-label">Contact Number</label>
                        <input type="number" class="form-control" id="exampleFormControlInput1" placeholder="Enter your mobile number" required/>
                    </div>
                    <div class=" col-12 mb-3">
                        <label for="exampleInputEmail1" class="form-label">Delivery address</label>
                        <div class="row">
                            <div class="col-4 col-md-3">
                                <input type="text" class="form-control" placeholder="House no." onChange={(e) => setHouseNo(e.target.value)} aria-label="First name" required/>
                            </div>
                            <div class="col-4 col-md-3">
                                <input type="text" class="form-control" placeholder="Street" onChange={(e) => setStreet(e.target.value)} aria-label="Last name" required/>
                            </div>
                            <div class="col-4 col-md-3">
                                <input type="text" class="form-control" placeholder="Colony/Residency" onChange={(e) => setColony(e.target.value)} aria-label="First name" />
                            </div>
                            <div class="col-4 col-md-3">
                                <input type="text" class="form-control" placeholder="Nearest Landmark" aria-label="First name" required/>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6 col-md-6">
                                < select id="select" className='form-control add' placeholder="State" onChange={(e) => setCity(e.target.value)} >
                                    <option value="Indore" selected>Indore</option>
                                    <option value="Bhopal" >Bhopal</option>
                                    <option value="Sehore" >Sehore</option>
                                    <option value="Jabalpur" >Jabalpur</option>
                                    <option value="Satna" >Satna</option>
                                    <option value="Ujjain" >Ujjain</option>
                                    <option value="Dewas" >Dewas</option>
                                    <option value="Pune" >Pune</option>
                                    <option value="Solapur">Solapur</option>
                                    <option value="Nashik" >Nashik</option>
                                    <option value="Thane">Thane</option>
                                    <option value="Nagpur" >Nagpur</option>
                                </select>
                            </div>
                            <div class="col-6 col-md-6">
                                < select id="select" className='form-control add' placeholder="State" onChange={(e) => setState(e.target.value)} >
                                    <option value="Madhya Pradesh" selected>Madhya Pradesh</option>
                                    <option value="Maharashtra" >Maharashtra</option>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6 col-md-6">
                                <input type="text" class="form-control add" placeholder="PIN code" onChange={(e) => setPinCode(e.target.value)} aria-label="First name" required/>
                            </div>
                            <div class="col-6 col-md-6">
                                <input type="text" class="form-control add" placeholder="Country" onChange={(e) => setCountry(e.target.value)} aria-label="Last name" required/>
                            </div>
                        </div>
                    </div>
                    <div className="text-center">
                        <QRCode value={generateQR}></QRCode><br></br>
                        <input type="checkbox" onClick={onCheckboxClick} />If payment done check this<br></br>
                        <button type="submit" class="btn bg-primary" disabled={isDisabled} >Submit</button>
                    </div>
                </form>
            </div>
        </div>
    );
}
export default Orderdetails
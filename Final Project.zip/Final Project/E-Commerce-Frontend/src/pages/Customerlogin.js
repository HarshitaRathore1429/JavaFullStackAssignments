import React from 'react';
import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import '../App.css';
import Footer from '../views/Footer';
import Navigationbar from "../views/Navigationbar";

function Customerlogin() {

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate();
    
    useEffect(() => {

        if (localStorage.getItem("customer_id") != "null") {
            navigate("/customerhome");
        }
    })
    const handleClick = (e) => {
        e.preventDefault();
        const customer = { email, password };
        fetch("http://localhost:8080/customer/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(customer)
        }).then(res => res.text())
            .then((result) => {

                if (result === "Customer successfully logged in!") {
                    localStorage.setItem("customer_id", email);
                    navigate('/customerhome');
                } else {
                    alert(result);
                }
            });
    }

    return (
        <div className="customerlogin ">
            <Navigationbar />
            <div className="container-fluid row mt-5 ">
                <div className="col-md-6 col-12">
                    <img src={'/images/loginimg.png'} width="100%" height="100%" />
                </div>
                <div className='col-md-6 col-12'>
                    <form className="mt-5 p-5 border shadow rounded-4 border-dark p-5 border shadow border-2 " onSubmit={handleClick}>
                        <h3 className="text-uppercase text-center">Login</h3>
                        <div className="form-outline mb-4">
                            <label className="form-label">Email address</label>
                            <input type="email" id="form3Example3" className="form-control form-control-lg" placeholder="Enter email address" required onChange={(e) => setEmail(e.target.value)} />
                        </div>

                        <div className="form-outline mb-3">
                            <label className="form-label" >Password</label>
                            <input type="password" id="form3Example4" className="form-control form-control-lg" placeholder="Enter password" required onChange={(e) => setPassword(e.target.value)} />
                        </div>

                        <div className="text-center text-md-start ">
                            <button type="submit" className="btn btn-primary btn-lg border-rounded w-100 p-2">Login</button>
                            <p className="small fw-bold mt-2 pt-1 mb-0">Don't have an account?<Link className=" text-danger text-decoration-none" to='/customerregister'>Register</Link></p>
                        </div>
                    </form>
                </div>
            </div>
            <div className='mt-3'>
                <Footer />
            </div>
        </div>
    );
}

export default Customerlogin
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Sellerloginnavbar from '../views/Sellerloginnavbar';

export default function Sellerallproduct() {

    const navigate = useNavigate();
    const [email, setEmail] = useState(localStorage.getItem("seller_id"));
    const [allProducts, setAllProducts] = useState([]);
    const [currentSellerId, setSellerId] = useState('');

    useEffect(() => {

        if (localStorage.getItem("seller_id") === "null") {
            navigate("/");
        } else {
            const seller = { email };
            fetch("http://localhost:8080/seller/getSellerId", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(seller)
            }).then(res => res.json())
                .then((result) => {
                    setSellerId(result)
                });

            fetch("http://localhost:8080/product/getProducts")
                .then(res => res.json())
                .then((result) => {
                    setAllProducts(result);
                })
        }


    })

    const [id, setId] = useState('');
    const deleteProduct=()=>{
        alert(id);
        const product={id}
        fetch("http://localhost:8080/product/productDelete", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(product)
            }).then(res => res.text())
                .then((result) => {
                    alert(result)
                });
    }

    const img="Slider1";
    return (
        
        <div className='allproduct'>
            <Sellerloginnavbar />
            <div className="container-fluid mt-5 pt-5">
                <table className="table table-hover text-center">
                    <thead className="headTable">
                        <tr>
                            <th >Product Name</th>
                            <th >Product Type</th>
                            <th >Product Subtype</th>
                            <th >Product Price</th>
                            <th >Product Color</th>
                            <th >Product Size</th>
                            <th >Product Image</th>
                            <th >Delete Product</th>
                        </tr>
                    </thead>
                    <tbody>
                        {allProducts.slice().reverse().map(product => (
                            <>
                                {product.sellerId == currentSellerId ? <tr>
                                    <td>{product.name}</td>
                                    <td>{product.idealFor}</td>
                                    <td>{product.description}</td>
                                    <td>{product.price}</td>
                                    <td>{product.colour}</td>
                                    <td>{product.size}</td>
                                    <td><img width="100vw" height="100vh" src={"/productImages/"+product.imageName} className="imageEdit" /></td>
                                    <td> <button className="btn btn-outline-danger btn1" type="submit" onMouseOver={(e) => setId(product.id)} onClick={deleteProduct}>Delete</button></td>
                                </tr> : <></>}


                            </>
                        ))}

                    </tbody>
                </table>
            </div>
        </div>
    );
}

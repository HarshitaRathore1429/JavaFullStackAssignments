import React, { Component } from 'react';
import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import '../App.css';
import Sellernavbar from '../views/Sellernavbar';
import Navigationbar from "../views/Navigationbar";

export default function Sellerlogin() {

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate();

    const handleClick = (e) => {
        e.preventDefault();
        const seller = { email, password };
        fetch("http://localhost:8080/seller/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(seller)
        }).then(res => res.text())
            .then((result) => {
                
                if (result === "Seller successfully logged in!") {
                    localStorage.setItem("seller_id",email);
                    navigate('/sellerhome');
                }else{
                    alert(result);
                }
            });
    }

    return (
        <div className="customerlogin ">
            <Sellernavbar />
            <div className="container-fluid row mt-5">
                <form className=" col-md-6 offset-md-3 rounded-5 border-dark p-5 border shadow border-2" onSubmit={handleClick}>
                    <h3 className="text-uppercase text-center">Seller Login</h3>
                    <div className="form-outline mb-4">
                        <label className="form-label">Email address</label>
                        <input type="email" id="form3Example3" className="form-control form-control-lg" placeholder="Enter email address" required onChange={(e) => setEmail(e.target.value)} />
                    </div>

                    <div className="form-outline mb-3">
                        <label className="form-label" >Password</label>
                        <input type="password" id="form3Example4" className="form-control form-control-lg" placeholder="Enter password" required onChange={(e) => setPassword(e.target.value)} />
                    </div>

                    <div className="text-center text-md-start ">
                        <button type="submit" className="btn btn-primary btn-lg border-rounded w-100 p-2">Login</button>
                        <div className="mt-2">

                        </div>
                        <p className="small fw-bold mt-2 pt-1 mb-0">Don't have an account?<Link className=" text-danger text-decoration-none" to='/sellerregister'>Register</Link></p>
                    </div>
                </form>
            </div>
        </div>
    );
}
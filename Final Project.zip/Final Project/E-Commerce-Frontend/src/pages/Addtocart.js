import '../App.css';
import { Link } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Customerloginnavbar from '../views/Customerloginnavbar';

//setQuant(quant+1)
function Addtocart() {
    const navigate = useNavigate();
    const [email, setEmail] = useState(localStorage.getItem("customer_id"));
    const [customerCart, setCustomerCart] = useState([]);
    const [customerId, setCustomerId] = useState('');


    useEffect(() => {

        if (localStorage.getItem("customer_id") === "null") {
            navigate("/");
        } else {
            const customer = { email };
            fetch("http://localhost:8080/customer/getCustomerId", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(customer)
            }).then(res => res.json())
                .then((result) => {
                    setCustomerId(result)
                });

            const sendCustomerId = { customerId };
            fetch("http://localhost:8080/cart/getCustomerCart", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(sendCustomerId)
            }).then(res => res.json())
                .then((result) => {
                    setCustomerCart(result)
                });
        }
        if (customerCart.length == 0) {
            document.getElementById("checkoutbutton").disabled = true;
        }
        else{
            document.getElementById("checkoutbutton").disabled = false;
        }
    })

    const [productId, setId] = useState();
    const handleDelete = () => {
        const cartDelete = { customerId, productId }
        fetch("http://localhost:8080/cart/remove", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(cartDelete)
        }).then(res => res.text())
            .then((result) => {
                alert(result)
            });
        window.location.reload(false);
    }

    const quant = customerCart.length;

    var totalPrice = 0;
    customerCart.map(total);

    function total(cart) {
        totalPrice = totalPrice + cart.price;
    }
    return (
        <div className='allproduct'>
            <Customerloginnavbar />
            <div className="container-fluid mt-5 pt-5">
                <table className="table table-hover">
                    <thead className="headTable">
                        <tr>
                            <th >Product Name</th>
                            <th >Product Price</th>
                            <th >Product Type</th>
                            <th >Ideal For</th>
                            <th >Description</th>
                            <th >Product Color</th>
                            <th >Product Size</th>
                            <th >Product Image</th>
                            <th >Delete Product</th>
                        </tr>
                    </thead>
                    {customerCart.map(cart => (

                        <tbody >
                            <tr>
                                <td >{cart.name}</td>
                                <td>{cart.price}</td>
                                <td>{cart.type}</td>
                                <td>{cart.idealFor}</td>
                                <td>{cart.description}</td>
                                <td>{cart.colour}</td>
                                <td>{cart.size}</td>
                                <td><img src={'/productImages/' + cart.imageName} className="imageEdit" width="100vw" height="100vh" /></td>
                                <td> <button className="btn btn-outline-danger btn1" onMouseOver={(e) => setId(cart.id)} onClick={handleDelete} type="submit">Delete This Product</button></td>
                            </tr>
                        </tbody>
                    ))}


                </table>
                <table className='table text-center'>
                    <tbody>
                        <tr>
                            <td>
                                Quantity:{quant}
                            </td>
                            <td>Price:{totalPrice} </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div className="text-center mb-3">

                <button id="checkoutbutton" className="btn bg-primary "><Link className='text-decoration-none text-light' to='/orderdetails'>Checkout</Link></button>
            </div>
        </div>
    );
}

export default Addtocart;
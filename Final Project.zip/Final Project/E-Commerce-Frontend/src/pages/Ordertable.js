import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Customerloginnavbar from '../views/Customerloginnavbar';

export default function Ordertable() {

    const [customerId, setCustomerId] = useState();
    const [allOrders, setAllProducts] = useState([]);
    const [email, setEmail] = useState(localStorage.getItem("customer_id"));
    const navigate = useNavigate();
    useEffect(() => {
        if (localStorage.getItem("customer_id") === "null") {
            navigate("/customerlogin");
        }
        const customerEmail = { email };
        fetch("http://localhost:8080/customer/getCustomerId", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(customerEmail)
        }).then(res => res.json())
            .then((result) => {
                setCustomerId(result)
            });
        const customer = { customerId }
        fetch("http://localhost:8080/customer/getOrder", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(customer)
        }).then(res => res.json())
            .then((result) => {
                setAllProducts(result);
            });
    })
    return (
        <div>
            <Customerloginnavbar />
            <div className='container-fluid mt-5 pt-5'>
            <table className="table table-hover ">
                <thead className="headTable">
                    <tr>
                        <th >Date</th>
                        <th >Time</th>
                        <th >All Product</th>
                        <th >Quantity</th>
                        <th >Address</th>
                        <th >Price</th>
                    </tr>
                </thead>
                {allOrders.map(order => (
                    <tbody>
                        <tr>
                            <td>{order.date}</td>
                            <td>{order.time}</td>
                            <td>{order.allProductsName}</td>
                            <td>{order.quantity}</td>
                            <td>{order.address}</td>
                            <td>{order.price}</td>
                        </tr>
                    </tbody>
                ))}
            </table>
            </div>
        </div >
    )
}
import React, {useEffect } from "react";
import Secondnav from '../views/Secondnav';
import Dashboard from "../views/Dashboard";
import Footer from '../views/Footer';
import { useNavigate } from 'react-router-dom';
import Customerloginnavbar from "../views/Customerloginnavbar";

function Customerhome() {
    const navigate = useNavigate();
    useEffect(() => {
        if (localStorage.getItem("customer_id") === "null") {
            navigate("/");
        }
    })

    return (
        <div className='customerhome'>
            <Customerloginnavbar />
            <Secondnav />
            <Dashboard />
            <Footer />
        </div>
    );
}
export default Customerhome
import React, { Component } from 'react';
import Navigationbar from '../views/Navigationbar';
import Footer from '../views/Footer';


class About extends Component {
    render() {
        return (
            <div className='aboutus '>
                <Navigationbar />

                <div className='col-md-10 offset-md-1 border shadow mt-5 rounded p-5 mb-3 pt-5'>
                    <div className='about'>
                        <div className='row'>
                            <div className='col-md-6 col-12 text-left'>
                                <h3>About Us</h3>
                                <p>
                                    Welcome to Yash E Store! YASH Technologies is a customer-centric transformational global IT
                                    solutions and services partner. We have a proven track record in delivering battle-tested
                                    consulting, technology, and outsourcing services to address our clients’ evolving and complex digital
                                    transformation challenges. We harness business-centric, innovative frameworks and solutions
                                    to help clients achieve unprecedented performance levels and revenue growth at optimized costs. Recognized
                                    as one of the fastest-growing IT services firms globally,
                                    YASH has complemented its robust organic growth with strategic ‘tuck-in’ acquisitions.

                                    E-commerce (electronic commerce) is the buying and selling of goods and services, or the transmitting of funds or data, over an electronic network, primarily the internet.
                                    The history of ecommerce begins with the first ever online sale: on the August 11, 1994 a man sold a CD by the band Sting to his friend through his website NetMarket, an American retail platform. This is the first example of a consumer purchasing a product from a business through the World Wide Web—or “ecommerce” as we commonly know it today.

                                    Since then, ecommerce has evolved to make products easier to discover and purchase through online retailers and marketplaces.  Independent freelancers, small businesses, and large corporations have all benefited from ecommerce, which enables them to sell their goods and services at a scale that was not possible with traditional offline retail.
                                    <br></br>
                                </p>
                            </div>
                            <div className='col-md-6 col-12'>
                                <img src={'/productImages/about.webp'} width="100%" height="100%" />
                            </div>
                        </div>
                    </div>
                </div>
                <Footer />
            </div>

        );
    }
}
export default About
import styled from "styled-components";
import { useEffect, useState } from "react";

import { css } from "styled-components";
import Sellerloginnavbar from "../views/Sellerloginnavbar";

const mobile = (props) => {
  return css`
    @media only screen and (max-width: 300px){
        ${props}
    }
    `;
}

const Container = styled.div`
  height: 100vh;
  background: linear-gradient(
      rgba(255, 255, 255, 0.5),
      rgba(255, 255, 255, 0.5)
    ),
    url("https://images.pexels.com/photos/1036856/pexels-photo-1036856.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2")
      center;
  background-size: cover;
  display: flex;
  align-items: center;
  justify-content: center;
`;

const Wrapper = styled.div`
  width: 40%;
  padding: 80px;
  background-color: white;
  ${mobile({ width: "75%" })}

`;

const Title = styled.h1`
  font-size: 24px;
  font-weight: 300;
  text-align: center;
  padding: 20px;
`;

const Form = styled.form`
  display: flex;
  flex-wrap: wrap;
`;

const Input = styled.input`
  flex: 1;
  min-width: 40%;
  margin: 20px 10px 0px 0px;
  padding: 10px;
`;

const Select = styled.select`
  flex: 1;
  min-width: 40%;
  margin: 20px 10px 0px 0px;
  padding: 10px;
`;
const Label = styled.label`
  flex: 1;
  min-width: 40%;
  margin: 20px 10px 0px 20px;
  padding: 10px;
`;


const Button = styled.button`
  width: 40%;
  border: none;
  padding: 15px 20px;
  background-color: teal;
  color: white;
  cursor: pointer;
  margin:auto;
  margin-top:10px;
`;



const Sellerform = () => {
  const [error, setError] = useState("");
  const [File,] = useState("");

  const handleChange = event => {

    const image = event.target.files[0];
    if (!image) {
      console.log('image is required');
      return false;
    }
    if (!image.name.match(/\.(jpg|jpeg)$/)) {
      console.log('select valid image.');
      return false;
    }
  };

  const [email, setEmail] = useState(localStorage.getItem("seller_id"));
  const [sellerId, setSellerId] = useState('');
  useEffect(() => {
    const seller = { email };
    fetch("http://localhost:8080/seller/getSellerId", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(seller)
    }).then(res => res.json())
      .then((result) => {
        setSellerId(result);
      })
  });

  const [idealFor, setIdealFor] = useState('Men');
  const [name, setName] = useState('Jeans');
  const [size, setSize] = useState('S');
  const [colour, setColor] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState("");
  const [type, setType] = useState("Bottom Wear");

  const [picture, setPicture] = useState({});

  const uploadPicture = (e) => {
    setPicture({
      picturePreview: URL.createObjectURL(e.target.files[0]),
      pictureAsFile: e.target.files[0],
    });
  };

  
  const setImageAction = async (event) => {
    event.preventDefault();

    const formData = new FormData();
    formData.append("img", picture.pictureAsFile);

    const data = await fetch("http://localhost:8080/product/saveImage", {
      method: "POST",
      body: formData,
    });
    const uploadedImage = await data.text();
    const imageName=picture.pictureAsFile.name;
    const product = { name, colour, description, sellerId, size, price, idealFor,imageName,type};
    if (uploadedImage) {
      fetch("http://localhost:8080/product/productAdd", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(product)
    }).then(res => res.text())
      .then((result) => {
        alert(result)
      });
    } else {
      console.log("Error Found");
    }
    
  };

  return (
    <div className="sellerbottom">
      <Sellerloginnavbar />
          <Title className="fw-bold mt-5 pt-5">Bottom Wear</Title>

          <Form className="col-md-6 offset-md-3 border shadow-lg p-4 border-dark rounded ">

            <Select placeholder="Category" onChange={(e) => setIdealFor(e.target.value)}>
              <option value="Men" >Mens</option>
              <option value="Women">Womens</option>
              <option value="Kid">Kids</option>
            </Select>

            {'Men' == idealFor ?
              < Select placeholder="Product Type" onChange={(e) => setName(e.target.value)}>
                <option value="Jeans" selected>Jeans</option>
                <option value="Trouser" >Trouser</option>
                <option value="Pants" >Pants</option>
              </Select>
              : <h1></h1>}

            {'Women' == idealFor ?
              < Select placeholder="Product Type" onChange={(e) => setName(e.target.value)}>
                <option value="Jeans" selected>Jeans</option>
                <option value="Palazzo" >Palazzo</option>
                <option value="Shorts" >Shorts</option>
              </Select>
              : <h1></h1>}

            {'Kid' == idealFor ?
              < Select placeholder="Product Type" onChange={(e) => setName(e.target.value)}>
                <option value="Jeans" selected>Jeans</option>
                <option value="Shorts" >Shorts</option>
              </Select>
              : <h1></h1>}

            <Input placeholder="Product Description" onChange={(e) => setDescription(e.target.value)} required="required" />

            <Input type="number" placeholder="Price" maxLength={10} onChange={(e) => setPrice(e.target.value)} required />

            <Input placeholder="Color" onChange={(e) => setColor(e.target.value)} required />

            <Select placeholder="Size" onChange={(e) => setSize(e.target.value)}>
              <option value="24" selected>24</option>
              <option value="26">26</option>
              <option value="28">28</option>
              <option value="30">30</option>
              <option value="32">32</option>
              <option value="34">34</option>

            </Select>

            <Label for="img">Select Product image:</Label>

            <Input type="file" name="image" onChange={uploadPicture} />

            <Button className="btn bg-primary" type="submit" onClick={setImageAction} >Submit</Button>
          </Form>
    </div>
  );
};

export default Sellerform;
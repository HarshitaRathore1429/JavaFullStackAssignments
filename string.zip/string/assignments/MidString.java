class MidString
{
	public static void main(String[] args)
	{
		String s1=args[0];
		int len=s1.length();
		if(len>2)
		{
		  for(int i=1;i<len-1;i++)
		  { 
	          cshar ch=s1.charAt(i);
			  System.out.print(ch);
		  }
		}
		else
		{
			System.out.println("String length must be greater than 2");
		}
	}
}
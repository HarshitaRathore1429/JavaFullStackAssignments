class StringPalindrome
{
	public static void main(String[] args)
	{   
		String s1=args[0];
		int len=s1.length();
		boolean isPalindrome=true;
		for(int i = 0; i < len; i++)
        {
          if(s1.charAt(i) != s1.charAt(len-1-i)) {
            System.out.println("String is not a palindrome.");
            isPalindrome = false;
            break;
          }
        }
        if(isPalindrome) {
          System.out.println("String is a palindrome.");
        }
	}
}
	
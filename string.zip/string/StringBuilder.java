class StringBuilder
{
	public static void main(String[] args)
	{
		StringBuilder s1 = new StringBuilder("Harshita rathore is in Indore");
		System.out.println(s1);
		s1.replace(24,29,"Madhya Pradesh");
		System.out.println(s1);
	}
}
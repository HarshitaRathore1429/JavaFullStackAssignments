class StringMethod
{
	public static void main(String[] args)
	{
		String s1="";
		String s2="Yash";
		System.out.println(s1.isEmpty());
		System.out.println(s2.isEmpty());
		String s3=" Harshita Rathore";
		System.out.println(s3);
		System.out.println(s3.trim());
		String s4="Welcome Harshita";
		String s5="Welcome Harshita";
		System.out.println(s3.equals(s4));
		System.out.println(s4.equals(s5));
		System.out.println(s5.substring(0,5));
		String s6="HarsHITa";
		String s7="Harshita";
		System.out.println(s6.compareTo(s7));
		System.out.println(s6.equalsIgnoreCase(s4));
	}
}
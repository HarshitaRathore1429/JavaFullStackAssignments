class StringBuilderAppend
{
	public static void main(String[] args)
	{
		StringBuilder sb = new StringBuilder("Harshita rathore is in Indore");
		System.out.println(sb);
		sb.append("in Madhya Pradesh");
		System.out.println(sb);
	}
}
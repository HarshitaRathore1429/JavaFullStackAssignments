import java.util.Scanner;
class NegativeValue extends RuntimeException
{
	NegativeValue(String s)
	{
		super(s);
	}
}
class NumberFormatE extends RuntimeException
{
	NumberFormatE(String s)
	{
		super(s);
	}
}
class Exception6
{
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		String a;
		int []b=new int[3];
		int i,j;
		for(i=0;i<2;i++)
		{
			System.out.println("Enter student name: ");
			a=s.nextLine();
			System.out.println("Enter marks: ");
			for(j=3;j<3;j++)
			{
				b[i]=s.nextInt();
			}
			try
			{
				if(b[i]>100)
				{
					throw new NumberFormatE("Number out of range");
				}
				if(b[i]<0)
				{
					throw new NegativeValue("Negative number not accepted");
				}
			}
            catch(NumberFormatE e)
            {
	           e.printStackTrace();
            }
			catch(NegativeValue n)
            {
              n.printStackTrace();
	        }
	    }
	}
}
class Exception1 
{
	public static void main(String[] args)
	{

		try
		{
			int a=Integer.parseInt(args[0]);
			System.out.println(a*a);
		}
		catch(NumberFormatException n)
		{
			System.out.println("enter input is not valid format for integer");
		}
	}
}
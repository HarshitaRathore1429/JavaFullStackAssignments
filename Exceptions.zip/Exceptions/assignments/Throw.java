import java.util.Scanner;
class VoteEligibility extends RuntimeException
{
	VoteEligibility(String s)
	{
	  super(s);	
	}
}
class Nullp extends RuntimeException
{
	Nullp(String s)
	{
		super(s);
	}
}
class Throw
{
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter your age:");
		int age=s.nextInt();
	    try
		{
		 	if(age<18)
	  		{
				throw new VoteEligibility("You are not eligible for voting"),Nullp("No null value");
			}
			else
			{
				System.out.println("You can vote");
			}
		} 
		catch(VoteEligibility e)
		{
		  e.printStackTrace();		  
		}
		System.out.println("Bye");
	}
}
	
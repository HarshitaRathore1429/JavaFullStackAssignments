class ArithmeticException extends RuntimeException
{
	ArithmeticException(String s)
	{
		super(s);
	}
}
class Exception8
{
	public static void main(String[] args)
	{
		int a=Integer.parseInt(args[0]);
		int b=Integer.parseInt(args[1]);
		int c=a/b;
		try
		{
			if(b==0)
			{
				throw new ArithmeticException("zero is not accepted");
			}
			else
			{
				System.out.println(c);
			}
		}
		catch(ArithException w)
		{
			w.printStackTrace();
		}
		finally
		{
			System.out.println("Inside finally block");
		}
	}
}
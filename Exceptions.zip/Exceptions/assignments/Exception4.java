import java.util.Scanner;
class Exception4
{
	public static void main(String[] args)
	{   int sum=0;
	    int a[]=new int[5];
		
		try
		{
			for(int i=0;i<5;i++)
		    {
				a[i]=Integer.parseInt(args[i]);
		        sum=sum+a[i];
			}
		}
		catch(NumberFormatException e)
	    {
		  System.out.println(e.getClass());
	    }
	    catch(ArithmeticException e)
	    {
		  System.out.println(e.getClass());
	    }
		System.out.println(sum);
	}
}
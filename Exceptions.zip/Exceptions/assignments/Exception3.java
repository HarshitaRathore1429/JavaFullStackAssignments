import java.util.Scanner;
class Exception3
{
	public static void main(String[] args)
	{
	    Scanner s=new Scanner(System.in);
		System.out.println("Enter size of array:");
		int n=s.nextInt();
		 int []a=new int[n];
		try
		{
		System.out.println("Enter elements of array:");
		for (int i=0;i<n;i++)
		{
			a[i] = s.nextInt();
		}
	     System.out.println("Enter index which you want to access");
	  	 int j=s.nextInt();
		 System.out.println("Accessed number is"+a[j]);
	    }
		catch(NumberFormatException e)
	    {
		  System.out.println(e.getClass());
	    }
	    catch(ArrayIndexOutOfBoundsException e)
	    {
		  System.out.println(e.getClass());
	    }
	}
}
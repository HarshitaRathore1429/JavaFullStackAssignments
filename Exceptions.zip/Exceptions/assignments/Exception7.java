import java.util.Scanner;
class InvalidCountryException extends RuntimeException
{
	InvalidCountryException(String s)
	{
		super(s);
	}
}
class UserRegistration
{
	public static void main(String[] args)
	{   
        String username,usercountry;		
		Scanner s=new Scanner(System.in);
        username=s.next();
		usercountry=s.next();
		String s2="India";
		try
		{
			if(usercountry.equals(s2))
			{
				System.out.println("User is registered");
			}
			else
			{
				throw new InvalidCountryException("User outside India cannot access");
			}
		}
		catch(InvalidCountryException e)
		{
			e.printStackTrace();
		}
	}
}
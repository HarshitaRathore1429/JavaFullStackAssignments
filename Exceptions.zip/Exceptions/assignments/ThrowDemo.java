class Throws
{
	void show() throws ClassNotFoundException
	{
		Class.forName("mypackage.project");
	}
}
class ThrowDemo
{
	public static void main(String[] args)
	{
		Throws t=new Throws();
		try
		{
			t.show();
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
	}
}
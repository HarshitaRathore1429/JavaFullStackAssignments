import java.io.File;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.EOFException;
class CheckedException 
{
	public static void main(String[] args)throws Exception
	{ try
	  {
      //File f=new File("D:/harhita.txt");
      //FileReader r=new FileReader(f);
      //Class c=Class.forName("YASH");
	  DataInputStream dis = new DataInputStream(new FileInputStream("C:/Users/Harshita.Rathore/Desktop/Java program/Stream/abc.txt"));
      while(true) {
         char ch;
         ch = dis.readChar();
         System.out.print(ch);
      }
	  }
	catch(FileNotFoundException  | EOFException n)
	  {
        n.printStackTrace();
	  }
	}
}
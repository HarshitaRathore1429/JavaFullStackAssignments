import java.util.Scanner;
class UncheckedException
{
	public static void main(String[] args)
	{   Scanner sc=new Scanner(System.in);
		try
		{  
    		System.out.println("Enter dividend:");
	    	int a=sc.nextInt();
		    System.out.println("Enter divisor:");
	    	int b=sc.nextInt();
			System.out.println(a/b);
		    int[] arr={10,0,30,34};
		    System.out.println("Enter index number of array to retrieve");
		    int index=sc.nextInt();
			System.out.println(arr[index]);
			//String s=null;
			//System.out.println(s.length());
			 int o = Integer.parseInt(null);
		}
		catch(ArithmeticException ae)
		{
			ae.printStackTrace();
		}
		catch(ArrayIndexOutOfBoundsException ai)
		{
			ai.printStackTrace();
		}
		catch(NullPointerException n)
		{
			n.printStackTrace();
		}
		catch(NumberFormatException i)
		{
			i.printStackTrace();
		}
		
	}
}
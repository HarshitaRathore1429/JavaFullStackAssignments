import java.io.FileInputStream;
class ExceptionDemo1
{
	public static void main(String[] args)
	{   
	    try
		{
			FileInputStream f= new FileInputStream("D://xwy.txt");//file not found
		} 
         catch(Exception e)
		{
			 System.out.println(e);
		}  
	}
}
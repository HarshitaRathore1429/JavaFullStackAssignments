import java.util.Scanner;
class EnumDemo1
{
	enum WeekDays{
		MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY,SATURDAY,SUNDAY;
	}
	public static void main(String[] args)
	{   Scanner sc=new Scanner(System.in);
		int c;
		System.out.println("Enter weekday number");
		c=sc.nextInt();
		switch(c)
		{
			case 1:
			System.out.println(WeekDays.valueOf("MONDAY"));
			System.out.println(WeekDays.valueOf("MONDAY").ordinal());
			break;
			case 2:
			System.out.println(WeekDays.valueOf("TUESDAY"));
			System.out.println(WeekDays.valueOf("TUESDAY").ordinal());
			break;
			case 3:
			System.out.println(WeekDays.valueOf("WEDNESDAY"));
			System.out.println(WeekDays.valueOf("WEDNESDAY").ordinal());
			break;
			case 4:
			System.out.println(WeekDays.valueOf("THURSDAY"));
			System.out.println(WeekDays.valueOf("THURSDAY").ordinal());
			break;
			case 5:
			System.out.println(WeekDays.valueOf("FRIDAY"));
			System.out.println(WeekDays.valueOf("FRIDAY").ordinal());
			break;
			case 6:
			System.out.println(WeekDays.valueOf("SATURDAY"));
			System.out.println(WeekDays.valueOf("SATURDAY").ordinal());
			break;
			case 7:
			System.out.println(WeekDays.valueOf("SUNDAY"));
			System.out.println(WeekDays.valueOf("SUNDAY").ordinal());
			break;
		}
	}
}
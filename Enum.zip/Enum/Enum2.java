public class Enum2
{
	enum Seasons{
		SUMMER,SPRING,RAINY,WINTER;
	}
	private Enum2(final String day)
	{
		this.day=day;
	}
	private String day;
	public String day()
	{
		System.out.println(Seasons.valueOf(day)+" "+Seasons.valueOf(day).ordinal());
		return day;
	}
	public static void main(String[] args)
    {
		Enum2 e=new Enum2("WINTER");
		e.day();
	}
}